# 1. Introduction:

It packs in lots of demanding features that allows your business to scale in no time:

* Assign labels to all the product types.

* Add visually appealing labels (e.g., Best Seller, New Arrival, Limited Offer) to products, enhancing product visibility and user engagement.

* Assign multiple labels to cart rules, allowing you to highlight various promotions or product attributes simultaneously.

* Automatically display assigned product labels dynamically on both product listing and product detail pages, ensuring consistent and seamless user experience.

* Effortlessly assign labels to cart rules using an intuitive drag-and-drop interface, simplifying label management and saving time.

* Visible on all pages - product, category, search, advanced search, wishlist, compare, and other CMS pages..


## 2. Requirements:

* **Bagisto**: v2.2.4

### 3. Installation:

* Unzip the respective extension zip and then merge "packages" folder into project root directory.

#### Goto `config/app.php` file and add following line under `providers`

~~~
Webkul\ProductLabel\Providers\ProductLabelServiceProvider::class,
~~~

#### Goto `composer.json` file and add following line under 'psr-4'

~~~
"Webkul\\ProductLabel\\": "packages/Webkul/ProductLabel/src"
~~~

#### Run these commands below to complete the setup

~~~
composer dump-autoload
~~~

~~~
php artisan product-label:install
~~~

~~~
php artisan optimize:clear
~~~
