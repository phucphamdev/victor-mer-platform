<?php

namespace Webkul\ProductLabel\Listeners;

class CartRule
{
    /**
     * Update cartRule-lables after edit cart rule.
     */
    public function afterUpdate($cartRule): void
    {
        $cartRuleLables = request('cartRuleLables') ?? [];

        $syncData = [];

        foreach ($cartRuleLables as $labelId => $sortOrder) {
            $syncData[$labelId] = ['sort_order' => $sortOrder];
        }

        $cartRule->labels()->sync($syncData);
    }
}
