<?php

namespace Webkul\ProductLabel\Repositories;

use Illuminate\Container\Container;
use Illuminate\Support\Carbon;
use Webkul\Core\Eloquent\Repository;
use Webkul\Marketing\Repositories\CampaignRepository;
use Webkul\ProductLabel\Contracts\Label;

class LabelRepository extends Repository
{
    /**
     * Create a new repository instance.
     *
     * @return void
     */
    public function __construct(
        protected CampaignRepository $campaignRepository,
        Container $container
    ) {
        parent::__construct($container);
    }

    /**
     * Specify Model class name
     *
     * @return mixed
     */
    public function model()
    {
        return Label::class;
    }

    /**
     * Get un-assigned labels.
     */
    public function getUnAssignedLabels($cartRule): object
    {
        $today = Carbon::today();

        $query = $this->model
            ->newQuery()
            ->where('status', 1);

        if (isset($cartRule)) {
            $query->leftJoin('cart_rule_labels', function ($join) use ($cartRule) {
                $join->on('labels.id', '=', 'cart_rule_labels.label_id')
                    ->where('cart_rule_labels.cart_rule_id', $cartRule->id);
            })
                ->whereNull('cart_rule_labels.cart_rule_id');
        }

        $query->orderBy('labels.sort_order');

        return $query->get();
    }
}
