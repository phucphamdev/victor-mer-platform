<?php

namespace Webkul\ProductLabel\Models;

use Illuminate\Database\Eloquent\Model;
use Webkul\Product\Models\ProductProxy;
use Webkul\CartRule\Models\CartRuleProxy;
use Webkul\Marketing\Models\CampaignProxy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Webkul\ProductLabel\Contracts\Label as LabelContract;

class Label extends Model implements LabelContract
{
    use HasFactory;

    /**
     * Table associated with the model
     *
     * @var string
     */
    protected $table = 'labels';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'type',
        'icon',
        'image_path',
        'text',
        'text_color',
        'background_color',
        'position',
        'sort_order',
        'status',
        'image_width',
        'image_height',
    ];

    /**
     * Get campaign associated with the label.
     */
    public function campaign()
    {
        return $this->belongsTo(CampaignProxy::modelClass(), 'campaign_id');
    }

    /**
     * Get product associated with the label.
     */
    public function cart_rule()
    {
        return $this->belongsToMany(CartRuleProxy::modelClass(), 'cart_rule_labels')
            ->withPivot('sort_order');
    }
}
