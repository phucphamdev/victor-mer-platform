<?php

namespace Webkul\ProductLabel\Models\CartRule;

use Webkul\ProductLabel\Models\LabelProxy;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Webkul\CartRule\Models\CartRule as BaseModel;

class CartRule extends BaseModel
{
    /**
     * Get product associated with the label.
     */
    public function labels(): BelongsToMany
    {
        return $this->belongsToMany(LabelProxy::modelClass(), 'cart_rule_labels')
            ->withPivot('sort_order')
            ->where('labels.status', 1)
            ->orderBy('cart_rule_labels.sort_order');
    }
}
