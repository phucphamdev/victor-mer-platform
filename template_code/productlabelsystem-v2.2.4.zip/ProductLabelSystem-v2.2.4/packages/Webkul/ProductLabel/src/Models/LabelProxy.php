<?php

namespace Webkul\ProductLabel\Models;

use Konekt\Concord\Proxies\ModelProxy;

class LabelProxy extends ModelProxy {}
