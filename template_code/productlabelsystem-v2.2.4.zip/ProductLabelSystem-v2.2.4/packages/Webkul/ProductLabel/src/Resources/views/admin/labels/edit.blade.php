
<x-admin::layouts>
    <x-slot:title>
        @lang('productlabel::app.admin.label.edit.title')
    </x-slot>

    <v-label-create></v-label-create>

    @pushOnce('scripts')
        <script
            type="text/x-template"
            id="v-label-create-template"
        >
             {!! view_render_event('bagisto.admin.label.edit.before', ['label' => $label]) !!}

            <!-- Input Form -->
            <x-admin::form
                :action="route('admin.product_label.update', $label->id)"
                method="PUT"
                enctype="multipart/form-data"
                >

                {!! view_render_event('bagisto.admin.label.edit.create_form_controls.before', ['label' => $label]) !!}

                <div class="flex items-center justify-between">
                    <p class="text-xl font-bold text-gray-800 dark:text-white">
                        @lang('productlabel::app.admin.label.edit.title')
                    </p>

                    <div class="flex items-center gap-x-2.5">
                        <!-- Back Button -->
                        <a
                            href="{{ route('admin.product_label.index') }}"
                            class="transparent-button hover:bg-gray-200 dark:text-white dark:hover:bg-gray-800"
                        >
                            @lang('productlabel::app.admin.label.edit.back-btn')
                        </a>

                        <!-- Save Button -->
                        <button
                            type="submit"
                            class="primary-button"
                        >
                            @lang('productlabel::app.admin.label.edit.save-btn')
                        </button>
                    </div>
                </div>
                <!-- Information -->
                <div class="mt-3.5 flex gap-2.5 max-xl:flex-wrap">
                    <!-- Left Section -->
                    <div class="flex flex-1 flex-col gap-2 max-xl:flex-auto">

                        {!! view_render_event('bagisto.admin.label.edit.card.general.before', ['label' => $label]) !!}

                        <!-- General Section -->
                        <div class="box-shadow rounded bg-white p-4 dark:bg-gray-900">
                            <p class="mb-4 text-base font-semibold text-gray-800 dark:text-white">
                                @lang('productlabel::app.admin.label.edit.general')
                            </p>

                            <div class="mb-2.5">
                                <input
                                    type="hidden"
                                    name="position"
                                    value="top-left"
                                    />

                                <x-admin::form.control-group>
                                    <x-admin::form.control-group.label class="required">
                                        @lang('productlabel::app.admin.label.edit.label-name')
                                    </x-admin::form.control-group.label>

                                    <x-admin::form.control-group.control
                                        type="text"
                                        name="name"
                                        rules="required"
                                        value="{{ old('name') ?: $label->name }}"
                                        :label="trans('productlabel::app.admin.label.edit.label-name')"
                                        :placeholder="trans('productlabel::app.admin.label.edit.label-name')"
                                    />

                                    <x-admin::form.control-group.error control-name="name" />
                                </x-admin::form.control-group>

                                <!-- sort order | position -->
                                <x-admin::form.control-group>
                                    <x-admin::form.control-group.label class="required">
                                        @lang('productlabel::app.admin.label.edit.sort-order')
                                    </x-admin::form.control-group.label>

                                    <x-admin::form.control-group.control
                                        type="text"
                                        name="sort_order"
                                        rules="required|integer"
                                        value="{{ old('sort_order') ?: $label->sort_order }}"
                                        :label="trans('productlabel::app.admin.label.edit.sort-order')"
                                        :placeholder="trans('productlabel::app.admin.label.edit.sort-order')"
                                    />

                                    <x-admin::form.control-group.error control-name="sort_order" />
                                </x-admin::form.control-group>

                                <!-- Lable type -->
                                <x-admin::form.control-group class="">
                                    <x-admin::form.control-group.label class="required">
                                        @lang('productlabel::app.admin.label.edit.label-type')
                                    </x-admin::form.control-group.label>

                                    <x-admin::form.control-group.control
                                        type="select"
                                        name="type"
                                        rules="required"
                                        class="cursor-pointer"
                                        v-model="typeCode"
                                        :label="trans('productlabel::app.admin.label.edit.compaign')"
                                    >
                                        <!-- Default Option -->
                                        <option value="">
                                            @lang('productlabel::app.admin.label.edit.select')
                                        </option>

                                        <option
                                            v-for="(type, index) in types"
                                            :value="type.code"
                                            >
                                            @{{ type.label }}
                                        </option>
                                    </x-admin::form.control-group.control>

                                    <x-admin::form.control-group.error control-name="type" />
                                </x-admin::form.control-group>

                                <div v-if="typeCode == 'text'">
                                    <!-- Lable Text -->
                                    <x-admin::form.control-group>
                                        <x-admin::form.control-group.label class="required">
                                            @lang('productlabel::app.admin.label.edit.label-text')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="text"
                                            name="text"
                                            rules="required|max:50"
                                            value="{{ old('text') ?: $label->text }}"
                                            :label="trans('productlabel::app.admin.label.edit.label-text')"
                                            :placeholder="trans('productlabel::app.admin.label.edit.label-text')"
                                        />
                                        <x-admin::form.control-group.error 
                                            control-name="text" 
                                            class="text-red-600 mt-1 text-sm"
                                        />
                                    </x-admin::form.control-group>

                                    <!-- Text color -->
                                    <x-admin::form.control-group class="w-2/6">
                                        <x-admin::form.control-group.label>
                                            @lang('productlabel::app.admin.label.edit.label-text-color')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="color"
                                            name="text_color"
                                            :placeholder="trans('productlabel::app.admin.label.edit.label-text-color')"
                                            value="{{ old('text_color') ?: $label->text_color }}"
                                        />

                                        <x-admin::form.control-group.error control-name="text_color" />
                                    </x-admin::form.control-group>

                                    <!-- Background Color -->
                                    <x-admin::form.control-group class="w-2/6">
                                        <x-admin::form.control-group.label>
                                            @lang('productlabel::app.admin.label.edit.label-bg-color')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="color"
                                            name="background_color"
                                            :placeholder="trans('productlabel::app.admin.label.edit.label-bg-color')"
                                            value="{{ old('background_color') ?: $label->background_color }}"
                                        />

                                        <x-admin::form.control-group.error control-name="background_color" />
                                    </x-admin::form.control-group>
                                </div>

                                <div v-if="typeCode == 'image' || typeCode == 'icon'">
                                    <x-admin::form.control-group>
                                        <x-admin::form.control-group.label>
                                            @lang('productlabel::app.admin.label.edit.image-width')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="text"
                                            name="image_width"
                                            rules="integer"
                                            value="{{ old('image_width') ?: $label->image_width }}"
                                            :label="trans('productlabel::app.admin.label.edit.image-width')"
                                            :placeholder="trans('productlabel::app.admin.label.edit.image-width')"
                                        />

                                        <x-admin::form.control-group.error control-name="image_width" />
                                    </x-admin::form.control-group>

                                    <x-admin::form.control-group>
                                        <x-admin::form.control-group.label>
                                            @lang('productlabel::app.admin.label.edit.image-height')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="text"
                                            name="image_height"
                                            rules="integer"
                                            value="{{ old('image_height') ?: $label->image_height }}"
                                            :label="trans('productlabel::app.admin.label.edit.image-height')"
                                            :placeholder="trans('productlabel::app.admin.label.edit.image-height')"
                                        />

                                        <x-admin::form.control-group.error control-name="image_height" />
                                    </x-admin::form.control-group>

                                    <!-- Lable Image -->
                                    <div class="flex flex-col gap-2 w-[40%] mt-5">
                                        <p class="text-gray-800 dark:text-white font-medium">
                                            @lang('productlabel::app.admin.label.edit.label-image')
                                        </p>

                                        <x-admin::media.images
                                            name="image"
                                            :uploaded-images="$label->type == 'image' ? [['id' => 'image', 'url' => Storage::url($label->image_path)]] : []"
                                            />
                                    </div>
                                </div>
                            </div>
                        </div>

                        {!! view_render_event('bagisto.admin.label.edit.card.general.after', ['label' => $label]) !!}
                    </div>

                    <!-- Right Section -->
                    <div class="flex w-[360px] max-w-full flex-col gap-2 max-md:w-full">

                        {!! view_render_event('bagisto.admin.label.edit.card.accordion.setting.before', ['label' => $label]) !!}

                        <!-- Setting -->
                        <x-admin::accordion>
                            <x-slot:header>
                                <p class="p-2.5 text-base font-semibold text-gray-800 dark:text-white">
                                    @lang('productlabel::app.admin.label.edit.setting')
                                </p>
                            </x-slot>

                            <x-slot:content>
                                <!-- Status -->
                                <x-admin::form.control-group class="!mb-0">
                                    <x-admin::form.control-group.label>
                                        @lang('productlabel::app.admin.label.edit.status')
                                    </x-admin::form.control-group.label>

                                    <x-admin::form.control-group.control
                                        type="switch"
                                        name="status"
                                        value="1"
                                        :label="trans('productlabel::app.admin.label.edit.status')"
                                        :checked="old('status', $label->status) ? true : false"
                                    />

                                </x-admin::form.control-group>
                            </x-slot>
                        </x-admin::accordion>

                        {!! view_render_event('bagisto.admin.label.edit.card.accordion.setting.after', ['label' => $label]) !!}
                    </div>
                </div>

                {!! view_render_event('bagisto.admin.label.edit.create_form_controls.after', ['label' => $label]) !!}

            </x-admin::form>

            {!! view_render_event('bagisto.admin.label.edit.after', ['label' => $label]) !!}
        </script>
        <script type="module">
            app.component('v-label-create', {
                template: '#v-label-create-template',

                data() {
                    return {
                        label: @json($label),
                        types: [
                            { code: 'text', label: @json(trans('productlabel::app.admin.label.index.datagrid.type.text')) },
                            { code: 'image', label: @json(trans('productlabel::app.admin.label.index.datagrid.type.image')) },
                        ],
                        typeCode: '',
                        oldData: @json(old()),
                    };
                },

                mounted() {
                    if(this.oldData.type){
                        this.typeCode = this.oldData.type;
                    } else{
                        this.typeCode = this.label.type;
                    }
                },
            });
        </script>
    @endPushOnce

</x-admin::layouts>
