<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'Etykiety',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'Utwórz etykietę',
				'title'      => 'Etykiety',

				'datagrid' => [
					'id'                  => 'Identyfikator',
					'name'                => 'Nazwa',
					'label'               => 'Etykieta',
					'compaign-id'         => 'Identyfikator kampanii',
					'status'              => 'Status',
					'active'              => 'Aktywny',
					'inactive'            => 'Nieaktywny',
					'edit'                => 'Edytuj',
					'delete'              => 'Usuń',
					'update-status'       => 'Zaktualizuj status',
					'create-success'      => 'Etykieta została pomyślnie utworzona',
					'mass-update-success' => 'Etykiety zostały pomyślnie zaktualizowane',
					'update-success'      => 'Etykieta została pomyślnie zaktualizowana',
					'mass-delete-success' => 'Etykiety zostały pomyślnie usunięte',
					'delete-success'      => 'Etykieta została pomyślnie usunięta',

					'type' => [
						'title' => 'Typ',
						'image' => 'Obraz',
						'icon'  => 'Ikona',
						'text'  => 'Tekst',
					],
				],
			],

			'create' => [
				'active'           => 'Aktywny',
				'back-btn'         => 'Wstecz',
				'channel'          => 'Kanał',
				'customer-group'   => 'Grupa klientów',
				'compaign'         => 'Kampania',
				'event'            => 'Wydarzenie',
				'general'          => 'Ogólne',
				'inactive'         => 'Nieaktywny',
				'sort-order'       => 'Priorytet',
				'save-btn'         => 'Zapisz etykietę',
				'select-channel'   => 'Wybierz kanał',
				'select-event'     => 'Wybierz wydarzenie',
				'select-group'     => 'Wybierz grupę',
				'select-status'    => 'Wybierz status',
				'select-compaign'  => 'Wybierz kampanię',
				'setting'          => 'Ustawienia',
				'status'           => 'Status',
				'subject'          => 'Temat',
				'title'            => 'Utwórz etykietę',
				'label-name'       => 'Nazwa',
				'label-type'       => 'Typ',
				'label-text'       => 'Tekst',
				'label-text-color' => 'Kolor tekstu',
				'label-bg-color'   => 'Kolor tła',
				'label-image'      => 'Obraz',
				'image-width'      => 'Szerokość (px)',
				'image-height'     => 'Wysokość (px)',
				'select'           => 'Wybierz',
			],

			'edit' => [
				'active'           => 'Aktywny',
				'audience'         => 'Odbiorcy',
				'back-btn'         => 'Wstecz',
				'channel'          => 'Kanał',
				'customer-group'   => 'Grupa klientów',
				'compaign'         => 'Kampania',
				'event'            => 'Wydarzenie',
				'general'          => 'Ogólne',
				'inactive'         => 'Nieaktywny',
				'sort-order'       => 'Priorytet',
				'save-btn'         => 'Zaktualizuj',
				'select-event'     => 'Wybierz wydarzenie',
				'select-status'    => 'Wybierz status',
				'select-compaign'  => 'Wybierz kampanię',
				'setting'          => 'Ustawienia',
				'status'           => 'Status',
				'subject'          => 'Temat',
				'title'            => 'Edytuj etykietę',
				'label-name'       => 'Nazwa',
				'label-type'       => 'Typ',
				'label-text'       => 'Tekst',
				'label-text-color' => 'Kolor tekstu',
				'label-bg-color'   => 'Kolor tła',
				'label-image'      => 'Obraz',
				'image-width'      => 'Szerokość (px)',
				'image-height'     => 'Wysokość (px)',
				'select'           => 'Wybierz',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'Etykiety',
						'info'                   => 'Przypisz etykiety do reguły koszyka',
						'assigned-labels'        => 'Przypisane etykiety',
						'unassigned-labels'      => 'Nieprzypisane etykiety',
						'unassigned-labels-info' => 'Przeciągnij te etykiety, aby dodać je do wybranej listy.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'Ustawienia etykiet produktów.',
				'title' => 'Etykieta produktu',

				'general' => [
					'info'  => 'Ustaw status etykiet produktu.',
					'title' => 'Ogólne',

					'settings' => [
						'title'                               => 'Ogólne',
						'info'                                => 'Skonfiguruj ustawienia etykiet produktu.',
						'status'                              => 'Status',
						'max-label-show-on-card'              => 'Maksymalna liczba etykiet na karcie produktu',
						'max-label-show-on-card-info'         => 'Określ maksymalną liczbę etykiet wyświetlanych na karcie produktu.',
						'max-label-show-on-product-view'      => 'Maksymalna liczba etykiet na stronie produktu',
						'max-label-show-on-product-view-info' => 'Określ liczbę etykiet wyświetlanych na stronie produktu. Ustaw wartość 0 lub pozostaw puste, aby wyświetlić wszystkie powiązane etykiety.',
						'label-image-width'                   => 'Szerokość obrazu etykiety (px) dla komputerów',
						'label-image-width-info'              => 'Określ szerokość obrazu etykiety dla komputerów.',
						'label-image-heigh'                   => 'Wysokość obrazu etykiety (px) dla komputerów',
						'label-image-heigh-info'              => 'Określ wysokość obrazu etykiety dla komputerów.',
						'mobile-label-image-width'            => 'Szerokość obrazu etykiety (px) dla urządzeń mobilnych',
						'mobile-label-image-width-info'       => 'Określ szerokość obrazu etykiety dla urządzeń mobilnych.',
						'mobile-label-image-heigh'            => 'Wysokość obrazu etykiety (px) dla urządzeń mobilnych',
						'mobile-label-image-heigh-info'       => 'Określ wysokość obrazu etykiety dla urządzeń mobilnych.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'Instaluje pakiet etykiet produktów.',
			'migrate'     => 'Migracja wszystkich tabel do bazy danych (może to chwilę potrwać)...',
			'seed'        => 'Dodawanie danych do bazy danych...',
			'publish'     => 'Publikowanie zasobów i konfiguracji...',
			'cache'       => 'Czyszczenie pamięci podręcznej...',
			'finish'      => 'Pakiet etykiet produktów został pomyślnie zainstalowany.',
		],

		'version' => [
			'description' => 'Wyświetla aktualną wersję pakietu etykiet produktów.',
			'comment'     => 'Wersja etykiety produktu: :version',
		],
	],
];
