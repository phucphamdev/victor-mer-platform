@bagistoVite(['src/Resources/assets/css/app.css', 'src/Resources/assets/js/app.js'], 'product-label')
