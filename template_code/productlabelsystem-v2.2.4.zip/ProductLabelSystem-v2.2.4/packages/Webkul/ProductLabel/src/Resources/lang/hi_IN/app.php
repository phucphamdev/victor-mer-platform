<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'लेबल',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'लेबल बनाएं',
				'title'      => 'लेबल',

				'datagrid' => [
					'id'                  => 'आईडी',
					'name'                => 'नाम',
					'label'               => 'लेबल',
					'compaign-id'         => 'अभियान आईडी',
					'status'              => 'स्थिति',
					'active'              => 'सक्रिय',
					'inactive'            => 'निष्क्रिय',
					'edit'                => 'संपादित करें',
					'delete'              => 'हटाएं',
					'update-status'       => 'स्थिति अपडेट करें',
					'create-success'      => 'लेबल सफलतापूर्वक बनाया गया',
					'mass-update-success' => 'लेबल सफलतापूर्वक अपडेट किए गए',
					'update-success'      => 'लेबल सफलतापूर्वक अपडेट किया गया',
					'mass-delete-success' => 'लेबल सफलतापूर्वक हटाए गए',
					'delete-success'      => 'लेबल सफलतापूर्वक हटाया गया',

					'type' => [
						'title' => 'प्रकार',
						'image' => 'छवि',
						'icon'  => 'आइकन',
						'text'  => 'पाठ',
					],
				],
			],

			'create' => [
				'active'           => 'सक्रिय',
				'back-btn'         => 'वापस',
				'channel'          => 'चैनल',
				'customer-group'   => 'ग्राहक समूह',
				'compaign'         => 'अभियान',
				'event'            => 'घटना',
				'general'          => 'सामान्य',
				'inactive'         => 'निष्क्रिय',
				'sort-order'       => 'प्राथमिकता',
				'save-btn'         => 'लेबल सहेजें',
				'select-channel'   => 'चैनल चुनें',
				'select-event'     => 'घटना चुनें',
				'select-group'     => 'समूह चुनें',
				'select-status'    => 'स्थिति चुनें',
				'select-compaign'  => 'अभियान चुनें',
				'setting'          => 'सेटिंग',
				'status'           => 'स्थिति',
				'subject'          => 'विषय',
				'title'            => 'लेबल बनाएं',
				'label-name'       => 'नाम',
				'label-type'       => 'प्रकार',
				'label-text'       => 'पाठ',
				'label-text-color' => 'रंग',
				'label-bg-color'   => 'पृष्ठभूमि रंग',
				'label-image'      => 'छवि',
				'image-width'      => 'चौड़ाई (px)',
				'image-height'     => 'ऊँचाई (px)',
				'select'           => 'चुनें',
			],

			'edit' => [
				'active'           => 'सक्रिय',
				'audience'         => 'दर्शक',
				'back-btn'         => 'वापस',
				'channel'          => 'चैनल',
				'customer-group'   => 'ग्राहक समूह',
				'compaign'         => 'अभियान',
				'event'            => 'घटना',
				'general'          => 'सामान्य',
				'inactive'         => 'निष्क्रिय',
				'sort-order'       => 'प्राथमिकता',
				'save-btn'         => 'अपडेट करें',
				'select-event'     => 'घटना चुनें',
				'select-status'    => 'स्थिति चुनें',
				'select-compaign'  => 'अभियान चुनें',
				'setting'          => 'सेटिंग',
				'status'           => 'स्थिति',
				'subject'          => 'विषय',
				'title'            => 'लेबल संपादित करें',
				'label-name'       => 'नाम',
				'label-type'       => 'प्रकार',
				'label-text'       => 'पाठ',
				'label-text-color' => 'रंग',
				'label-bg-color'   => 'पृष्ठभूमि रंग',
				'label-image'      => 'छवि',
				'image-width'      => 'चौड़ाई (px)',
				'image-height'     => 'ऊँचाई (px)',
				'select'           => 'चुनें',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'लेबल',
						'info'                   => 'कार्ट नियमों के लिए लेबल असाइन करें',
						'assigned-labels'        => 'सौंपे गए लेबल',
						'unassigned-labels'      => 'असाइन न किए गए लेबल',
						'unassigned-labels-info' => 'इन लेबल को खींचकर चयनित सूची में जोड़ें।',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'उत्पाद लेबल से संबंधित सेटिंग्स सेट करें।',
				'title' => 'उत्पाद लेबल',

				'general' => [
					'info'  => 'उत्पाद लेबल की स्थिति सेट करें।',
					'title' => 'सामान्य',

					'settings' => [
						'title'                               => 'सामान्य',
						'info'                                => 'उत्पाद लेबल से संबंधित सेटिंग्स सेट करें।',
						'status'                              => 'स्थिति',
						'max-label-show-on-card'              => 'उत्पाद कार्ड पर दिखाए जाने वाले लेबल की संख्या',
						'max-label-show-on-card-info'         => 'उत्पाद कार्ड पर प्रदर्शित होने वाले अधिकतम लेबल की संख्या सेट करें।',
						'max-label-show-on-product-view'      => 'उत्पाद दृश्य पृष्ठ पर लेबल की संख्या',
						'max-label-show-on-product-view-info' => 'निर्धारित करें कि उत्पाद दृश्य पर कितने लेबल दिखाई देंगे। सभी लेबल दिखाने के लिए 0 या खाली छोड़ें।',
						'label-image-width'                   => 'डेस्कटॉप के लिए लेबल छवि की चौड़ाई (px)',
						'label-image-width-info'              => 'डेस्कटॉप के लिए लेबल छवि की चौड़ाई निर्दिष्ट करें।',
						'label-image-heigh'                   => 'डेस्कटॉप के लिए लेबल छवि की ऊँचाई (px)',
						'label-image-heigh-info'              => 'डेस्कटॉप के लिए लेबल छवि की ऊँचाई निर्दिष्ट करें।',
						'mobile-label-image-width'            => 'मोबाइल के लिए लेबल छवि की चौड़ाई (px)',
						'mobile-label-image-width-info'       => 'मोबाइल के लिए लेबल छवि की चौड़ाई निर्दिष्ट करें।',
						'mobile-label-image-heigh'            => 'मोबाइल के लिए लेबल छवि की ऊँचाई (px)',
						'mobile-label-image-heigh-info'       => 'मोबाइल के लिए लेबल छवि की ऊँचाई निर्दिष्ट करें।',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'उत्पाद लेबल पैकेज इंस्टॉल करें।',
			'migrate'     => 'सभी तालिकाओं को डेटाबेस में माइग्रेट किया जा रहा है (इसमें कुछ समय लग सकता है)...',
			'seed'        => 'डेटाबेस में डेटा डाला जा रहा है...',
			'publish'     => 'संपत्तियां और कॉन्फ़िगरेशन प्रकाशित की जा रही हैं...',
			'cache'       => 'कैश साफ़ किया जा रहा है...',
			'finish'      => 'उत्पाद लेबल पैकेज सफलतापूर्वक इंस्टॉल किया गया।',
		],

		'version' => [
			'description' => 'उत्पाद लेबल पैकेज का वर्तमान संस्करण दिखाता है।',
			'comment'     => 'उत्पाद लेबल संस्करण: :version',
		],
	],
];
