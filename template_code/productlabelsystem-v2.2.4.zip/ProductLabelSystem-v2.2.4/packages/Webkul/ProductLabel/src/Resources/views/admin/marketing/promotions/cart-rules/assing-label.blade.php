@php
$labelHelper = app('Webkul\ProductLabel\Helpers\LabelHelper');
@endphp

<div class="box-shadow relative rounded bg-white p-4 dark:bg-gray-900">
	<div class="mb-4 flex justify-between gap-5">
        <div class="flex flex-col gap-2">
            <p class="text-base font-semibold text-gray-800 dark:text-white">
                @lang('productlabel::app.admin.marketing.promotions.cart-rules.label.title')
            </p>

            <p class="text-xs font-medium text-gray-500 dark:text-gray-300">
				@lang('productlabel::app.admin.marketing.promotions.cart-rules.label.info')
            </p>
        </div>
    </div>
    <v-label-assign></v-label-assign>
</div>

@pushOnce('scripts')
	<script
		type="text/x-template"
		id="v-label-assign-template"
		>
		<div class="grid grid-cols-1 gap-4">
			<!-- Panel Content -->
			<div class="flex [&>*]:flex-1 gap-5 justify-between px-4">
				<div>
					<!-- Attributes Groups Header -->
					<div class="mb-4 flex flex-col">
						<p class="font-semibold leading-6 text-gray-600 dark:text-gray-300">
							@lang('productlabel::app.admin.marketing.promotions.cart-rules.label.assigned-labels')
						</p>
					</div>

					<draggable
						class="h-[calc(100vh-285px)] overflow-auto border-gray-200 pb-4 ltr:border-r rtl:border-l"
						ghost-class="draggable-ghost"
						handle=".icon-drag"
						v-bind="{animation: 200}"
						:list="assignedLables"
						item-key="id"
						group="assignedLables"
						:move="onMove"
						@end="onEnd"
					>
						<template #item="{ element, index }">
							<div class="group flex max-w-max gap-1.5 rounded py-1.5 text-gray-600 dark:text-gray-300 ltr:pr-1.5 rtl:pl-1.5">
								<i class="icon-drag cursor-grab text-xl transition-all group-hover:text-gray-800 dark:group-hover:text-white"></i>

								<img
									v-if="element.type == 'image' || element.type == 'icon'"
									class="h-[50px] w-[50px] rounded-[35px]" :src="element.image_path ? '{{ Storage::url('') }}' + element.image_path : '{{ bagisto_asset('images/product-placeholders/front.svg') }}'"
								/>

								<span
									v-else
									class="max-w-max rounded-[35px] px-2.5 py-1.5 text-[12px] font-semibold"
									:style="{ color: element.text_color, backgroundColor: element.background_color }"
									>
									@{{element.text}}
								</span>

								<input
									type="hidden"
									:name="'cartRuleLables[' + element.id + ']'"
									:value="index"
								/>
							</div>
						</template>
					</draggable>
				</div>

				<!-- Unassigned Attributes Container -->
				<div class="">
					<!-- Unassigned Attributes Header -->
					<div class="mb-4 flex flex-col">
						<p class="font-semibold leading-6 text-gray-600 dark:text-gray-300">
							@lang('productlabel::app.admin.marketing.promotions.cart-rules.label.unassigned-labels')
						</p>

						<p class="text-xs font-medium text-gray-800 dark:text-white">
							@lang('productlabel::app.admin.marketing.promotions.cart-rules.label.unassigned-labels-info')
						</p>
					</div>

					<!-- Draggable Unassigned Attributes -->
					<draggable
						id="unassigned-products"
						class="h-[calc(100vh-285px)] overflow-auto pb-4"
						ghost-class="draggable-ghost"
						handle=".icon-drag"
						v-bind="{animation: 200}"
						:list="unAssignedLables"
						item-key="id"
						group="assignedLables"
					>
						<template #item="{ element }">
							<div class="group flex max-w-max gap-1.5 rounded py-1.5 text-gray-600 dark:text-gray-300 ltr:pr-1.5 rtl:pl-1.5">
								<i class="icon-drag cursor-grab text-xl transition-all group-hover:text-gray-800 dark:group-hover:text-white"></i>

								<i class="text-xl transition-all group-hover:text-gray-800 dark:group-hover:text-white"></i>

                    			<img
									v-if="element.type == 'image' || element.type == 'icon'"
									class="h-[50px] w-[50px] rounded-[35px]" :src="element.image_path ? '{{ Storage::url('') }}' + element.image_path : '{{ bagisto_asset('images/product-placeholders/front.svg') }}'"
								/>

								<span
									v-else
									class="max-w-max rounded-[35px] px-2.5 py-1.5 text-[12px] font-semibold"
									:style="{ color: element.text_color, backgroundColor: element.background_color }"
									>
									@{{element.text}}
								</span>
							</div>
						</template>
					</draggable>
				</div>
			</div>
		</div>
	</script>

	<script type="module">
		app.component('v-label-assign', {
			template: '#v-label-assign-template',

			data() {
				return {
					unAssignedLables: @json($labelHelper->getUnAssignedLabels( $cartRule ?? null )),
					assignedLables:@json( isset($cartRule) ? $cartRule->labels : []),
				}
			},

			mounted(){
				console.log('this.unAssignedLables', this.unAssignedLables);


				this.sortData();
			},

			methods: {
				sortData(){
					this.assignedLables = this.assignedLables.sort((a, b) => {
						return a.pivot.sort_order - b.pivot.sort_order;
					});
				}
			}
		})
	</script>
@endPushOnce
