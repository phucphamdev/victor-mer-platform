<?php

return [
    'admin' => [
        'components' => [
            'layouts' => [
                'sidebar' => [
                    'product-label' => 'Labels',
                ],
            ],
        ],

        'label' => [
            'index' => [
                'create-btn' => 'Create Label',
                'title'      => 'Labels',

                'datagrid' => [
                    'id'                  => 'Id',
                    'name'                => 'Name',
                    'label'               => 'Label',
                    'compaign-id'         => 'Compaign Id',
                    'status'              => 'Status',
                    'active'              => 'Active',
                    'inactive'            => 'Inactive',
                    'edit'                => 'Edit',
                    'delete'              => 'Delete',
                    'update-status'       => 'Update Status',
                    'create-success'      => 'Label created succssfully',
                    'mass-update-success' => 'Labels updated successfully',
                    'update-success'      => 'Label updated successfully',
                    'mass-delete-success' => 'Labels delete successfully',
                    'delete-success'      => 'Label delete successfully',

                    'type' => [
                        'title' => 'Type',
                        'image' => 'Image',
                        'icon'  => 'Icon',
                        'text'  => 'Text',
                    ],
                ],
            ],

            'create' => [
                'active'           => 'Active',
                'back-btn'         => 'Back',
                'channel'          => 'Channel',
                'customer-group'   => 'Customer Group',
                'compaign'         => 'Compaign',
                'event'            => 'Event',
                'general'          => 'General',
                'inactive'         => 'Inactive',
                'sort-order'       => 'Priority',
                'save-btn'         => 'Save Label',
                'select-channel'   => 'Select Channel',
                'select-event'     => 'Select Event',
                'select-group'     => 'Select Group',
                'select-status'    => 'Select Status',
                'select-compaign'  => 'Select Compaign',
                'setting'          => 'Setting',
                'status'           => 'Status',
                'subject'          => 'Subject',
                'title'            => 'Create Label',
                'label-name'       => 'Name',
                'label-type'       => 'Type',
                'label-text'       => 'Text',
                'label-text-color' => 'Color',
                'label-bg-color'   => 'Background Color',
                'label-image'      => 'Image',
                'image-width'      => 'Width in (px)',
                'image-height'     => 'Height in (px)',
                'select'           => 'Select',
            ],

            'edit' => [
                'active'           => 'Active',
                'audience'         => 'Audience',
                'back-btn'         => 'Back',
                'channel'          => 'Channel',
                'customer-group'   => 'Customer Group',
                'compaign'         => 'Compaign',
                'event'            => 'Event',
                'general'          => 'General',
                'inactive'         => 'Inactive',
                'sort-order'       => 'Priority',
                'save-btn'         => 'Update',
                'select-event'     => 'Select Event',
                'select-status'    => 'Select Status',
                'select-compaign'  => 'Select Compaign',
                'setting'          => 'Setting',
                'status'           => 'Status',
                'subject'          => 'Subject',
                'title'            => 'Edit Label',
                'label-name'       => 'Name',
                'label-type'       => 'Type',
                'label-text'       => 'Text',
                'label-text-color' => 'Color',
                'label-bg-color'   => 'Background Color',
                'label-image'      => 'Image',
                'image-width'      => 'Width in (px)',
                'image-height'     => 'Height in (px)',
                'select'           => 'Select',
            ],
        ],

        'marketing' => [
            'promotions' => [
                'cart-rules' => [
                    'label' => [
                        'title'                  => 'Product Label',
                        'info'                   => 'Assign label to cart rule',
                        'assigned-labels'        => 'Assigned Labels',
                        'unassigned-labels'      => 'Un-Assigned Labels',
                        'unassigned-labels-info' => 'Drag these labels to add into selected list.',
                    ],
                ]
            ],
        ],
    ],

    'configuration' => [
        'index' => [
            'label' => [
                'info'  => 'Set Product label related settings.',
                'title' => 'Product Label',

                'general' => [
                    'info'  => 'Set product label status.',
                    'title' => 'General',

                    'settings' => [
                        'title'                               => 'General',
                        'info'                                => 'Set Product label related settings.',
                        'status'                              => 'Status',
                        'max-label-show-on-card'              => 'Number of Labels on Product Card',
                        'max-label-show-on-card-info'         => 'Set the maximum number of labels that will be displayed on the product card.',
                        'max-label-show-on-product-view'      => 'Number of Labels on product view page',
                        'max-label-show-on-product-view-info' => 'Specify how many labels should be visible on the product view. set 0 or empty to show all labels relate to product.',
                        'label-image-width'                   => 'Width for label images (in px) for desktop',
                        'label-image-width-info'              => 'Specify the width for label images for desktop',
                        'label-image-heigh'                   => 'Heigh for label images (in px) for desktop',
                        'label-image-heigh-info'              => 'Specify the heigh for label images. for desktop',
                        'mobile-label-image-width'            => 'Width for label images (in px) for mobile',
                        'mobile-label-image-width-info'       => 'Specify the width for label images for mobile',
                        'mobile-label-image-heigh'            => 'Heigh for label images (in px) for mobile',
                        'mobile-label-image-heigh-info'       => 'Specify the heigh for label images for mobile.',
                    ],
                ],
            ],
        ],
    ],

    'commands' => [
        'install' => [
            'description' => 'Install the Product Label package.',
            'migrate'     => 'Migrating all tables into database (will take a while)...',
            'seed'        => 'Seeding data into database...',
            'publish'     => 'Publishing assets and configurations...',
            'cache'       => 'Clearing cache...',
            'finish'      => 'Product Label package installed successfully.',
        ],

        'version' => [
            'description' => 'Displays the current version of the Product Label package.',
            'comment'     => 'Product Label Version: :version',
        ],
    ],

    'validation' => [
        'image_required'        => 'Please upload a product label image when type is set to Image.',
        'priority_unique'       => 'Priority must be unique as the value is already used.',
        'type_required'         => 'The Type field is required.',
    ],
];
