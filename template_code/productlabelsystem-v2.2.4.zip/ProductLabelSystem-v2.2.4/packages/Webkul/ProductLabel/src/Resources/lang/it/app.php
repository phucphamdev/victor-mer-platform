<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'Etichette',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'Crea Etichetta',
				'title'      => 'Etichette',

				'datagrid' => [
					'id'                  => 'ID',
					'name'                => 'Nome',
					'label'               => 'Etichetta',
					'compaign-id'         => 'ID Campagna',
					'status'              => 'Stato',
					'active'              => 'Attivo',
					'inactive'            => 'Inattivo',
					'edit'                => 'Modifica',
					'delete'              => 'Elimina',
					'update-status'       => 'Aggiorna Stato',
					'create-success'      => 'Etichetta creata con successo',
					'mass-update-success' => 'Etichette aggiornate con successo',
					'update-success'      => 'Etichetta aggiornata con successo',
					'mass-delete-success' => 'Etichette eliminate con successo',
					'delete-success'      => 'Etichetta eliminata con successo',

					'type' => [
						'title' => 'Tipo',
						'image' => 'Immagine',
						'icon'  => 'Icona',
						'text'  => 'Testo',
					],
				],
			],

			'create' => [
				'active'           => 'Attivo',
				'back-btn'         => 'Indietro',
				'channel'          => 'Canale',
				'customer-group'   => 'Gruppo Clienti',
				'compaign'         => 'Campagna',
				'event'            => 'Evento',
				'general'          => 'Generale',
				'inactive'         => 'Inattivo',
				'sort-order'       => 'Priorità',
				'save-btn'         => 'Salva Etichetta',
				'select-channel'   => 'Seleziona Canale',
				'select-event'     => 'Seleziona Evento',
				'select-group'     => 'Seleziona Gruppo',
				'select-status'    => 'Seleziona Stato',
				'select-compaign'  => 'Seleziona Campagna',
				'setting'          => 'Impostazioni',
				'status'           => 'Stato',
				'subject'          => 'Oggetto',
				'title'            => 'Crea Etichetta',
				'label-name'       => 'Nome',
				'label-type'       => 'Tipo',
				'label-text'       => 'Testo',
				'label-text-color' => 'Colore Testo',
				'label-bg-color'   => 'Colore Sfondo',
				'label-image'      => 'Immagine',
				'image-width'      => 'Larghezza (px)',
				'image-height'     => 'Altezza (px)',
				'select'           => 'Seleziona',
			],

			'edit' => [
				'active'           => 'Attivo',
				'audience'         => 'Pubblico',
				'back-btn'         => 'Indietro',
				'channel'          => 'Canale',
				'customer-group'   => 'Gruppo Clienti',
				'compaign'         => 'Campagna',
				'event'            => 'Evento',
				'general'          => 'Generale',
				'inactive'         => 'Inattivo',
				'sort-order'       => 'Priorità',
				'save-btn'         => 'Aggiorna',
				'select-event'     => 'Seleziona Evento',
				'select-status'    => 'Seleziona Stato',
				'select-compaign'  => 'Seleziona Campagna',
				'setting'          => 'Impostazioni',
				'status'           => 'Stato',
				'subject'          => 'Oggetto',
				'title'            => 'Modifica Etichetta',
				'label-name'       => 'Nome',
				'label-type'       => 'Tipo',
				'label-text'       => 'Testo',
				'label-text-color' => 'Colore Testo',
				'label-bg-color'   => 'Colore Sfondo',
				'label-image'      => 'Immagine',
				'image-width'      => 'Larghezza (px)',
				'image-height'     => 'Altezza (px)',
				'select'           => 'Seleziona',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'Etichette',
						'info'                   => 'Assegna etichette alla regola del carrello',
						'assigned-labels'        => 'Etichette Assegnate',
						'unassigned-labels'      => 'Etichette Non Assegnate',
						'unassigned-labels-info' => 'Trascina queste etichette per aggiungerle alla lista selezionata.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'Imposta le configurazioni relative alle etichette dei prodotti.',
				'title' => 'Etichetta Prodotto',

				'general' => [
					'info'  => 'Imposta lo stato delle etichette dei prodotti.',
					'title' => 'Generale',

					'settings' => [
						'title'                               => 'Generale',
						'info'                                => 'Configura le impostazioni delle etichette dei prodotti.',
						'status'                              => 'Stato',
						'max-label-show-on-card'              => 'Numero di Etichette su Carta Prodotto',
						'max-label-show-on-card-info'         => 'Imposta il numero massimo di etichette da visualizzare sulla carta del prodotto.',
						'max-label-show-on-product-view'      => 'Numero di Etichette nella Pagina di Dettaglio Prodotto',
						'max-label-show-on-product-view-info' => 'Specifica quante etichette devono essere visibili nella pagina di visualizzazione del prodotto. Imposta 0 o lascia vuoto per mostrare tutte le etichette relative al prodotto.',
						'label-image-width'                   => 'Larghezza dell’immagine dell’etichetta (px) per desktop',
						'label-image-width-info'              => 'Specifica la larghezza dell’immagine dell’etichetta per desktop.',
						'label-image-heigh'                   => 'Altezza dell’immagine dell’etichetta (px) per desktop',
						'label-image-heigh-info'              => 'Specifica l’altezza dell’immagine dell’etichetta per desktop.',
						'mobile-label-image-width'            => 'Larghezza dell’immagine dell’etichetta (px) per mobile',
						'mobile-label-image-width-info'       => 'Specifica la larghezza dell’immagine dell’etichetta per mobile.',
						'mobile-label-image-heigh'            => 'Altezza dell’immagine dell’etichetta (px) per mobile',
						'mobile-label-image-heigh-info'       => 'Specifica l’altezza dell’immagine dell’etichetta per mobile.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'Installa il pacchetto delle etichette dei prodotti.',
			'migrate'     => 'Migrazione di tutte le tabelle nel database (potrebbe richiedere del tempo)...',
			'seed'        => 'Popolamento del database con dati...',
			'publish'     => 'Pubblicazione delle risorse e configurazioni...',
			'cache'       => 'Pulizia della cache...',
			'finish'      => 'Pacchetto delle etichette dei prodotti installato con successo.',
		],

		'version' => [
			'description' => 'Mostra la versione attuale del pacchetto delle etichette dei prodotti.',
			'comment'     => 'Versione Etichette Prodotto: :version',
		],
	],
];
