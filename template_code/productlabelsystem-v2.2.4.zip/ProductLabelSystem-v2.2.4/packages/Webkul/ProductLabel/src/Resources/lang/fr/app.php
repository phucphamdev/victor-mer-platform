<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'Étiquettes',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'Créer une Étiquette',
				'title'      => 'Étiquettes',

				'datagrid' => [
					'id'                  => 'Id',
					'name'                => 'Nom',
					'label'               => 'Étiquette',
					'compaign-id'         => 'Id de Campagne',
					'status'              => 'Statut',
					'active'              => 'Actif',
					'inactive'            => 'Inactif',
					'edit'                => 'Modifier',
					'delete'              => 'Supprimer',
					'update-status'       => 'Mettre à jour le statut',
					'create-success'      => 'Étiquette créée avec succès',
					'mass-update-success' => 'Étiquettes mises à jour avec succès',
					'update-success'      => 'Étiquette mise à jour avec succès',
					'mass-delete-success' => 'Étiquettes supprimées avec succès',
					'delete-success'      => 'Étiquette supprimée avec succès',

					'type' => [
						'title' => 'Type',
						'image' => 'Image',
						'icon'  => 'Icône',
						'text'  => 'Texte',
					],
				],
			],

			'create' => [
				'active'           => 'Actif',
				'back-btn'         => 'Retour',
				'channel'          => 'Canal',
				'customer-group'   => 'Groupe de Clients',
				'compaign'         => 'Campagne',
				'event'            => 'Événement',
				'general'          => 'Général',
				'inactive'         => 'Inactif',
				'sort-order'       => 'Priorité',
				'save-btn'         => 'Enregistrer l\'Étiquette',
				'select-channel'   => 'Sélectionner le Canal',
				'select-event'     => 'Sélectionner l\'Événement',
				'select-group'     => 'Sélectionner le Groupe',
				'select-status'    => 'Sélectionner le Statut',
				'select-compaign'  => 'Sélectionner la Campagne',
				'setting'          => 'Paramètre',
				'status'           => 'Statut',
				'subject'          => 'Sujet',
				'title'            => 'Créer une Étiquette',
				'label-name'       => 'Nom',
				'label-type'       => 'Type',
				'label-text'       => 'Texte',
				'label-text-color' => 'Couleur',
				'label-bg-color'   => 'Couleur d\'arrière-plan',
				'label-image'      => 'Image',
				'image-width'      => 'Largeur en (px)',
				'image-height'     => 'Hauteur en (px)',
				'select'           => 'Sélectionner',
			],

			'edit' => [
				'active'           => 'Actif',
				'audience'         => 'Audience',
				'back-btn'         => 'Retour',
				'channel'          => 'Canal',
				'customer-group'   => 'Groupe de Clients',
				'compaign'         => 'Campagne',
				'event'            => 'Événement',
				'general'          => 'Général',
				'inactive'         => 'Inactif',
				'sort-order'       => 'Priorité',
				'save-btn'         => 'Mettre à jour',
				'select-event'     => 'Sélectionner l\'Événement',
				'select-status'    => 'Sélectionner le Statut',
				'select-compaign'  => 'Sélectionner la Campagne',
				'setting'          => 'Paramètre',
				'status'           => 'Statut',
				'subject'          => 'Sujet',
				'title'            => 'Modifier l\'Étiquette',
				'label-name'       => 'Nom',
				'label-type'       => 'Type',
				'label-text'       => 'Texte',
				'label-text-color' => 'Couleur',
				'label-bg-color'   => 'Couleur d\'arrière-plan',
				'label-image'      => 'Image',
				'image-width'      => 'Largeur en (px)',
				'image-height'     => 'Hauteur en (px)',
				'select'           => 'Sélectionner',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'Étiquettes',
						'info'                   => 'Assigner des étiquettes à la règle du panier',
						'assigned-labels'        => 'Étiquettes Assignées',
						'unassigned-labels'      => 'Étiquettes Non Assignées',
						'unassigned-labels-info' => 'Faites glisser ces étiquettes pour les ajouter à la liste sélectionnée.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'Définir les paramètres liés aux étiquettes de produit.',
				'title' => 'Étiquette de Produit',

				'general' => [
					'info'  => 'Définir le statut de l\'étiquette de produit.',
					'title' => 'Général',

					'settings' => [
						'title'                               => 'Général',
						'info'                                => 'Définir les paramètres liés aux étiquettes de produit.',
						'status'                              => 'Statut',
						'max-label-show-on-card'              => 'Nombre d\'Étiquettes sur la Carte Produit',
						'max-label-show-on-card-info'         => 'Définir le nombre maximum d\'étiquettes qui seront affichées sur la carte produit.',
						'max-label-show-on-product-view'      => 'Nombre d\'Étiquettes sur la page de vue du produit',
						'max-label-show-on-product-view-info' => 'Spécifier combien d\'étiquettes doivent être visibles sur la vue du produit. Mettre 0 ou vide pour afficher toutes les étiquettes liées au produit.',
						'label-image-width'                   => 'Largeur pour les images d\'étiquette (en px) pour bureau',
						'label-image-width-info'              => 'Spécifier la largeur pour les images d\'étiquette pour bureau',
						'label-image-heigh'                   => 'Hauteur pour les images d\'étiquette (en px) pour bureau',
						'label-image-heigh-info'              => 'Spécifier la hauteur pour les images d\'étiquette pour bureau',
						'mobile-label-image-width'            => 'Largeur pour les images d\'étiquette (en px) pour mobile',
						'mobile-label-image-width-info'       => 'Spécifier la largeur pour les images d\'étiquette pour mobile',
						'mobile-label-image-heigh'            => 'Hauteur pour les images d\'étiquette (en px) pour mobile',
						'mobile-label-image-heigh-info'       => 'Spécifier la hauteur pour les images d\'étiquette pour mobile.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'Installer le package d\'Étiquette de Produit.',
			'migrate'     => 'Migration de toutes les tables dans la base de données (prendra un moment)...',
			'seed'        => 'Injection de données dans la base de données...',
			'publish'     => 'Publication des assets et des configurations...',
			'cache'       => 'Nettoyage du cache...',
			'finish'      => 'Package d\'Étiquette de Produit installé avec succès.',
		],

		'version' => [
			'description' => 'Affiche la version actuelle du package d\'Étiquette de Produit.',
			'comment'     => 'Version d\'Étiquette de Produit: :version',
		],
	],
];
