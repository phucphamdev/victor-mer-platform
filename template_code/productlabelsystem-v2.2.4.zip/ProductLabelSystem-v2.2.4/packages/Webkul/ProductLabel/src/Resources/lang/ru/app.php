<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'Ярлыки',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'Создать ярлык',
				'title'      => 'Ярлыки',

				'datagrid' => [
					'id'                  => 'ID',
					'name'                => 'Имя',
					'label'               => 'Ярлык',
					'compaign-id'         => 'ID кампании',
					'status'              => 'Статус',
					'active'              => 'Активный',
					'inactive'            => 'Неактивный',
					'edit'                => 'Редактировать',
					'delete'              => 'Удалить',
					'update-status'       => 'Обновить статус',
					'create-success'      => 'Ярлык успешно создан',
					'mass-update-success' => 'Ярлыки успешно обновлены',
					'update-success'      => 'Ярлык успешно обновлен',
					'mass-delete-success' => 'Ярлыки успешно удалены',
					'delete-success'      => 'Ярлык успешно удален',

					'type' => [
						'title' => 'Тип',
						'image' => 'Изображение',
						'icon'  => 'Иконка',
						'text'  => 'Текст',
					],
				],
			],

			'create' => [
				'active'           => 'Активный',
				'back-btn'         => 'Назад',
				'channel'          => 'Канал',
				'customer-group'   => 'Группа клиентов',
				'compaign'         => 'Кампания',
				'event'            => 'Событие',
				'general'          => 'Общее',
				'inactive'         => 'Неактивный',
				'sort-order'       => 'Приоритет',
				'save-btn'         => 'Сохранить ярлык',
				'select-channel'   => 'Выбрать канал',
				'select-event'     => 'Выбрать событие',
				'select-group'     => 'Выбрать группу',
				'select-status'    => 'Выбрать статус',
				'select-compaign'  => 'Выбрать кампанию',
				'setting'          => 'Настройки',
				'status'           => 'Статус',
				'subject'          => 'Тема',
				'title'            => 'Создать ярлык',
				'label-name'       => 'Название',
				'label-type'       => 'Тип',
				'label-text'       => 'Текст',
				'label-text-color' => 'Цвет текста',
				'label-bg-color'   => 'Цвет фона',
				'label-image'      => 'Изображение',
				'image-width'      => 'Ширина (px)',
				'image-height'     => 'Высота (px)',
				'select'           => 'Выбрать',
			],

			'edit' => [
				'active'           => 'Активный',
				'audience'         => 'Аудитория',
				'back-btn'         => 'Назад',
				'channel'          => 'Канал',
				'customer-group'   => 'Группа клиентов',
				'compaign'         => 'Кампания',
				'event'            => 'Событие',
				'general'          => 'Общее',
				'inactive'         => 'Неактивный',
				'sort-order'       => 'Приоритет',
				'save-btn'         => 'Обновить',
				'select-event'     => 'Выбрать событие',
				'select-status'    => 'Выбрать статус',
				'select-compaign'  => 'Выбрать кампанию',
				'setting'          => 'Настройки',
				'status'           => 'Статус',
				'subject'          => 'Тема',
				'title'            => 'Редактировать ярлык',
				'label-name'       => 'Название',
				'label-type'       => 'Тип',
				'label-text'       => 'Текст',
				'label-text-color' => 'Цвет текста',
				'label-bg-color'   => 'Цвет фона',
				'label-image'      => 'Изображение',
				'image-width'      => 'Ширина (px)',
				'image-height'     => 'Высота (px)',
				'select'           => 'Выбрать',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'Ярлыки',
						'info'                   => 'Назначьте ярлыки для правила корзины',
						'assigned-labels'        => 'Назначенные ярлыки',
						'unassigned-labels'      => 'Неназначенные ярлыки',
						'unassigned-labels-info' => 'Перетащите эти ярлыки, чтобы добавить их в выбранный список.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'Настройки ярлыков продуктов.',
				'title' => 'Ярлыки продукта',

				'general' => [
					'info'  => 'Настройте статус ярлыков продуктов.',
					'title' => 'Общие',

					'settings' => [
						'title'                               => 'Общие',
						'info'                                => 'Настроить параметры ярлыков продуктов.',
						'status'                              => 'Статус',
						'max-label-show-on-card'              => 'Максимальное количество ярлыков на карточке товара',
						'max-label-show-on-card-info'         => 'Укажите максимальное количество ярлыков, которые будут отображаться на карточке товара.',
						'max-label-show-on-product-view'      => 'Максимальное количество ярлыков на странице товара',
						'max-label-show-on-product-view-info' => 'Определите, сколько ярлыков должно отображаться на странице товара. Укажите 0 или оставьте пустым, чтобы отобразить все связанные ярлыки.',
						'label-image-width'                   => 'Ширина изображения ярлыка (px) для компьютеров',
						'label-image-width-info'              => 'Определите ширину изображения ярлыка для компьютеров.',
						'label-image-heigh'                   => 'Высота изображения ярлыка (px) для компьютеров',
						'label-image-heigh-info'              => 'Определите высоту изображения ярлыка для компьютеров.',
						'mobile-label-image-width'            => 'Ширина изображения ярлыка (px) для мобильных устройств',
						'mobile-label-image-width-info'       => 'Определите ширину изображения ярлыка для мобильных устройств.',
						'mobile-label-image-heigh'            => 'Высота изображения ярлыка (px) для мобильных устройств',
						'mobile-label-image-heigh-info'       => 'Определите высоту изображения ярлыка для мобильных устройств.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'Установите пакет ярлыков продуктов.',
			'migrate'     => 'Миграция всех таблиц в базу данных (это может занять некоторое время)...',
			'seed'        => 'Заполнение базы данных...',
			'publish'     => 'Публикация активов и конфигураций...',
			'cache'       => 'Очистка кеша...',
			'finish'      => 'Пакет ярлыков продуктов успешно установлен.',
		],

		'version' => [
			'description' => 'Отображает текущую версию пакета ярлыков продуктов.',
			'comment'     => 'Версия ярлыков продукта: :version',
		],
	],
];
