<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'লেবেলসমূহ',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'লেবেল তৈরি করুন',
				'title'      => 'লেবেলসমূহ',

				'datagrid' => [
					'id'                  => 'আইডি',
					'name'                => 'নাম',
					'label'               => 'লেবেল',
					'compaign-id'         => 'ক্যাম্পেইন আইডি',
					'status'              => 'স্ট্যাটাস',
					'active'              => 'সক্রিয়',
					'inactive'            => 'নিষ্ক্রিয়',
					'edit'                => 'সম্পাদনা করুন',
					'delete'              => 'মুছুন',
					'update-status'       => 'স্ট্যাটাস আপডেট করুন',
					'create-success'      => 'লেবেল সফলভাবে তৈরি করা হয়েছে',
					'mass-update-success' => 'লেবেলসমূহ সফলভাবে আপডেট করা হয়েছে',
					'update-success'      => 'লেবেল সফলভাবে আপডেট করা হয়েছে',
					'mass-delete-success' => 'লেবেলসমূহ সফলভাবে মুছে ফেলা হয়েছে',
					'delete-success'      => 'লেবেল সফলভাবে মুছে ফেলা হয়েছে',

					'type' => [
						'title' => 'ধরন',
						'image' => 'ছবি',
						'icon'  => 'আইকন',
						'text'  => 'পাঠ্য',
					],
				],
			],

			'create' => [
				'active'           => 'সক্রিয়',
				'back-btn'         => 'পিছনে',
				'channel'          => 'চ্যানেল',
				'customer-group'   => 'কাস্টমার গ্রুপ',
				'compaign'         => 'ক্যাম্পেইন',
				'event'            => 'ইভেন্ট',
				'general'          => 'সাধারণ',
				'inactive'         => 'নিষ্ক্রিয়',
				'sort-order'       => 'প্রায়োরিটি',
				'save-btn'         => 'লেবেল সংরক্ষণ করুন',
				'select-channel'   => 'চ্যানেল নির্বাচন করুন',
				'select-event'     => 'ইভেন্ট নির্বাচন করুন',
				'select-group'     => 'গ্রুপ নির্বাচন করুন',
				'select-status'    => 'স্ট্যাটাস নির্বাচন করুন',
				'select-compaign'  => 'ক্যাম্পেইন নির্বাচন করুন',
				'setting'          => 'সেটিং',
				'status'           => 'স্ট্যাটাস',
				'subject'          => 'বিষয়',
				'title'            => 'লেবেল তৈরি করুন',
				'label-name'       => 'নাম',
				'label-type'       => 'ধরন',
				'label-text'       => 'পাঠ্য',
				'label-text-color' => 'রঙ',
				'label-bg-color'   => 'পটভূমির রঙ',
				'label-image'      => 'ছবি',
				'image-width'      => 'প্রস্থ (পিক্সেল)',
				'image-height'     => 'উচ্চতা (পিক্সেল)',
				'select'           => 'নির্বাচন করুন',
			],

			'edit' => [
				'active'           => 'সক্রিয়',
				'audience'         => 'অডিয়েন্স',
				'back-btn'         => 'পিছনে',
				'channel'          => 'চ্যানেল',
				'customer-group'   => 'কাস্টমার গ্রুপ',
				'compaign'         => 'ক্যাম্পেইন',
				'event'            => 'ইভেন্ট',
				'general'          => 'সাধারণ',
				'inactive'         => 'নিষ্ক্রিয়',
				'sort-order'       => 'প্রায়োরিটি',
				'save-btn'         => 'আপডেট করুন',
				'select-event'     => 'ইভেন্ট নির্বাচন করুন',
				'select-status'    => 'স্ট্যাটাস নির্বাচন করুন',
				'select-compaign'  => 'ক্যাম্পেইন নির্বাচন করুন',
				'setting'          => 'সেটিং',
				'status'           => 'স্ট্যাটাস',
				'subject'          => 'বিষয়',
				'title'            => 'লেবেল সম্পাদনা করুন',
				'label-name'       => 'নাম',
				'label-type'       => 'ধরন',
				'label-text'       => 'পাঠ্য',
				'label-text-color' => 'রঙ',
				'label-bg-color'   => 'পটভূমির রঙ',
				'label-image'      => 'ছবি',
				'image-width'      => 'প্রস্থ (পিক্সেল)',
				'image-height'     => 'উচ্চতা (পিক্সেল)',
				'select'           => 'নির্বাচন করুন',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'লেবেলসমূহ',
						'info'                   => 'কার্ট রুলে লেবেল অ্যাসাইন করুন',
						'assigned-labels'        => 'অ্যাসাইন করা লেবেলসমূহ',
						'unassigned-labels'      => 'অ্যাসাইন না করা লেবেলসমূহ',
						'unassigned-labels-info' => 'নির্বাচিত তালিকায় যোগ করতে এই লেবেলগুলি টেনে আনুন।',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'পণ্য লেবেল সম্পর্কিত সেটিংস সেট করুন।',
				'title' => 'পণ্য লেবেল',

				'general' => [
					'info'  => 'পণ্য লেবেল স্ট্যাটাস সেট করুন।',
					'title' => 'সাধারণ',

					'settings' => [
						'title'                               => 'সাধারণ',
						'info'                                => 'পণ্য লেবেল সম্পর্কিত সেটিংস সেট করুন।',
						'status'                              => 'স্ট্যাটাস',
						'max-label-show-on-card'              => 'পণ্য কার্ডে লেবেলের সংখ্যা',
						'max-label-show-on-card-info'         => 'পণ্য কার্ডে প্রদর্শিত হবে এমন লেবেলের সর্বাধিক সংখ্যা সেট করুন।',
						'max-label-show-on-product-view'      => 'পণ্য ভিউ পৃষ্ঠায় লেবেলের সংখ্যা',
						'max-label-show-on-product-view-info' => 'পণ্য ভিউতে কতগুলি লেবেল দৃশ্যমান হওয়া উচিত তা নির্দিষ্ট করুন। পণ্যের সাথে সম্পর্কিত সমস্ত লেবেল দেখাতে 0 বা খালি সেট করুন।',
						'label-image-width'                   => 'ডেস্কটপের জন্য লেবেল ছবির প্রস্থ (পিক্সেলে)',
						'label-image-width-info'              => 'ডেস্কটপের জন্য লেবেল ছবির প্রস্থ নির্দিষ্ট করুন',
						'label-image-heigh'                   => 'ডেস্কটপের জন্য লেবেল ছবির উচ্চতা (পিক্সেলে)',
						'label-image-heigh-info'              => 'ডেস্কটপের জন্য লেবেল ছবির উচ্চতা নির্দিষ্ট করুন',
						'mobile-label-image-width'            => 'মোবাইলের জন্য লেবেল ছবির প্রস্থ (পিক্সেলে)',
						'mobile-label-image-width-info'       => 'মোবাইলের জন্য লেবেল ছবির প্রস্থ নির্দিষ্ট করুন',
						'mobile-label-image-heigh'            => 'মোবাইলের জন্য লেবেল ছবির উচ্চতা (পিক্সেলে)',
						'mobile-label-image-heigh-info'       => 'মোবাইলের জন্য লেবেল ছবির উচ্চতা নির্দিষ্ট করুন।',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'পণ্য লেবেল প্যাকেজ ইনস্টল করুন।',
			'migrate'     => 'ডাটাবেসে সমস্ত টেবিল মাইগ্রেট করা হচ্ছে (সময় লাগবে)...',
			'seed'        => 'ডাটাবেসে ডাটা সিড করা হচ্ছে...',
			'publish'     => 'অ্যাসেট এবং কনফিগারেশন প্রকাশ করা হচ্ছে...',
			'cache'       => 'ক্যাশে পরিষ্কার করা হচ্ছে...',
			'finish'      => 'পণ্য লেবেল প্যাকেজ সফলভাবে ইনস্টল করা হয়েছে।',
		],

		'version' => [
			'description' => 'পণ্য লেবেল প্যাকেজের বর্তমান সংস্করণ প্রদর্শন করে।',
			'comment'     => 'পণ্য লেবেল সংস্করণ: :version',
		],
	],
];
