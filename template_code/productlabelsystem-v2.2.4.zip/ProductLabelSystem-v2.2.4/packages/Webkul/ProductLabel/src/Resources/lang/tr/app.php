<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'Etiketler',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'Etiket Oluştur',
				'title'      => 'Etiketler',

				'datagrid' => [
					'id'                  => 'ID',
					'name'                => 'Ad',
					'label'               => 'Etiket',
					'compaign-id'         => 'Kampanya ID',
					'status'              => 'Durum',
					'active'              => 'Aktif',
					'inactive'            => 'Pasif',
					'edit'                => 'Düzenle',
					'delete'              => 'Sil',
					'update-status'       => 'Durumu Güncelle',
					'create-success'      => 'Etiket başarıyla oluşturuldu',
					'mass-update-success' => 'Etiketler başarıyla güncellendi',
					'update-success'      => 'Etiket başarıyla güncellendi',
					'mass-delete-success' => 'Etiketler başarıyla silindi',
					'delete-success'      => 'Etiket başarıyla silindi',

					'type' => [
						'title' => 'Tür',
						'image' => 'Görsel',
						'icon'  => 'Simge',
						'text'  => 'Metin',
					],
				],
			],

			'create' => [
				'active'           => 'Aktif',
				'back-btn'         => 'Geri',
				'channel'          => 'Kanal',
				'customer-group'   => 'Müşteri Grubu',
				'compaign'         => 'Kampanya',
				'event'            => 'Etkinlik',
				'general'          => 'Genel',
				'inactive'         => 'Pasif',
				'sort-order'       => 'Öncelik',
				'save-btn'         => 'Etiketi Kaydet',
				'select-channel'   => 'Kanal Seç',
				'select-event'     => 'Etkinlik Seç',
				'select-group'     => 'Grup Seç',
				'select-status'    => 'Durum Seç',
				'select-compaign'  => 'Kampanya Seç',
				'setting'          => 'Ayarlar',
				'status'           => 'Durum',
				'subject'          => 'Konu',
				'title'            => 'Etiket Oluştur',
				'label-name'       => 'Ad',
				'label-type'       => 'Tür',
				'label-text'       => 'Metin',
				'label-text-color' => 'Metin Rengi',
				'label-bg-color'   => 'Arka Plan Rengi',
				'label-image'      => 'Görsel',
				'image-width'      => 'Genişlik (px)',
				'image-height'     => 'Yükseklik (px)',
				'select'           => 'Seç',
			],

			'edit' => [
				'active'           => 'Aktif',
				'audience'         => 'Hedef Kitle',
				'back-btn'         => 'Geri',
				'channel'          => 'Kanal',
				'customer-group'   => 'Müşteri Grubu',
				'compaign'         => 'Kampanya',
				'event'            => 'Etkinlik',
				'general'          => 'Genel',
				'inactive'         => 'Pasif',
				'sort-order'       => 'Öncelik',
				'save-btn'         => 'Güncelle',
				'select-event'     => 'Etkinlik Seç',
				'select-status'    => 'Durum Seç',
				'select-compaign'  => 'Kampanya Seç',
				'setting'          => 'Ayarlar',
				'status'           => 'Durum',
				'subject'          => 'Konu',
				'title'            => 'Etiketi Düzenle',
				'label-name'       => 'Ad',
				'label-type'       => 'Tür',
				'label-text'       => 'Metin',
				'label-text-color' => 'Metin Rengi',
				'label-bg-color'   => 'Arka Plan Rengi',
				'label-image'      => 'Görsel',
				'image-width'      => 'Genişlik (px)',
				'image-height'     => 'Yükseklik (px)',
				'select'           => 'Seç',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'Etiketler',
						'info'                   => 'Sepet kuralına etiket ata',
						'assigned-labels'        => 'Atanan Etiketler',
						'unassigned-labels'      => 'Atanmamış Etiketler',
						'unassigned-labels-info' => 'Bu etiketleri seçili listeye eklemek için sürükleyin.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'Ürün etiketi ile ilgili ayarları yapın.',
				'title' => 'Ürün Etiketi',

				'general' => [
					'info'  => 'Ürün etiketi durumunu ayarlayın.',
					'title' => 'Genel',

					'settings' => [
						'title'                               => 'Genel',
						'info'                                => 'Ürün etiketi ile ilgili ayarları yapın.',
						'status'                              => 'Durum',
						'max-label-show-on-card'              => 'Ürün Kartında Gösterilecek Etiket Sayısı',
						'max-label-show-on-card-info'         => 'Ürün kartında görüntülenecek maksimum etiket sayısını belirleyin.',
						'max-label-show-on-product-view'      => 'Ürün Görünüm Sayfasında Gösterilecek Etiket Sayısı',
						'max-label-show-on-product-view-info' => 'Ürün görünüm sayfasında kaç etiketin görünmesi gerektiğini belirtin. Tüm etiketleri göstermek için 0 veya boş bırakın.',
						'label-image-width'                   => 'Masaüstü için etiket görsellerinin genişliği (px)',
						'label-image-width-info'              => 'Masaüstü için etiket görsellerinin genişliğini belirleyin.',
						'label-image-heigh'                   => 'Masaüstü için etiket görsellerinin yüksekliği (px)',
						'label-image-heigh-info'              => 'Masaüstü için etiket görsellerinin yüksekliğini belirleyin.',
						'mobile-label-image-width'            => 'Mobil için etiket görsellerinin genişliği (px)',
						'mobile-label-image-width-info'       => 'Mobil için etiket görsellerinin genişliğini belirleyin.',
						'mobile-label-image-heigh'            => 'Mobil için etiket görsellerinin yüksekliği (px)',
						'mobile-label-image-heigh-info'       => 'Mobil için etiket görsellerinin yüksekliğini belirleyin.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'Ürün Etiketi paketini yükleyin.',
			'migrate'     => 'Tüm tablolar veritabanına taşınıyor (biraz zaman alabilir)...',
			'seed'        => 'Veritabanına veri ekleniyor...',
			'publish'     => 'Varlıklar ve yapılandırmalar yayınlanıyor...',
			'cache'       => 'Önbellek temizleniyor...',
			'finish'      => 'Ürün Etiketi paketi başarıyla yüklendi.',
		],

		'version' => [
			'description' => 'Ürün Etiketi paketinin mevcut sürümünü gösterir.',
			'comment'     => 'Ürün Etiketi Sürümü: :version',
		],
	],
];
