<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'Rótulos',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'Criar Rótulo',
				'title'      => 'Rótulos',

				'datagrid' => [
					'id'                  => 'ID',
					'name'                => 'Nome',
					'label'               => 'Rótulo',
					'compaign-id'         => 'ID da Campanha',
					'status'              => 'Status',
					'active'              => 'Ativo',
					'inactive'            => 'Inativo',
					'edit'                => 'Editar',
					'delete'              => 'Excluir',
					'update-status'       => 'Atualizar Status',
					'create-success'      => 'Rótulo criado com sucesso',
					'mass-update-success' => 'Rótulos atualizados com sucesso',
					'update-success'      => 'Rótulo atualizado com sucesso',
					'mass-delete-success' => 'Rótulos excluídos com sucesso',
					'delete-success'      => 'Rótulo excluído com sucesso',

					'type' => [
						'title' => 'Tipo',
						'image' => 'Imagem',
						'icon'  => 'Ícone',
						'text'  => 'Texto',
					],
				],
			],

			'create' => [
				'active'           => 'Ativo',
				'back-btn'         => 'Voltar',
				'channel'          => 'Canal',
				'customer-group'   => 'Grupo de Clientes',
				'compaign'         => 'Campanha',
				'event'            => 'Evento',
				'general'          => 'Geral',
				'inactive'         => 'Inativo',
				'sort-order'       => 'Prioridade',
				'save-btn'         => 'Salvar Rótulo',
				'select-channel'   => 'Selecionar Canal',
				'select-event'     => 'Selecionar Evento',
				'select-group'     => 'Selecionar Grupo',
				'select-status'    => 'Selecionar Status',
				'select-compaign'  => 'Selecionar Campanha',
				'setting'          => 'Configuração',
				'status'           => 'Status',
				'subject'          => 'Assunto',
				'title'            => 'Criar Rótulo',
				'label-name'       => 'Nome',
				'label-type'       => 'Tipo',
				'label-text'       => 'Texto',
				'label-text-color' => 'Cor do Texto',
				'label-bg-color'   => 'Cor de Fundo',
				'label-image'      => 'Imagem',
				'image-width'      => 'Largura (px)',
				'image-height'     => 'Altura (px)',
				'select'           => 'Selecionar',
			],

			'edit' => [
				'active'           => 'Ativo',
				'audience'         => 'Público',
				'back-btn'         => 'Voltar',
				'channel'          => 'Canal',
				'customer-group'   => 'Grupo de Clientes',
				'compaign'         => 'Campanha',
				'event'            => 'Evento',
				'general'          => 'Geral',
				'inactive'         => 'Inativo',
				'sort-order'       => 'Prioridade',
				'save-btn'         => 'Atualizar',
				'select-event'     => 'Selecionar Evento',
				'select-status'    => 'Selecionar Status',
				'select-compaign'  => 'Selecionar Campanha',
				'setting'          => 'Configuração',
				'status'           => 'Status',
				'subject'          => 'Assunto',
				'title'            => 'Editar Rótulo',
				'label-name'       => 'Nome',
				'label-type'       => 'Tipo',
				'label-text'       => 'Texto',
				'label-text-color' => 'Cor do Texto',
				'label-bg-color'   => 'Cor de Fundo',
				'label-image'      => 'Imagem',
				'image-width'      => 'Largura (px)',
				'image-height'     => 'Altura (px)',
				'select'           => 'Selecionar',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'Rótulos',
						'info'                   => 'Atribuir rótulos à regra do carrinho',
						'assigned-labels'        => 'Rótulos Atribuídos',
						'unassigned-labels'      => 'Rótulos Não Atribuídos',
						'unassigned-labels-info' => 'Arraste estes rótulos para adicioná-los à lista selecionada.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'Definir configurações relacionadas a rótulos de produtos.',
				'title' => 'Rótulo do Produto',

				'general' => [
					'info'  => 'Definir status do rótulo do produto.',
					'title' => 'Geral',

					'settings' => [
						'title'                               => 'Geral',
						'info'                                => 'Definir configurações relacionadas a rótulos de produtos.',
						'status'                              => 'Status',
						'max-label-show-on-card'              => 'Número de rótulos no cartão do produto',
						'max-label-show-on-card-info'         => 'Defina o número máximo de rótulos que serão exibidos no cartão do produto.',
						'max-label-show-on-product-view'      => 'Número de rótulos na página do produto',
						'max-label-show-on-product-view-info' => 'Especifique quantos rótulos devem ser visíveis na página do produto. Defina 0 ou deixe em branco para exibir todos os rótulos relacionados ao produto.',
						'label-image-width'                   => 'Largura da imagem do rótulo (px) para desktop',
						'label-image-width-info'              => 'Especifique a largura da imagem do rótulo para desktop.',
						'label-image-heigh'                   => 'Altura da imagem do rótulo (px) para desktop',
						'label-image-heigh-info'              => 'Especifique a altura da imagem do rótulo para desktop.',
						'mobile-label-image-width'            => 'Largura da imagem do rótulo (px) para dispositivos móveis',
						'mobile-label-image-width-info'       => 'Especifique a largura da imagem do rótulo para dispositivos móveis.',
						'mobile-label-image-heigh'            => 'Altura da imagem do rótulo (px) para dispositivos móveis',
						'mobile-label-image-heigh-info'       => 'Especifique a altura da imagem do rótulo para dispositivos móveis.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'Instale o pacote de rótulos de produtos.',
			'migrate'     => 'Migrando todas as tabelas para o banco de dados (isso pode levar algum tempo)...',
			'seed'        => 'Inserindo dados no banco de dados...',
			'publish'     => 'Publicando ativos e configurações...',
			'cache'       => 'Limpando cache...',
			'finish'      => 'Pacote de rótulos de produtos instalado com sucesso.',
		],

		'version' => [
			'description' => 'Exibe a versão atual do pacote de rótulos de produtos.',
			'comment'     => 'Versão do rótulo do produto: :version',
		],
	],
];
