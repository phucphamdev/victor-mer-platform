@php
	$labelHelper = app('Webkul\ProductLabel\Helpers\LabelHelper');
	$limit = core()->getConfigData('labels.general.settings.max-label-show-on-product-view');
	$labelProduct = $product;

	if (in_array($labelProduct->type, ['bundle', 'configurable', 'grouped'])) {
		$labelProduct->price = $product->getTypeInstance()->getMinimalPrice();
	}

	$label = $labelHelper->getproductLabels($labelProduct, $limit);

	$productVariantLabels = $product->type == 'configurable' ? $labelHelper->getConfigurableProdcutLabels($product, $limit) : null;
@endphp

<v-product-gallery-labels> </v-product-gallery-labels>

@pushOnce('scripts')
    <script
        type="text/x-template"
        id="v-product-gallery-labels-template"
    	>
		<template v-if="labels">
			<div>
				<div
					v-if="labels['top-left']"
					class="absolute top-1.5 mx-1 z-[1]">
					<div class="relative h-[400px] overflow-x-auto">
						<div v-for="label in labels['top-left']">
							<p
								v-if="label.type == 'text'"
								class="inline-block rounded-[44px] px-2.5 text-sm mb-2 max-sm:rounded-l-none max-sm:rounded-r-xl max-sm:px-2 max-sm:py-0.5 max-sm:text-xs ltr:left-1.5 max-sm:ltr:left-0 rtl:right-5 max-sm:rtl:right-0"
								:ruleId="label.pivot.cart_rule_id"
								:style="{ color: label.text_color, backgroundColor: label.background_color }"
								>
								@{{ label.text }}
							</p>

							<img
								v-if="(label.type == 'image' || label.type == 'icon') && label.image_path"
								class="rounded-[44px] mb-2"
								:src="'{{ Storage::url('') }}' + label.image_path"
								:alt="label.pivot.cart_rule_id"
								:ruleId="label.pivot.cart_rule_id"
								:style="{ width: (label.image_width ?? labelImageWidth) + 'px', height: (label.image_height ?? labelImageheight) + 'px' }"
								/>
						</div>
					</div>
				</div>
			</div>
		</template>
	</script>
	<script type="module">
        app.component('v-product-gallery-labels', {
            template: '#v-product-gallery-labels-template',

            data() {
                return {
					labels: @json($label),
					product: @json($product),
					productVariantLabels:@json($productVariantLabels),
					labelImageWidth:"{{core()->getConfigData('labels.general.settings.label-image-width')}}",
					labelImageheight:"{{core()->getConfigData('labels.general.settings.label-image-heigh')}}",
					limit: '{{$limit}}',
					params: {
						limit: '{{$limit}}',
						variant_id: null,
						action: 'card',
					},
                }
            },

			mounted(){
				this.params.product_id = this.product.id;
				this.params.product_type = this.product.type;

				this.groupLabelsByPosition(this.labels);

				if(this.product.type == 'bundle'){
					this.CalculateBundleProductPrice();
				}

                this.$emitter.on('configurable-variant-selected-event', this.configurableProduct);
                this.$emitter.on('bundle-config-final-price', this.updateBundleProductPrice);
			},

			methods:{
				groupLabelsByPosition(data){
					this.labels = data.reduce((acc, curr) => {
						acc[curr.position] = acc[curr.position] || [];
						acc[curr.position].push(curr);
						return acc;
					}, {});
				},

				getLabels() {
					this.$axios.get("{{ route('shop.api.product.labels') }}", {
						params: {
							query:{
								...this.params,
							}
						}
					}).then((response) => {
						if (response.data) {
							this.labels = response.data.data;
							this.groupLabelsByPosition(this.labels);
						}
					}).catch((error) => {
						console.error('Error fetching labels:', error);
					});
				},

				configurableProduct(variant_id){
					if(variant_id){
						this.params.variant_id = variant_id;
						this.getLabels();
					}
				},

				updateBundleProductPrice(price){
					this.params.newPrice = price
					this.getLabels();
				},

				CalculateBundleProductPrice(){
					let configData = @json(app('Webkul\Product\Helpers\BundleOption')->getBundleConfig($product));
					let bundleOption = [];

					for (var key in configData.options) {
                        bundleOption.push(configData.options[key]);
                    }

					var total = 0;

					for (var key in bundleOption) {
						for (var key1 in bundleOption[key].products) {
							if (! bundleOption[key].products[key1].is_default)
								continue;

							total += bundleOption[key].products[key1].qty * bundleOption[key].products[key1].price.final.price;
						}
					}

					this.updateBundleProductPrice(total);
				},
			}
		});
	</script>
@endpushOnce

