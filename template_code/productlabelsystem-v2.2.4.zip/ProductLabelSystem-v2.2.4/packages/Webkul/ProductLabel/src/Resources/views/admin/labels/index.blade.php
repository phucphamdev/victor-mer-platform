<x-admin::layouts>
    <x-slot:title>
        @lang('productlabel::app.admin.label.index.title')
    </x-slot>

    <div class="flex justify-between gap-4 max-sm:flex-wrap">
        <p class="text-xl font-bold text-gray-800 dark:text-white">
            @lang('productlabel::app.admin.label.index.title')
        </p>

        <div class="flex items-center gap-x-2.5">
            @if (bouncer()->hasPermission('marketing.communications.campaigns.create'))
                <a href="{{ route('admin.product_label.create') }}">
                    <div class="primary-button">
                        @lang('productlabel::app.admin.label.index.create-btn')
                    </div>
                </a>
            @endif
        </div>
    </div>

    {!! view_render_event('bagisto.admin.marketing.communications.campaigns.list.before') !!}

    <x-admin::datagrid :src="route('admin.product_label.index')" />

    {!! view_render_event('bagisto.admin.marketing.communications.campaigns.list.after') !!}

</x-admin::layouts>
