<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'Labels',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'Label aanmaken',
				'title'      => 'Labels',

				'datagrid' => [
					'id'                  => 'ID',
					'name'                => 'Naam',
					'label'               => 'Label',
					'compaign-id'         => 'Campagne ID',
					'status'              => 'Status',
					'active'              => 'Actief',
					'inactive'            => 'Inactief',
					'edit'                => 'Bewerken',
					'delete'              => 'Verwijderen',
					'update-status'       => 'Status bijwerken',
					'create-success'      => 'Label succesvol aangemaakt',
					'mass-update-success' => 'Labels succesvol bijgewerkt',
					'update-success'      => 'Label succesvol bijgewerkt',
					'mass-delete-success' => 'Labels succesvol verwijderd',
					'delete-success'      => 'Label succesvol verwijderd',

					'type' => [
						'title' => 'Type',
						'image' => 'Afbeelding',
						'icon'  => 'Icoon',
						'text'  => 'Tekst',
					],
				],
			],

			'create' => [
				'active'           => 'Actief',
				'back-btn'         => 'Terug',
				'channel'          => 'Kanaal',
				'customer-group'   => 'Klantengroep',
				'compaign'         => 'Campagne',
				'event'            => 'Evenement',
				'general'          => 'Algemeen',
				'inactive'         => 'Inactief',
				'sort-order'       => 'Prioriteit',
				'save-btn'         => 'Label opslaan',
				'select-channel'   => 'Selecteer kanaal',
				'select-event'     => 'Selecteer evenement',
				'select-group'     => 'Selecteer groep',
				'select-status'    => 'Selecteer status',
				'select-compaign'  => 'Selecteer campagne',
				'setting'          => 'Instellingen',
				'status'           => 'Status',
				'subject'          => 'Onderwerp',
				'title'            => 'Label aanmaken',
				'label-name'       => 'Naam',
				'label-type'       => 'Type',
				'label-text'       => 'Tekst',
				'label-text-color' => 'Tekstkleur',
				'label-bg-color'   => 'Achtergrondkleur',
				'label-image'      => 'Afbeelding',
				'image-width'      => 'Breedte (px)',
				'image-height'     => 'Hoogte (px)',
				'select'           => 'Selecteren',
			],

			'edit' => [
				'active'           => 'Actief',
				'audience'         => 'Doelgroep',
				'back-btn'         => 'Terug',
				'channel'          => 'Kanaal',
				'customer-group'   => 'Klantengroep',
				'compaign'         => 'Campagne',
				'event'            => 'Evenement',
				'general'          => 'Algemeen',
				'inactive'         => 'Inactief',
				'sort-order'       => 'Prioriteit',
				'save-btn'         => 'Bijwerken',
				'select-event'     => 'Selecteer evenement',
				'select-status'    => 'Selecteer status',
				'select-compaign'  => 'Selecteer campagne',
				'setting'          => 'Instellingen',
				'status'           => 'Status',
				'subject'          => 'Onderwerp',
				'title'            => 'Label bewerken',
				'label-name'       => 'Naam',
				'label-type'       => 'Type',
				'label-text'       => 'Tekst',
				'label-text-color' => 'Tekstkleur',
				'label-bg-color'   => 'Achtergrondkleur',
				'label-image'      => 'Afbeelding',
				'image-width'      => 'Breedte (px)',
				'image-height'     => 'Hoogte (px)',
				'select'           => 'Selecteren',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'Labels',
						'info'                   => 'Labels toewijzen aan winkelwagenregel',
						'assigned-labels'        => 'Toegewezen labels',
						'unassigned-labels'      => 'Niet-toegewezen labels',
						'unassigned-labels-info' => 'Sleep deze labels om ze toe te voegen aan de geselecteerde lijst.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'Instellingen voor productlabels configureren.',
				'title' => 'Productlabel',

				'general' => [
					'info'  => 'Stel de status van productlabels in.',
					'title' => 'Algemeen',

					'settings' => [
						'title'                               => 'Algemeen',
						'info'                                => 'Stel productlabelinstellingen in.',
						'status'                              => 'Status',
						'max-label-show-on-card'              => 'Aantal labels op productkaart',
						'max-label-show-on-card-info'         => 'Stel het maximale aantal labels in dat op de productkaart wordt weergegeven.',
						'max-label-show-on-product-view'      => 'Aantal labels op productpagina',
						'max-label-show-on-product-view-info' => 'Specificeer hoeveel labels zichtbaar moeten zijn op de productpagina. Stel in op 0 of laat leeg om alle labels weer te geven.',
						'label-image-width'                   => 'Breedte van labelafbeeldingen (px) voor desktop',
						'label-image-width-info'              => 'Specificeer de breedte van de labelafbeeldingen voor desktop.',
						'label-image-heigh'                   => 'Hoogte van labelafbeeldingen (px) voor desktop',
						'label-image-heigh-info'              => 'Specificeer de hoogte van de labelafbeeldingen voor desktop.',
						'mobile-label-image-width'            => 'Breedte van labelafbeeldingen (px) voor mobiel',
						'mobile-label-image-width-info'       => 'Specificeer de breedte van de labelafbeeldingen voor mobiel.',
						'mobile-label-image-heigh'            => 'Hoogte van labelafbeeldingen (px) voor mobiel',
						'mobile-label-image-heigh-info'       => 'Specificeer de hoogte van de labelafbeeldingen voor mobiel.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'Installeer het productlabelpakket.',
			'migrate'     => 'Alle tabellen migreren naar de database (dit kan even duren)...',
			'seed'        => 'Data wordt ingevoerd in de database...',
			'publish'     => 'Publiceren van assets en configuraties...',
			'cache'       => 'Cache wordt gewist...',
			'finish'      => 'Productlabelpakket succesvol geïnstalleerd.',
		],

		'version' => [
			'description' => 'Geeft de huidige versie van het productlabelpakket weer.',
			'comment'     => 'Productlabelversie: :version',
		],
	],
];
