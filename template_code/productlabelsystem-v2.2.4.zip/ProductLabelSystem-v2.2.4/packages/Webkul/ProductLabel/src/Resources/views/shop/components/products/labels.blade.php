

<v-product-card-labels
    :product="product"
	:labels="labels"
>
</v-product-card-labels>

@pushOnce('scripts')
    <script
        type="text/x-template"
        id="v-product-card-labels-template"
    	>
		<template v-if="labels">
			<div
				v-if="labels['top-left']"
				class="absolute top-1.5 mx-1"
				>
				<div v-for="label in labels['top-left']">
					<p
						v-if="label.type == 'text'"
						class="inline-block rounded-[44px] px-2.5 text-sm mb-2 max-sm:rounded-l-none max-sm:rounded-r-xl max-sm:px-2 max-sm:py-0.5 max-sm:text-xs ltr:left-1.5 max-sm:ltr:left-0 rtl:right-5 max-sm:rtl:right-0"
						:ruleId="label.pivot.cart_rule_id"
						:style="{ color: label.text_color, backgroundColor: label.background_color }"
						>
						@{{ label.text }}
					</p>

					<img
						v-if="(label.type == 'image' || label.type == 'icon') && label.image_path"
						class="rounded-[44px] mb-2 max-1180:hidden"
						:src="'{{ Storage::url('') }}' + label.image_path"
						:alt="label.pivot.cart_rule_id"
						:ruleId="label.pivot.cart_rule_id"
					    :style="{ width: (label.image_width ?? labelImageWidth) + 'px', height: (label.image_height ?? labelImageheight) + 'px' }"
						/>

					<img
						v-if="(label.type == 'image' || label.type == 'icon') && label.image_path"
						class="rounded-[44px] mb-2 1180:hidden"
						:src="'{{ Storage::url('') }}' + label.image_path"
						:alt="label.pivot.cart_rule_id"
						:ruleId="label.pivot.cart_rule_id"
					    :style="{ width: (mobileLabelImageWidth ?? 40) + 'px', height: (mobileLabelImageheight ?? 40) + 'px' }"
						/>
				</div>
			</div>
		</template>
	</script>
	<script type="module">
        app.component('v-product-card-labels', {
            template: '#v-product-card-labels-template',

            props: ['product', 'labels'],

            data() {
                return {
					labels: null,
					labelImageWidth:"{{core()->getConfigData('labels.general.settings.label-image-width')}}",
					labelImageheight:"{{core()->getConfigData('labels.general.settings.label-image-heigh')}}",
					mobileLabelImageWidth:"{{core()->getConfigData('labels.general.settings.mobile-label-image-width')}}",
					mobileLabelImageheight:"{{core()->getConfigData('labels.general.settings.mobile-label-image-heigh')}}",
                }
            },

			mounted(){
				this.groupLabelsByPosition();
			},

			methods:{
				groupLabelsByPosition(){
					this.labels = this.product.labels.reduce((acc, curr) => {
						acc[curr.position] = acc[curr.position] || [];
						acc[curr.position].push(curr);
						return acc;
					}, {});
				}
			}
		});
	</script>
@endpushOnce

