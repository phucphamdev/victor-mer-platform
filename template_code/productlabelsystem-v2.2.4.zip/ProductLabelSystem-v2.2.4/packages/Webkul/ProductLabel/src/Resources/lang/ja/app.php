<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'ラベル',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'ラベルを作成',
				'title'      => 'ラベル',

				'datagrid' => [
					'id'                  => 'ID',
					'name'                => '名前',
					'label'               => 'ラベル',
					'compaign-id'         => 'キャンペーンID',
					'status'              => 'ステータス',
					'active'              => 'アクティブ',
					'inactive'            => '非アクティブ',
					'edit'                => '編集',
					'delete'              => '削除',
					'update-status'       => 'ステータスを更新',
					'create-success'      => 'ラベルが正常に作成されました',
					'mass-update-success' => 'ラベルが正常に更新されました',
					'update-success'      => 'ラベルが正常に更新されました',
					'mass-delete-success' => 'ラベルが正常に削除されました',
					'delete-success'      => 'ラベルが正常に削除されました',

					'type' => [
						'title' => 'タイプ',
						'image' => '画像',
						'icon'  => 'アイコン',
						'text'  => 'テキスト',
					],
				],
			],

			'create' => [
				'active'           => 'アクティブ',
				'back-btn'         => '戻る',
				'channel'          => 'チャネル',
				'customer-group'   => '顧客グループ',
				'compaign'         => 'キャンペーン',
				'event'            => 'イベント',
				'general'          => '一般',
				'inactive'         => '非アクティブ',
				'sort-order'       => '優先順位',
				'save-btn'         => 'ラベルを保存',
				'select-channel'   => 'チャネルを選択',
				'select-event'     => 'イベントを選択',
				'select-group'     => 'グループを選択',
				'select-status'    => 'ステータスを選択',
				'select-compaign'  => 'キャンペーンを選択',
				'setting'          => '設定',
				'status'           => 'ステータス',
				'subject'          => '件名',
				'title'            => 'ラベルを作成',
				'label-name'       => '名前',
				'label-type'       => 'タイプ',
				'label-text'       => 'テキスト',
				'label-text-color' => 'テキストカラー',
				'label-bg-color'   => '背景色',
				'label-image'      => '画像',
				'image-width'      => '幅 (px)',
				'image-height'     => '高さ (px)',
				'select'           => '選択',
			],

			'edit' => [
				'active'           => 'アクティブ',
				'audience'         => 'オーディエンス',
				'back-btn'         => '戻る',
				'channel'          => 'チャネル',
				'customer-group'   => '顧客グループ',
				'compaign'         => 'キャンペーン',
				'event'            => 'イベント',
				'general'          => '一般',
				'inactive'         => '非アクティブ',
				'sort-order'       => '優先順位',
				'save-btn'         => '更新',
				'select-event'     => 'イベントを選択',
				'select-status'    => 'ステータスを選択',
				'select-compaign'  => 'キャンペーンを選択',
				'setting'          => '設定',
				'status'           => 'ステータス',
				'subject'          => '件名',
				'title'            => 'ラベルを編集',
				'label-name'       => '名前',
				'label-type'       => 'タイプ',
				'label-text'       => 'テキスト',
				'label-text-color' => 'テキストカラー',
				'label-bg-color'   => '背景色',
				'label-image'      => '画像',
				'image-width'      => '幅 (px)',
				'image-height'     => '高さ (px)',
				'select'           => '選択',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'ラベル',
						'info'                   => 'カートルールにラベルを割り当てる',
						'assigned-labels'        => '割り当て済みラベル',
						'unassigned-labels'      => '未割り当てラベル',
						'unassigned-labels-info' => 'これらのラベルをドラッグして、選択リストに追加してください。',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => '商品ラベルに関する設定を行います。',
				'title' => '商品ラベル',

				'general' => [
					'info'  => '商品ラベルのステータスを設定します。',
					'title' => '一般',

					'settings' => [
						'title'                               => '一般',
						'info'                                => '商品ラベルの設定を行います。',
						'status'                              => 'ステータス',
						'max-label-show-on-card'              => '商品カードに表示されるラベルの最大数',
						'max-label-show-on-card-info'         => '商品カードに表示されるラベルの最大数を設定します。',
						'max-label-show-on-product-view'      => '商品詳細ページに表示されるラベルの数',
						'max-label-show-on-product-view-info' => '商品詳細ページに表示するラベルの数を指定します。0または空欄の場合、すべての関連ラベルを表示します。',
						'label-image-width'                   => 'デスクトップ用ラベル画像の幅 (px)',
						'label-image-width-info'              => 'デスクトップ用のラベル画像の幅を指定します。',
						'label-image-heigh'                   => 'デスクトップ用ラベル画像の高さ (px)',
						'label-image-heigh-info'              => 'デスクトップ用のラベル画像の高さを指定します。',
						'mobile-label-image-width'            => 'モバイル用ラベル画像の幅 (px)',
						'mobile-label-image-width-info'       => 'モバイル用のラベル画像の幅を指定します。',
						'mobile-label-image-heigh'            => 'モバイル用ラベル画像の高さ (px)',
						'mobile-label-image-heigh-info'       => 'モバイル用のラベル画像の高さを指定します。',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => '商品ラベルパッケージをインストールします。',
			'migrate'     => 'データベースにすべてのテーブルを移行中（少し時間がかかります）...',
			'seed'        => 'データベースにデータを投入中...',
			'publish'     => 'アセットと設定を公開中...',
			'cache'       => 'キャッシュをクリア中...',
			'finish'      => '商品ラベルパッケージが正常にインストールされました。',
		],

		'version' => [
			'description' => '商品ラベルパッケージの現在のバージョンを表示します。',
			'comment'     => '商品ラベルバージョン: :version',
		],
	],
];
