<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'العلامات',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'إنشاء علامة',
				'title'      => 'العلامات',

				'datagrid' => [
					'id'                  => 'المعرف',
					'name'                => 'الاسم',
					'label'               => 'العلامة',
					'compaign-id'         => 'معرف الحملة',
					'status'              => 'الحالة',
					'active'              => 'نشط',
					'inactive'            => 'غير نشط',
					'edit'                => 'تعديل',
					'delete'              => 'حذف',
					'update-status'       => 'تحديث الحالة',
					'create-success'      => 'تم إنشاء العلامة بنجاح',
					'mass-update-success' => 'تم تحديث العلامات بنجاح',
					'update-success'      => 'تم تحديث العلامة بنجاح',
					'mass-delete-success' => 'تم حذف العلامات بنجاح',
					'delete-success'      => 'تم حذف العلامة بنجاح',

					'type' => [
						'title' => 'النوع',
						'image' => 'صورة',
						'icon'  => 'أيقونة',
						'text'  => 'نص',
					],
				],
			],

			'create' => [
				'active'           => 'نشط',
				'back-btn'         => 'رجوع',
				'channel'          => 'القناة',
				'customer-group'   => 'مجموعة العملاء',
				'compaign'         => 'الحملة',
				'event'            => 'الحدث',
				'general'          => 'عام',
				'inactive'         => 'غير نشط',
				'sort-order'       => 'الأولوية',
				'save-btn'         => 'حفظ العلامة',
				'select-channel'   => 'اختر القناة',
				'select-event'     => 'اختر الحدث',
				'select-group'     => 'اختر المجموعة',
				'select-status'    => 'اختر الحالة',
				'select-compaign'  => 'اختر الحملة',
				'setting'          => 'الإعدادات',
				'status'           => 'الحالة',
				'subject'          => 'الموضوع',
				'title'            => 'إنشاء علامة',
				'label-name'       => 'الاسم',
				'label-type'       => 'النوع',
				'label-text'       => 'النص',
				'label-text-color' => 'اللون',
				'label-bg-color'   => 'لون الخلفية',
				'label-image'      => 'الصورة',
				'image-width'      => 'العرض بالبكسل',
				'image-height'     => 'الارتفاع بالبكسل',
				'select'           => 'اختر',
			],

			'edit' => [
				'active'           => 'نشط',
				'audience'         => 'الجمهور',
				'back-btn'         => 'رجوع',
				'channel'          => 'القناة',
				'customer-group'   => 'مجموعة العملاء',
				'compaign'         => 'الحملة',
				'event'            => 'الحدث',
				'general'          => 'عام',
				'inactive'         => 'غير نشط',
				'sort-order'       => 'الأولوية',
				'save-btn'         => 'تحديث',
				'select-event'     => 'اختر الحدث',
				'select-status'    => 'اختر الحالة',
				'select-compaign'  => 'اختر الحملة',
				'setting'          => 'الإعدادات',
				'status'           => 'الحالة',
				'subject'          => 'الموضوع',
				'title'            => 'تعديل العلامة',
				'label-name'       => 'الاسم',
				'label-type'       => 'النوع',
				'label-text'       => 'النص',
				'label-text-color' => 'اللون',
				'label-bg-color'   => 'لون الخلفية',
				'label-image'      => 'الصورة',
				'image-width'      => 'العرض بالبكسل',
				'image-height'     => 'الارتفاع بالبكسل',
				'select'           => 'اختر',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'العلامات',
						'info'                   => 'تعيين العلامات لقاعدة السلة',
						'assigned-labels'        => 'العلامات المعينة',
						'unassigned-labels'      => 'العلامات غير المعينة',
						'unassigned-labels-info' => 'اسحب هذه العلامات لإضافتها إلى القائمة المحددة.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'تعيين إعدادات علامة المنتج.',
				'title' => 'علامة المنتج',

				'general' => [
					'info'  => 'تعيين حالة علامة المنتج.',
					'title' => 'عام',

					'settings' => [
						'title'                               => 'عام',
						'info'                                => 'تعيين إعدادات علامة المنتج.',
						'status'                              => 'الحالة',
						'max-label-show-on-card'              => 'عدد العلامات على بطاقة المنتج',
						'max-label-show-on-card-info'         => 'تعيين الحد الأقصى لعدد العلامات التي سيتم عرضها على بطاقة المنتج.',
						'max-label-show-on-product-view'      => 'عدد العلامات على صفحة عرض المنتج',
						'max-label-show-on-product-view-info' => 'حدد عدد العلامات التي يجب أن تكون مرئية على صفحة عرض المنتج. ضع 0 أو فارغًا لإظهار جميع العلامات المتعلقة بالمنتج.',
						'label-image-width'                   => 'عرض صور العلامة (بالبكسل) للكمبيوتر',
						'label-image-width-info'              => 'حدد عرض صور العلامة للكمبيوتر',
						'label-image-heigh'                   => 'ارتفاع صور العلامة (بالبكسل) للكمبيوتر',
						'label-image-heigh-info'              => 'حدد ارتفاع صور العلامة للكمبيوتر',
						'mobile-label-image-width'            => 'عرض صور العلامة (بالبكسل) للجوال',
						'mobile-label-image-width-info'       => 'حدد عرض صور العلامة للجوال',
						'mobile-label-image-heigh'            => 'ارتفاع صور العلامة (بالبكسل) للجوال',
						'mobile-label-image-heigh-info'       => 'حدد ارتفاع صور العلامة للجوال.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'تثبيت حزمة علامة المنتج.',
			'migrate'     => 'ترحيل جميع الجداول إلى قاعدة البيانات (سيستغرق بعض الوقت)...',
			'seed'        => 'بذر البيانات في قاعدة البيانات...',
			'publish'     => 'نشر الأصول والتكوينات...',
			'cache'       => 'مسح ذاكرة التخزين المؤقت...',
			'finish'      => 'تم تثبيت حزمة علامة المنتج بنجاح.',
		],

		'version' => [
			'description' => 'عرض الإصدار الحالي من حزمة علامة المنتج.',
			'comment'     => 'إصدار علامة المنتج: :version',
		],
	],
];
