<x-admin::layouts>
    <x-slot:title>
        @lang('productlabel::app.admin.label.create.title')
    </x-slot>

    <v-label-create></v-label-create>

    @pushOnce('scripts')
        <script
            type="text/x-template"
            id="v-label-create-template"
        >
             {!! view_render_event('bagisto.admin.label.create.before') !!}

            <!-- Input Form -->
            <x-admin::form
                :action="route('admin.product_label.store')"
                enctype="multipart/form-data"
                >

                {!! view_render_event('bagisto.admin.label.create.create_form_controls.before') !!}

                <div class="flex items-center justify-between">
                    <p class="text-xl font-bold text-gray-800 dark:text-white">
                        @lang('productlabel::app.admin.label.create.title')
                    </p>

                    <div class="flex items-center gap-x-2.5">
                        <!-- Back Button -->
                        <a
                            href="{{ route('admin.product_label.index') }}"
                            class="transparent-button hover:bg-gray-200 dark:text-white dark:hover:bg-gray-800"
                        >
                            @lang('productlabel::app.admin.label.create.back-btn')
                        </a>

                        <!-- Save Button -->
                        <button
                            type="submit"
                            class="primary-button"
                        >
                            @lang('productlabel::app.admin.label.create.save-btn')
                        </button>
                    </div>
                </div>
                <!-- Information -->
                <div class="mt-3.5 flex gap-2.5 max-xl:flex-wrap">
                    <!-- Left Section -->
                    <div class="flex flex-1 flex-col gap-2 max-xl:flex-auto">

                        {!! view_render_event('bagisto.admin.label.create.card.general.before') !!}

                        <!-- General Section -->
                        <div class="box-shadow rounded bg-white p-4 dark:bg-gray-900">
                            <p class="mb-4 text-base font-semibold text-gray-800 dark:text-white">
                                @lang('productlabel::app.admin.label.create.general')
                            </p>

                            <div class="mb-2.5">
                                <input
                                    type="hidden"
                                    name="position"
                                    value="top-left"
                                    />

                                <!-- Name of the label -->
                                <x-admin::form.control-group>
                                    <x-admin::form.control-group.label class="required">
                                        @lang('productlabel::app.admin.label.create.label-name')
                                    </x-admin::form.control-group.label>

                                    <x-admin::form.control-group.control
                                        type="text"
                                        name="name"
                                        rules="required"
                                        :value="old('name') ?? ''"
                                        :label="trans('productlabel::app.admin.label.create.label-name')"
                                        :placeholder="trans('productlabel::app.admin.label.create.label-name')"
                                    />

                                    <x-admin::form.control-group.error control-name="name" />
                                </x-admin::form.control-group>

                                <!-- sort order | position -->
                                <x-admin::form.control-group>
                                    <x-admin::form.control-group.label class="required">
                                        @lang('productlabel::app.admin.label.create.sort-order')
                                    </x-admin::form.control-group.label>

                                    <x-admin::form.control-group.control
                                        type="text"
                                        name="sort_order"
                                        rules="required|integer"
                                        :value="old('sort_order')"
                                        :label="trans('productlabel::app.admin.label.create.sort-order')"
                                        :placeholder="trans('productlabel::app.admin.label.create.sort-order')"
                                    />

                                    <x-admin::form.control-group.error control-name="sort_order" />
                                </x-admin::form.control-group>

                                <!-- Lable type -->
                                <x-admin::form.control-group class="">
                                    <x-admin::form.control-group.label class="required">
                                        @lang('productlabel::app.admin.label.create.label-type')
                                    </x-admin::form.control-group.label>

                                    <x-admin::form.control-group.control
                                        type="select"
                                        name="type"
                                        rules="required"
                                        class="cursor-pointer"
                                        :value="old('type')"
                                        v-model="type.code"
                                    >
                                        <!-- Default Option -->
                                        <option value="">
                                            @lang('productlabel::app.admin.label.create.select')
                                        </option>

                                        <option
                                            v-for="(type, index) in types"
                                            :value="type.code"
                                            >
                                            @{{ type.label }}
                                        </option>
                                    </x-admin::form.control-group.control>

                                    <x-admin::form.control-group.error control-name="type" />
                                </x-admin::form.control-group>


                                <div v-if="type.code == 'text'">
                                    <!-- Lable Text -->
                                    <x-admin::form.control-group>
                                        <x-admin::form.control-group.label class="required">
                                            @lang('productlabel::app.admin.label.create.label-text')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="text"
                                            name="text"
                                            rules="required|max:50"
                                            :value="old('text') ?? ''"
                                            :label="trans('productlabel::app.admin.label.create.label-text')"
                                            :placeholder="trans('productlabel::app.admin.label.create.label-text')"
                                        />
                                        <x-admin::form.control-group.error 
                                            control-name="text" 
                                            class="text-red-600 mt-1 text-sm"
                                        />
                                    </x-admin::form.control-group>

                                    <!-- Text color -->
                                    <x-admin::form.control-group class="w-2/6">
                                        <x-admin::form.control-group.label>
                                            @lang('productlabel::app.admin.label.create.label-text-color')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="color"
                                            name="text_color"
                                            :placeholder="trans('productlabel::app.admin.label.create.label-text-color')"
                                            :value="old('text_color') ?? '#000000'"
                                        />

                                        <x-admin::form.control-group.error control-name="text_color" />
                                    </x-admin::form.control-group>

                                    <!-- Background Color -->
                                    <x-admin::form.control-group class="w-2/6">
                                        <x-admin::form.control-group.label>
                                            @lang('productlabel::app.admin.label.create.label-bg-color')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="color"
                                            name="background_color"
                                            :placeholder="trans('productlabel::app.admin.label.create.label-bg-color')"
                                            :value="old('background_color') ?? '#a7aaaf'"
                                        />

                                        <x-admin::form.control-group.error control-name="background_color" />
                                    </x-admin::form.control-group>
                                </div>

                                <div v-if="type.code == 'image' || type.code == 'icon'">
                                    <x-admin::form.control-group>
                                        <x-admin::form.control-group.label>
                                            @lang('productlabel::app.admin.label.create.image-width')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="text"
                                            name="image_width"
                                            rules="integer"
                                            :value="old('image_width')"
                                            :label="trans('productlabel::app.admin.label.create.image-width')"
                                            :placeholder="trans('productlabel::app.admin.label.create.image-width')"
                                        />

                                        <x-admin::form.control-group.error control-name="image_width" />
                                    </x-admin::form.control-group>

                                    <x-admin::form.control-group>
                                        <x-admin::form.control-group.label>
                                            @lang('productlabel::app.admin.label.create.image-height')
                                        </x-admin::form.control-group.label>

                                        <x-admin::form.control-group.control
                                            type="text"
                                            name="image_height"
                                            rules="integer"
                                            :value="old('image_height')"
                                            :label="trans('productlabel::app.admin.label.create.image-height')"
                                            :placeholder="trans('productlabel::app.admin.label.create.image-height')"
                                        />

                                        <x-admin::form.control-group.error control-name="image_height" />
                                    </x-admin::form.control-group>

                                    <!-- Lable Image -->
                                    <div class="flex flex-col gap-2 w-[40%] mt-5">
                                        <p class="text-gray-800 dark:text-white font-medium">
                                            @lang('productlabel::app.admin.label.create.label-image')
                                        </p>

                                        <x-admin::media.images name="image" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        {!! view_render_event('bagisto.admin.label.create.card.general.after') !!}
                    </div>

                    <!-- Right Section -->
                    <div class="flex w-[360px] max-w-full flex-col gap-2 max-md:w-full">

                        {!! view_render_event('bagisto.admin.label.create.card.accordion.setting.before') !!}

                        <!-- Setting -->
                        <x-admin::accordion>
                            <x-slot:header>
                                <p class="p-2.5 text-base font-semibold text-gray-800 dark:text-white">
                                    @lang('productlabel::app.admin.label.create.setting')
                                </p>
                            </x-slot>

                            <x-slot:content>
                                <!-- Status -->
                                <x-admin::form.control-group class="!mb-0">
                                    <x-admin::form.control-group.label>
                                        @lang('productlabel::app.admin.label.create.status')
                                    </x-admin::form.control-group.label>

                                    <x-admin::form.control-group.control
                                        type="switch"
                                        name="status"
                                        value="1"
                                        :label="trans('productlabel::app.admin.label.create.status')"
                                        :checked="(bool) old('status') ?? false"
                                    />

                                </x-admin::form.control-group>
                            </x-slot>
                        </x-admin::accordion>

                        {!! view_render_event('bagisto.admin.label.create.card.accordion.setting.after') !!}
                    </div>
                </div>

                {!! view_render_event('bagisto.admin.label.create.create_form_controls.after') !!}

            </x-admin::form>

            {!! view_render_event('bagisto.admin.label.create.after') !!}
        </script>
        <script type="module">
            app.component('v-label-create', {
                template: '#v-label-create-template',

                data() {
                    return {
                        validated: false,
                        types: [
                                {
                                    'code': 'text',
                                    label: @json(trans('productlabel::app.admin.label.index.datagrid.type.text')),
                                },
                                {
                                    'code': 'image',
                                    label: @json(trans('productlabel::app.admin.label.index.datagrid.type.image')),

                                },
                            ],
                        type: {
                            'code': null,
                            'label': null,
                        },
                        oldData: @json( old() ),
                    };
                },

                mounted(){
                    if(this.oldData.type){
                        this.type = this.types.find( (type) => type.code == this.oldData.type);
                    }
                },
            });
        </script>

    @endPushOnce

</x-admin::layouts>
