<?php

return [
    'admin' => [
        'components' => [
            'layouts' => [
                'sidebar' => [
                    'product-label' => 'Etiketten',
                ],
            ],
        ],

        'label' => [
            'index' => [
                'create-btn' => 'Etikett erstellen',
                'title'      => 'Etiketten',

                'datagrid' => [
                    'id'                  => 'ID',
                    'name'                => 'Name',
                    'label'               => 'Etikett',
                    'compaign-id'         => 'Kampagnen-ID',
                    'status'              => 'Status',
                    'active'              => 'Aktiv',
                    'inactive'            => 'Inaktiv',
                    'edit'                => 'Bearbeiten',
                    'delete'              => 'Löschen',
                    'update-status'       => 'Status aktualisieren',
                    'create-success'      => 'Etikett erfolgreich erstellt',
                    'mass-update-success' => 'Etiketten erfolgreich aktualisiert',
                    'update-success'      => 'Etikett erfolgreich aktualisiert',
                    'mass-delete-success' => 'Etiketten erfolgreich gelöscht',
                    'delete-success'      => 'Etikett erfolgreich gelöscht',

                    'type' => [
                        'title' => 'Typ',
                        'image' => 'Bild',
                        'icon'  => 'Symbol',
                        'text'  => 'Text',
                    ],
                ],
            ],

            'create' => [
                'active'           => 'Aktiv',
                'back-btn'         => 'Zurück',
                'channel'          => 'Kanal',
                'customer-group'   => 'Kundengruppe',
                'compaign'         => 'Kampagne',
                'event'            => 'Ereignis',
                'general'          => 'Allgemein',
                'inactive'         => 'Inaktiv',
                'sort-order'       => 'Priorität',
                'save-btn'         => 'Etikett speichern',
                'select-channel'   => 'Kanal auswählen',
                'select-event'     => 'Ereignis auswählen',
                'select-group'     => 'Gruppe auswählen',
                'select-status'    => 'Status auswählen',
                'select-compaign'  => 'Kampagne auswählen',
                'setting'          => 'Einstellung',
                'status'           => 'Status',
                'subject'          => 'Betreff',
                'title'            => 'Etikett erstellen',
                'label-name'       => 'Name',
                'label-type'       => 'Typ',
                'label-text'       => 'Text',
                'label-text-color' => 'Farbe',
                'label-bg-color'   => 'Hintergrundfarbe',
                'label-image'      => 'Bild',
                'image-width'      => 'Breite (px)',
                'image-height'     => 'Höhe (px)',
                'select'           => 'Auswählen',
            ],

            'edit' => [
                'active'           => 'Aktiv',
                'audience'         => 'Zielgruppe',
                'back-btn'         => 'Zurück',
                'channel'          => 'Kanal',
                'customer-group'   => 'Kundengruppe',
                'compaign'         => 'Kampagne',
                'event'            => 'Ereignis',
                'general'          => 'Allgemein',
                'inactive'         => 'Inaktiv',
                'sort-order'       => 'Priorität',
                'save-btn'         => 'Aktualisieren',
                'select-event'     => 'Ereignis auswählen',
                'select-status'    => 'Status auswählen',
                'select-compaign'  => 'Kampagne auswählen',
                'setting'          => 'Einstellung',
                'status'           => 'Status',
                'subject'          => 'Betreff',
                'title'            => 'Etikett bearbeiten',
                'label-name'       => 'Name',
                'label-type'       => 'Typ',
                'label-text'       => 'Text',
                'label-text-color' => 'Farbe',
                'label-bg-color'   => 'Hintergrundfarbe',
                'label-image'      => 'Bild',
                'image-width'      => 'Breite (px)',
                'image-height'     => 'Höhe (px)',
                'select'           => 'Auswählen',
            ],
        ],

        'marketing' => [
            'promotions' => [
                'cart-rules' => [
                    'label' => [
                        'title'                  => 'Etiketten',
                        'info'                   => 'Etiketten für Warenkorb-Regeln zuweisen',
                        'assigned-labels'        => 'Zugewiesene Etiketten',
                        'unassigned-labels'      => 'Nicht zugewiesene Etiketten',
                        'unassigned-labels-info' => 'Ziehen Sie diese Etiketten, um sie der ausgewählten Liste hinzuzufügen.',
                    ],
                ]
            ],
        ],
    ],

    'configuration' => [
        'index' => [
            'label' => [
                'info'  => 'Einstellungen für Produktetiketten festlegen.',
                'title' => 'Produktetikett',

                'general' => [
                    'info'  => 'Status der Produktetiketten festlegen.',
                    'title' => 'Allgemein',

                    'settings' => [
                        'title'                               => 'Allgemein',
                        'info'                                => 'Einstellungen für Produktetiketten festlegen.',
                        'status'                              => 'Status',
                        'max-label-show-on-card'              => 'Maximale Anzahl der Etiketten auf der Produktkarte',
                        'max-label-show-on-card-info'         => 'Legen Sie die maximale Anzahl der Etiketten fest, die auf der Produktkarte angezeigt werden.',
                        'max-label-show-on-product-view'      => 'Maximale Anzahl der Etiketten auf der Produktansicht',
                        'max-label-show-on-product-view-info' => 'Geben Sie an, wie viele Etiketten auf der Produktansicht angezeigt werden sollen. Setzen Sie 0 oder lassen Sie es leer, um alle zugehörigen Etiketten anzuzeigen.',
                        'label-image-width'                   => 'Breite des Etikettenbildes (px) für Desktop',
                        'label-image-width-info'              => 'Geben Sie die Breite des Etikettenbildes für Desktop an.',
                        'label-image-heigh'                   => 'Höhe des Etikettenbildes (px) für Desktop',
                        'label-image-heigh-info'              => 'Geben Sie die Höhe des Etikettenbildes für Desktop an.',
                        'mobile-label-image-width'            => 'Breite des Etikettenbildes (px) für Mobilgeräte',
                        'mobile-label-image-width-info'       => 'Geben Sie die Breite des Etikettenbildes für Mobilgeräte an.',
                        'mobile-label-image-heigh'            => 'Höhe des Etikettenbildes (px) für Mobilgeräte',
                        'mobile-label-image-heigh-info'       => 'Geben Sie die Höhe des Etikettenbildes für Mobilgeräte an.',
                    ],
                ],
            ],
        ],
    ],

    'commands' => [
        'install' => [
            'description' => 'Produktetiketten-Paket installieren.',
            'migrate'     => 'Alle Tabellen in die Datenbank migrieren (dauert einige Zeit)...',
            'seed'        => 'Daten in die Datenbank einfügen...',
            'publish'     => 'Assets und Konfigurationen veröffentlichen...',
            'cache'       => 'Cache leeren...',
            'finish'      => 'Produktetiketten-Paket erfolgreich installiert.',
        ],

        'version' => [
            'description' => 'Zeigt die aktuelle Version des Produktetiketten-Pakets an.',
            'comment'     => 'Produktetiketten-Version: :version',
        ],
    ],
];
