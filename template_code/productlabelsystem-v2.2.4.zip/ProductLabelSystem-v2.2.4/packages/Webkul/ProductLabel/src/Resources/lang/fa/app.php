<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'برچسب‌ها',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'ایجاد برچسب',
				'title'      => 'برچسب‌ها',

				'datagrid' => [
					'id'                  => 'شناسه',
					'name'                => 'نام',
					'label'               => 'برچسب',
					'compaign-id'         => 'شناسه کمپین',
					'status'              => 'وضعیت',
					'active'              => 'فعال',
					'inactive'            => 'غیرفعال',
					'edit'                => 'ویرایش',
					'delete'              => 'حذف',
					'update-status'       => 'به‌روزرسانی وضعیت',
					'create-success'      => 'برچسب با موفقیت ایجاد شد',
					'mass-update-success' => 'برچسب‌ها با موفقیت به‌روزرسانی شدند',
					'update-success'      => 'برچسب با موفقیت به‌روزرسانی شد',
					'mass-delete-success' => 'برچسب‌ها با موفقیت حذف شدند',
					'delete-success'      => 'برچسب با موفقیت حذف شد',

					'type' => [
						'title' => 'نوع',
						'image' => 'تصویر',
						'icon'  => 'آیکون',
						'text'  => 'متن',
					],
				],
			],

			'create' => [
				'active'           => 'فعال',
				'back-btn'         => 'بازگشت',
				'channel'          => 'کانال',
				'customer-group'   => 'گروه مشتری',
				'compaign'         => 'کمپین',
				'event'            => 'رویداد',
				'general'          => 'عمومی',
				'inactive'         => 'غیرفعال',
				'sort-order'       => 'اولویت',
				'save-btn'         => 'ذخیره برچسب',
				'select-channel'   => 'انتخاب کانال',
				'select-event'     => 'انتخاب رویداد',
				'select-group'     => 'انتخاب گروه',
				'select-status'    => 'انتخاب وضعیت',
				'select-compaign'  => 'انتخاب کمپین',
				'setting'          => 'تنظیمات',
				'status'           => 'وضعیت',
				'subject'          => 'موضوع',
				'title'            => 'ایجاد برچسب',
				'label-name'       => 'نام',
				'label-type'       => 'نوع',
				'label-text'       => 'متن',
				'label-text-color' => 'رنگ',
				'label-bg-color'   => 'رنگ پس‌زمینه',
				'label-image'      => 'تصویر',
				'image-width'      => 'عرض به (پیکسل)',
				'image-height'     => 'ارتفاع به (پیکسل)',
				'select'           => 'انتخاب',
			],

			'edit' => [
				'active'           => 'فعال',
				'audience'         => 'مخاطبین',
				'back-btn'         => 'بازگشت',
				'channel'          => 'کانال',
				'customer-group'   => 'گروه مشتری',
				'compaign'         => 'کمپین',
				'event'            => 'رویداد',
				'general'          => 'عمومی',
				'inactive'         => 'غیرفعال',
				'sort-order'       => 'اولویت',
				'save-btn'         => 'به‌روزرسانی',
				'select-event'     => 'انتخاب رویداد',
				'select-status'    => 'انتخاب وضعیت',
				'select-compaign'  => 'انتخاب کمپین',
				'setting'          => 'تنظیمات',
				'status'           => 'وضعیت',
				'subject'          => 'موضوع',
				'title'            => 'ویرایش برچسب',
				'label-name'       => 'نام',
				'label-type'       => 'نوع',
				'label-text'       => 'متن',
				'label-text-color' => 'رنگ',
				'label-bg-color'   => 'رنگ پس‌زمینه',
				'label-image'      => 'تصویر',
				'image-width'      => 'عرض به (پیکسل)',
				'image-height'     => 'ارتفاع به (پیکسل)',
				'select'           => 'انتخاب',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'برچسب‌ها',
						'info'                   => 'اختصاص برچسب‌ها به قوانین سبد خرید',
						'assigned-labels'        => 'برچسب‌های اختصاص داده شده',
						'unassigned-labels'      => 'برچسب‌های اختصاص داده نشده',
						'unassigned-labels-info' => 'این برچسب‌ها را بکشید تا به لیست انتخاب شده اضافه شوند.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'تنظیمات مربوط به برچسب محصول را تعیین کنید.',
				'title' => 'برچسب محصول',

				'general' => [
					'info'  => 'وضعیت برچسب محصول را تعیین کنید.',
					'title' => 'عمومی',

					'settings' => [
						'title'                               => 'عمومی',
						'info'                                => 'تنظیمات مربوط به برچسب محصول را تعیین کنید.',
						'status'                              => 'وضعیت',
						'max-label-show-on-card'              => 'تعداد برچسب‌ها در کارت محصول',
						'max-label-show-on-card-info'         => 'حداکثر تعداد برچسب‌هایی که در کارت محصول نمایش داده می‌شوند را تعیین کنید.',
						'max-label-show-on-product-view'      => 'تعداد برچسب‌ها در صفحه نمایش محصول',
						'max-label-show-on-product-view-info' => 'مشخص کنید چند برچسب باید در نمای محصول قابل مشاهده باشد. 0 یا خالی را برای نمایش تمام برچسب‌های مرتبط با محصول تنظیم کنید.',
						'label-image-width'                   => 'عرض تصاویر برچسب (به پیکسل) برای دسکتاپ',
						'label-image-width-info'              => 'عرض تصاویر برچسب برای دسکتاپ را مشخص کنید',
						'label-image-heigh'                   => 'ارتفاع تصاویر برچسب (به پیکسل) برای دسکتاپ',
						'label-image-heigh-info'              => 'ارتفاع تصاویر برچسب برای دسکتاپ را مشخص کنید',
						'mobile-label-image-width'            => 'عرض تصاویر برچسب (به پیکسل) برای موبایل',
						'mobile-label-image-width-info'       => 'عرض تصاویر برچسب برای موبایل را مشخص کنید',
						'mobile-label-image-heigh'            => 'ارتفاع تصاویر برچسب (به پیکسل) برای موبایل',
						'mobile-label-image-heigh-info'       => 'ارتفاع تصاویر برچسب برای موبایل را مشخص کنید.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'نصب بسته برچسب محصول.',
			'migrate'     => 'در حال انتقال تمام جداول به پایگاه داده (مدتی طول خواهد کشید)...',
			'seed'        => 'در حال بذرپاشی داده‌ها در پایگاه داده...',
			'publish'     => 'در حال انتشار دارایی‌ها و پیکربندی‌ها...',
			'cache'       => 'در حال پاکسازی حافظه نهان...',
			'finish'      => 'بسته برچسب محصول با موفقیت نصب شد.',
		],

		'version' => [
			'description' => 'نمایش نسخه فعلی بسته برچسب محصول.',
			'comment'     => 'نسخه برچسب محصول: :version',
		],
	],
];
