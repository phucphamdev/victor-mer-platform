<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'Etiquetas',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'Crear Etiqueta',
				'title'      => 'Etiquetas',

				'datagrid' => [
					'id'                  => 'Id',
					'name'                => 'Nombre',
					'label'               => 'Etiqueta',
					'compaign-id'         => 'Id de Campaña',
					'status'              => 'Estado',
					'active'              => 'Activo',
					'inactive'            => 'Inactivo',
					'edit'                => 'Editar',
					'delete'              => 'Eliminar',
					'update-status'       => 'Actualizar Estado',
					'create-success'      => 'Etiqueta creada con éxito',
					'mass-update-success' => 'Etiquetas actualizadas con éxito',
					'update-success'      => 'Etiqueta actualizada con éxito',
					'mass-delete-success' => 'Etiquetas eliminadas con éxito',
					'delete-success'      => 'Etiqueta eliminada con éxito',

					'type' => [
						'title' => 'Tipo',
						'image' => 'Imagen',
						'icon'  => 'Icono',
						'text'  => 'Texto',
					],
				],
			],

			'create' => [
				'active'           => 'Activo',
				'back-btn'         => 'Atrás',
				'channel'          => 'Canal',
				'customer-group'   => 'Grupo de Clientes',
				'compaign'         => 'Campaña',
				'event'            => 'Evento',
				'general'          => 'General',
				'inactive'         => 'Inactivo',
				'sort-order'       => 'Prioridad',
				'save-btn'         => 'Guardar Etiqueta',
				'select-channel'   => 'Seleccionar Canal',
				'select-event'     => 'Seleccionar Evento',
				'select-group'     => 'Seleccionar Grupo',
				'select-status'    => 'Seleccionar Estado',
				'select-compaign'  => 'Seleccionar Campaña',
				'setting'          => 'Configuración',
				'status'           => 'Estado',
				'subject'          => 'Asunto',
				'title'            => 'Crear Etiqueta',
				'label-name'       => 'Nombre',
				'label-type'       => 'Tipo',
				'label-text'       => 'Texto',
				'label-text-color' => 'Color',
				'label-bg-color'   => 'Color de Fondo',
				'label-image'      => 'Imagen',
				'image-width'      => 'Ancho en (px)',
				'image-height'     => 'Alto en (px)',
				'select'           => 'Seleccionar',
			],

			'edit' => [
				'active'           => 'Activo',
				'audience'         => 'Audiencia',
				'back-btn'         => 'Atrás',
				'channel'          => 'Canal',
				'customer-group'   => 'Grupo de Clientes',
				'compaign'         => 'Campaña',
				'event'            => 'Evento',
				'general'          => 'General',
				'inactive'         => 'Inactivo',
				'sort-order'       => 'Prioridad',
				'save-btn'         => 'Actualizar',
				'select-event'     => 'Seleccionar Evento',
				'select-status'    => 'Seleccionar Estado',
				'select-compaign'  => 'Seleccionar Campaña',
				'setting'          => 'Configuración',
				'status'           => 'Estado',
				'subject'          => 'Asunto',
				'title'            => 'Editar Etiqueta',
				'label-name'       => 'Nombre',
				'label-type'       => 'Tipo',
				'label-text'       => 'Texto',
				'label-text-color' => 'Color',
				'label-bg-color'   => 'Color de Fondo',
				'label-image'      => 'Imagen',
				'image-width'      => 'Ancho en (px)',
				'image-height'     => 'Alto en (px)',
				'select'           => 'Seleccionar',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'Etiquetas',
						'info'                   => 'Asignar etiquetas a la regla del carrito',
						'assigned-labels'        => 'Etiquetas Asignadas',
						'unassigned-labels'      => 'Etiquetas No Asignadas',
						'unassigned-labels-info' => 'Arrastre estas etiquetas para añadirlas a la lista seleccionada.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'Establecer configuraciones relacionadas con etiquetas de producto.',
				'title' => 'Etiqueta de Producto',

				'general' => [
					'info'  => 'Establecer estado de etiqueta de producto.',
					'title' => 'General',

					'settings' => [
						'title'                               => 'General',
						'info'                                => 'Establecer configuraciones relacionadas con etiquetas de producto.',
						'status'                              => 'Estado',
						'max-label-show-on-card'              => 'Número de Etiquetas en Tarjeta de Producto',
						'max-label-show-on-card-info'         => 'Establecer el número máximo de etiquetas que se mostrarán en la tarjeta de producto.',
						'max-label-show-on-product-view'      => 'Número de Etiquetas en la página de vista de producto',
						'max-label-show-on-product-view-info' => 'Especificar cuántas etiquetas deben ser visibles en la vista del producto. Establecer 0 o vacío para mostrar todas las etiquetas relacionadas con el producto.',
						'label-image-width'                   => 'Ancho para imágenes de etiqueta (en px) para escritorio',
						'label-image-width-info'              => 'Especificar el ancho para imágenes de etiqueta para escritorio',
						'label-image-heigh'                   => 'Alto para imágenes de etiqueta (en px) para escritorio',
						'label-image-heigh-info'              => 'Especificar el alto para imágenes de etiqueta para escritorio',
						'mobile-label-image-width'            => 'Ancho para imágenes de etiqueta (en px) para móvil',
						'mobile-label-image-width-info'       => 'Especificar el ancho para imágenes de etiqueta para móvil',
						'mobile-label-image-heigh'            => 'Alto para imágenes de etiqueta (en px) para móvil',
						'mobile-label-image-heigh-info'       => 'Especificar el alto para imágenes de etiqueta para móvil.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'Instalar el paquete de Etiqueta de Producto.',
			'migrate'     => 'Migrando todas las tablas a la base de datos (tomará un tiempo)...',
			'seed'        => 'Sembrando datos en la base de datos...',
			'publish'     => 'Publicando assets y configuraciones...',
			'cache'       => 'Limpiando caché...',
			'finish'      => 'Paquete de Etiqueta de Producto instalado con éxito.',
		],

		'version' => [
			'description' => 'Muestra la versión actual del paquete de Etiqueta de Producto.',
			'comment'     => 'Versión de Etiqueta de Producto: :version',
		],
	],
];
