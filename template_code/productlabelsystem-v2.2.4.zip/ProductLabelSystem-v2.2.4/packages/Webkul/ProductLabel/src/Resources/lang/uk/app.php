<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'Мітки',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'Створити мітку',
				'title'      => 'Мітки',

				'datagrid' => [
					'id'                  => 'ID',
					'name'                => 'Ім’я',
					'label'               => 'Мітка',
					'compaign-id'         => 'ID кампанії',
					'status'              => 'Статус',
					'active'              => 'Активний',
					'inactive'            => 'Неактивний',
					'edit'                => 'Редагувати',
					'delete'              => 'Видалити',
					'update-status'       => 'Оновити статус',
					'create-success'      => 'Мітку успішно створено',
					'mass-update-success' => 'Мітки успішно оновлено',
					'update-success'      => 'Мітку успішно оновлено',
					'mass-delete-success' => 'Мітки успішно видалено',
					'delete-success'      => 'Мітку успішно видалено',

					'type' => [
						'title' => 'Тип',
						'image' => 'Зображення',
						'icon'  => 'Іконка',
						'text'  => 'Текст',
					],
				],
			],

			'create' => [
				'active'           => 'Активний',
				'back-btn'         => 'Назад',
				'channel'          => 'Канал',
				'customer-group'   => 'Група клієнтів',
				'compaign'         => 'Кампанія',
				'event'            => 'Подія',
				'general'          => 'Загальні',
				'inactive'         => 'Неактивний',
				'sort-order'       => 'Пріоритет',
				'save-btn'         => 'Зберегти мітку',
				'select-channel'   => 'Виберіть канал',
				'select-event'     => 'Виберіть подію',
				'select-group'     => 'Виберіть групу',
				'select-status'    => 'Виберіть статус',
				'select-compaign'  => 'Виберіть кампанію',
				'setting'          => 'Налаштування',
				'status'           => 'Статус',
				'subject'          => 'Тема',
				'title'            => 'Створити мітку',
				'label-name'       => 'Ім’я',
				'label-type'       => 'Тип',
				'label-text'       => 'Текст',
				'label-text-color' => 'Колір тексту',
				'label-bg-color'   => 'Колір фону',
				'label-image'      => 'Зображення',
				'image-width'      => 'Ширина (px)',
				'image-height'     => 'Висота (px)',
				'select'           => 'Вибрати',
			],

			'edit' => [
				'active'           => 'Активний',
				'audience'         => 'Аудиторія',
				'back-btn'         => 'Назад',
				'channel'          => 'Канал',
				'customer-group'   => 'Група клієнтів',
				'compaign'         => 'Кампанія',
				'event'            => 'Подія',
				'general'          => 'Загальні',
				'inactive'         => 'Неактивний',
				'sort-order'       => 'Пріоритет',
				'save-btn'         => 'Оновити',
				'select-event'     => 'Виберіть подію',
				'select-status'    => 'Виберіть статус',
				'select-compaign'  => 'Виберіть кампанію',
				'setting'          => 'Налаштування',
				'status'           => 'Статус',
				'subject'          => 'Тема',
				'title'            => 'Редагувати мітку',
				'label-name'       => 'Ім’я',
				'label-type'       => 'Тип',
				'label-text'       => 'Текст',
				'label-text-color' => 'Колір тексту',
				'label-bg-color'   => 'Колір фону',
				'label-image'      => 'Зображення',
				'image-width'      => 'Ширина (px)',
				'image-height'     => 'Висота (px)',
				'select'           => 'Вибрати',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'Мітки',
						'info'                   => 'Призначте мітки для правил кошика',
						'assigned-labels'        => 'Призначені мітки',
						'unassigned-labels'      => 'Непризначені мітки',
						'unassigned-labels-info' => 'Перетягніть ці мітки, щоб додати їх до вибраного списку.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'Налаштування міток товару.',
				'title' => 'Мітка товару',

				'general' => [
					'info'  => 'Налаштування статусу мітки товару.',
					'title' => 'Загальні',

					'settings' => [
						'title'                               => 'Загальні',
						'info'                                => 'Налаштування міток товару.',
						'status'                              => 'Статус',
						'max-label-show-on-card'              => 'Кількість міток на картці товару',
						'max-label-show-on-card-info'         => 'Встановіть максимальну кількість міток, які будуть відображатися на картці товару.',
						'max-label-show-on-product-view'      => 'Кількість міток на сторінці перегляду товару',
						'max-label-show-on-product-view-info' => 'Вкажіть, скільки міток має відображатися на сторінці перегляду товару. Встановіть 0 або залиште порожнім, щоб показати всі пов’язані мітки.',
						'label-image-width'                   => 'Ширина зображення мітки (в пікселях) для ПК',
						'label-image-width-info'              => 'Вкажіть ширину зображення мітки для ПК.',
						'label-image-heigh'                   => 'Висота зображення мітки (в пікселях) для ПК',
						'label-image-heigh-info'              => 'Вкажіть висоту зображення мітки для ПК.',
						'mobile-label-image-width'            => 'Ширина зображення мітки (в пікселях) для мобільних пристроїв',
						'mobile-label-image-width-info'       => 'Вкажіть ширину зображення мітки для мобільних пристроїв.',
						'mobile-label-image-heigh'            => 'Висота зображення мітки (в пікселях) для мобільних пристроїв',
						'mobile-label-image-heigh-info'       => 'Вкажіть висоту зображення мітки для мобільних пристроїв.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'Встановлення пакета міток товару.',
			'migrate'     => 'Міграція всіх таблиць у базу даних (це займе деякий час)...',
			'seed'        => 'Заповнення бази даних...',
			'publish'     => 'Публікація ресурсів і конфігурацій...',
			'cache'       => 'Очищення кешу...',
			'finish'      => 'Пакет міток товару успішно встановлено.',
		],

		'version' => [
			'description' => 'Відображає поточну версію пакета міток товару.',
			'comment'     => 'Версія міток товару: :version',
		],
	],
];
