<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'תוויות',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'צור תווית',
				'title'      => 'תוויות',

				'datagrid' => [
					'id'                  => 'מזהה',
					'name'                => 'שם',
					'label'               => 'תווית',
					'compaign-id'         => 'מזהה קמפיין',
					'status'              => 'מצב',
					'active'              => 'פעיל',
					'inactive'            => 'לא פעיל',
					'edit'                => 'ערוך',
					'delete'              => 'מחק',
					'update-status'       => 'עדכן מצב',
					'create-success'      => 'התווית נוצרה בהצלחה',
					'mass-update-success' => 'התוויות עודכנו בהצלחה',
					'update-success'      => 'התווית עודכנה בהצלחה',
					'mass-delete-success' => 'התוויות נמחקו בהצלחה',
					'delete-success'      => 'התווית נמחקה בהצלחה',

					'type' => [
						'title' => 'סוג',
						'image' => 'תמונה',
						'icon'  => 'סמל',
						'text'  => 'טקסט',
					],
				],
			],

			'create' => [
				'active'           => 'פעיל',
				'back-btn'         => 'חזור',
				'channel'          => 'ערוץ',
				'customer-group'   => 'קבוצת לקוחות',
				'compaign'         => 'קמפיין',
				'event'            => 'אירוע',
				'general'          => 'כללי',
				'inactive'         => 'לא פעיל',
				'sort-order'       => 'עדיפות',
				'save-btn'         => 'שמור תווית',
				'select-channel'   => 'בחר ערוץ',
				'select-event'     => 'בחר אירוע',
				'select-group'     => 'בחר קבוצה',
				'select-status'    => 'בחר מצב',
				'select-compaign'  => 'בחר קמפיין',
				'setting'          => 'הגדרה',
				'status'           => 'מצב',
				'subject'          => 'נושא',
				'title'            => 'צור תווית',
				'label-name'       => 'שם',
				'label-type'       => 'סוג',
				'label-text'       => 'טקסט',
				'label-text-color' => 'צבע טקסט',
				'label-bg-color'   => 'צבע רקע',
				'label-image'      => 'תמונה',
				'image-width'      => 'רוחב (פיקסלים)',
				'image-height'     => 'גובה (פיקסלים)',
				'select'           => 'בחר',
			],

			'edit' => [
				'active'           => 'פעיל',
				'audience'         => 'קהל יעד',
				'back-btn'         => 'חזור',
				'channel'          => 'ערוץ',
				'customer-group'   => 'קבוצת לקוחות',
				'compaign'         => 'קמפיין',
				'event'            => 'אירוע',
				'general'          => 'כללי',
				'inactive'         => 'לא פעיל',
				'sort-order'       => 'עדיפות',
				'save-btn'         => 'עדכן',
				'select-event'     => 'בחר אירוע',
				'select-status'    => 'בחר מצב',
				'select-compaign'  => 'בחר קמפיין',
				'setting'          => 'הגדרה',
				'status'           => 'מצב',
				'subject'          => 'נושא',
				'title'            => 'ערוך תווית',
				'label-name'       => 'שם',
				'label-type'       => 'סוג',
				'label-text'       => 'טקסט',
				'label-text-color' => 'צבע טקסט',
				'label-bg-color'   => 'צבע רקע',
				'label-image'      => 'תמונה',
				'image-width'      => 'רוחב (פיקסלים)',
				'image-height'     => 'גובה (פיקסלים)',
				'select'           => 'בחר',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'תוויות',
						'info'                   => 'הקצה תוויות לכלל עגלה',
						'assigned-labels'        => 'תוויות שהוקצו',
						'unassigned-labels'      => 'תוויות שלא הוקצו',
						'unassigned-labels-info' => 'גרור תוויות אלו כדי להוסיף לרשימה שנבחרה.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'הגדרות תוויות מוצרים.',
				'title' => 'תווית מוצר',

				'general' => [
					'info'  => 'הגדרת מצב תוויות מוצרים.',
					'title' => 'כללי',

					'settings' => [
						'title'                               => 'כללי',
						'info'                                => 'הגדרות תוויות מוצרים.',
						'status'                              => 'מצב',
						'max-label-show-on-card'              => 'מספר התוויות בכרטיס מוצר',
						'max-label-show-on-card-info'         => 'הגדר את מספר התוויות המרבי שיוצגו בכרטיס המוצר.',
						'max-label-show-on-product-view'      => 'מספר התוויות בדף תצוגת מוצר',
						'max-label-show-on-product-view-info' => 'ציין כמה תוויות יוצגו בדף התצוגה. הזן 0 או השאר ריק כדי להציג את כל התוויות הרלוונטיות למוצר.',
						'label-image-width'                   => 'רוחב תמונת תווית (בפיקסלים) לשולחן עבודה',
						'label-image-width-info'              => 'ציין את רוחב תמונת התווית לשולחן עבודה.',
						'label-image-heigh'                   => 'גובה תמונת תווית (בפיקסלים) לשולחן עבודה',
						'label-image-heigh-info'              => 'ציין את גובה תמונת התווית לשולחן עבודה.',
						'mobile-label-image-width'            => 'רוחב תמונת תווית (בפיקסלים) לנייד',
						'mobile-label-image-width-info'       => 'ציין את רוחב תמונת התווית לנייד.',
						'mobile-label-image-heigh'            => 'גובה תמונת תווית (בפיקסלים) לנייד',
						'mobile-label-image-heigh-info'       => 'ציין את גובה תמונת התווית לנייד.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'התקן את חבילת תוויות המוצרים.',
			'migrate'     => 'מבצע הגירה של כל הטבלאות למסד הנתונים (עשוי לקחת זמן)...',
			'seed'        => 'הוספת נתונים למסד הנתונים...',
			'publish'     => 'פרסום נכסים וקובצי תצורה...',
			'cache'       => 'ניקוי מטמון...',
			'finish'      => 'חבילת תוויות המוצרים הותקנה בהצלחה.',
		],

		'version' => [
			'description' => 'מציג את הגרסה הנוכחית של חבילת תוויות המוצרים.',
			'comment'     => 'גרסת תווית מוצר: :version',
		],
	],
];
