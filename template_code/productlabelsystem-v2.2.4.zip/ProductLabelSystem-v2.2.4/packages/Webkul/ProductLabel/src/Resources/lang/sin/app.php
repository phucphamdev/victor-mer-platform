<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => 'ලේබල්',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => 'ලේබල් සාදන්න',
				'title'      => 'ලේබල්',

				'datagrid' => [
					'id'                  => 'අංකය',
					'name'                => 'නම',
					'label'               => 'ලේබල්',
					'compaign-id'         => 'ප්‍රචාරණ හැඳුනුම්පත',
					'status'              => 'තත්ත්වය',
					'active'              => 'සක්‍රිය',
					'inactive'            => 'අක්‍රිය',
					'edit'                => 'සංස්කරණය',
					'delete'              => 'මකන්න',
					'update-status'       => 'තත්ත්වය යාවත්කාලීන කරන්න',
					'create-success'      => 'ලේබල් සාර්ථකව සාදන ලදී',
					'mass-update-success' => 'ලේබල් සාර්ථකව යාවත්කාලීන කරන ලදී',
					'update-success'      => 'ලේබල් සාර්ථකව යාවත්කාලීන කරන ලදී',
					'mass-delete-success' => 'ලේබල් සාර්ථකව මකා දමන ලදී',
					'delete-success'      => 'ලේබල් සාර්ථකව මකා දමන ලදී',

					'type' => [
						'title' => 'වර්ගය',
						'image' => 'රූපය',
						'icon'  => 'අයිකනය',
						'text'  => 'පෙළ',
					],
				],
			],

			'create' => [
				'active'           => 'සක්‍රිය',
				'back-btn'         => 'ආපසු',
				'channel'          => 'නාලිකාව',
				'customer-group'   => 'පාරිභෝගික කණ්ඩායම',
				'compaign'         => 'ප්‍රචාරණය',
				'event'            => 'සිදුවීම',
				'general'          => 'සාමාන්‍ය',
				'inactive'         => 'අක්‍රිය',
				'sort-order'       => 'ප්‍රමුඛතාවය',
				'save-btn'         => 'ලේබල් සුරකින්න',
				'select-channel'   => 'නාලිකාව තෝරන්න',
				'select-event'     => 'සිදුවීම තෝරන්න',
				'select-group'     => 'කණ්ඩායම තෝරන්න',
				'select-status'    => 'තත්ත්වය තෝරන්න',
				'select-compaign'  => 'ප්‍රචාරණය තෝරන්න',
				'setting'          => 'සැකසුම්',
				'status'           => 'තත්ත්වය',
				'subject'          => 'මාතෘකාව',
				'title'            => 'ලේබල් සාදන්න',
				'label-name'       => 'නම',
				'label-type'       => 'වර්ගය',
				'label-text'       => 'පෙළ',
				'label-text-color' => 'පෙළ වර්ණය',
				'label-bg-color'   => 'පසුබැසීමේ වර්ණය',
				'label-image'      => 'රූපය',
				'image-width'      => 'පළල (px)',
				'image-height'     => 'උස (px)',
				'select'           => 'තෝරන්න',
			],

			'edit' => [
				'active'           => 'සක්‍රිය',
				'audience'         => 'ප්‍රේක්ෂකයින්',
				'back-btn'         => 'ආපසු',
				'channel'          => 'නාලිකාව',
				'customer-group'   => 'පාරිභෝගික කණ්ඩායම',
				'compaign'         => 'ප්‍රචාරණය',
				'event'            => 'සිදුවීම',
				'general'          => 'සාමාන්‍ය',
				'inactive'         => 'අක්‍රිය',
				'sort-order'       => 'ප්‍රමුඛතාවය',
				'save-btn'         => 'යාවත්කාලීන කරන්න',
				'select-event'     => 'සිදුවීම තෝරන්න',
				'select-status'    => 'තත්ත්වය තෝරන්න',
				'select-compaign'  => 'ප්‍රචාරණය තෝරන්න',
				'setting'          => 'සැකසුම්',
				'status'           => 'තත්ත්වය',
				'subject'          => 'මාතෘකාව',
				'title'            => 'ලේබල් සංස්කරණය',
				'label-name'       => 'නම',
				'label-type'       => 'වර්ගය',
				'label-text'       => 'පෙළ',
				'label-text-color' => 'පෙළ වර්ණය',
				'label-bg-color'   => 'පසුබැසීමේ වර්ණය',
				'label-image'      => 'රූපය',
				'image-width'      => 'පළල (px)',
				'image-height'     => 'උස (px)',
				'select'           => 'තෝරන්න',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => 'ලේබල්',
						'info'                   => 'කරත්ත නියමයට ලේබල් පැවරීම',
						'assigned-labels'        => 'පැවරූ ලේබල්',
						'unassigned-labels'      => 'නොපැවරූ ලේබල්',
						'unassigned-labels-info' => 'මෙම ලේබල් තෝරාගත් ලැයිස්තුවට එක් කිරීමට ඇදගෙන යන්න.',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => 'නිෂ්පාදන ලේබල් පිළිබඳ සැකසුම් සකසන්න.',
				'title' => 'නිෂ්පාදන ලේබල්',

				'general' => [
					'info'  => 'නිෂ්පාදන ලේබල් තත්වය සැකසීම.',
					'title' => 'සාමාන්‍ය',

					'settings' => [
						'title'                               => 'සාමාන්‍ය',
						'info'                                => 'නිෂ්පාදන ලේබල් පිළිබඳ සැකසුම් සකසන්න.',
						'status'                              => 'තත්වය',
						'max-label-show-on-card'              => 'නිෂ්පාදන කාඩ්පතේ පෙන්විය යුතු ලේබල් ගණන',
						'max-label-show-on-card-info'         => 'නිෂ්පාදන කාඩ්පතේ පෙන්විය යුතු උපරිම ලේබල් ගණන සැකසිය හැක.',
						'max-label-show-on-product-view'      => 'නිෂ්පාදන දසුන් පිටුවේ පෙන්විය යුතු ලේබල් ගණන',
						'max-label-show-on-product-view-info' => 'නිෂ්පාදන විශ්ලේෂණය පිටුවේ පෙන්විය යුතු ලේබල් ගණන නියම කරන්න. සියලුම ලේබල් පෙන්වීමට 0 හෝ හිස්ව තබන්න.',
						'label-image-width'                   => 'ඩෙස්ක්ටොප් සඳහා ලේබල් පිංතූරයේ පළල (px)',
						'label-image-width-info'              => 'ඩෙස්ක්ටොප් සඳහා ලේබල් පිංතූරයේ පළල සඳහන් කරන්න.',
						'label-image-heigh'                   => 'ඩෙස්ක්ටොප් සඳහා ලේබල් පිංතූරයේ උස (px)',
						'label-image-heigh-info'              => 'ඩෙස්ක්ටොප් සඳහා ලේබල් පිංතූරයේ උස සඳහන් කරන්න.',
						'mobile-label-image-width'            => 'ජංගම උපාංග සඳහා ලේබල් පිංතූරයේ පළල (px)',
						'mobile-label-image-width-info'       => 'ජංගම උපාංග සඳහා ලේබල් පිංතූරයේ පළල සඳහන් කරන්න.',
						'mobile-label-image-heigh'            => 'ජංගම උපාංග සඳහා ලේබල් පිංතූරයේ උස (px)',
						'mobile-label-image-heigh-info'       => 'ජංගම උපාංග සඳහා ලේබල් පිංතූරයේ උස සඳහන් කරන්න.',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => 'නිෂ්පාදන ලේබල් පැකේජය ස්ථාපනය කරන්න.',
			'migrate'     => 'සියලුම වගු දත්ත සමුදායට ගෙන යමින්... (යමක් කාලයක් ගතවිය හැක)',
			'seed'        => 'දත්ත දත්ත සමුදායට ඇතුළත් කරමින්...',
			'publish'     => 'දත්‍ය හා සැකසුම් ප්‍රකාශනය කරමින්...',
			'cache'       => 'මාර්ගකරණය මකාදැමීම...',
			'finish'      => 'නිෂ්පාදන ලේබල් පැකේජය සාර්ථකව ස්ථාපනය කරන ලදී.',
		],

		'version' => [
			'description' => 'නිෂ්පාදන ලේබල් පැකේජයේ වත්මන් අනුවාදය පෙන්වයි.',
			'comment'     => 'නිෂ්පාදන ලේබල් අනුවාදය: :version',
		],
	],
];
