<?php

return [
	'admin' => [
		'components' => [
			'layouts' => [
				'sidebar' => [
					'product-label' => '标签',
				],
			],
		],

		'label' => [
			'index' => [
				'create-btn' => '创建标签',
				'title'      => '标签',

				'datagrid' => [
					'id'                  => 'ID',
					'name'                => '名称',
					'label'               => '标签',
					'compaign-id'         => '活动 ID',
					'status'              => '状态',
					'active'              => '激活',
					'inactive'            => '未激活',
					'edit'                => '编辑',
					'delete'              => '删除',
					'update-status'       => '更新状态',
					'create-success'      => '标签创建成功',
					'mass-update-success' => '标签批量更新成功',
					'update-success'      => '标签更新成功',
					'mass-delete-success' => '标签批量删除成功',
					'delete-success'      => '标签删除成功',

					'type' => [
						'title' => '类型',
						'image' => '图片',
						'icon'  => '图标',
						'text'  => '文本',
					],
				],
			],

			'create' => [
				'active'           => '激活',
				'back-btn'         => '返回',
				'channel'          => '渠道',
				'customer-group'   => '客户群',
				'compaign'         => '活动',
				'event'            => '事件',
				'general'          => '常规',
				'inactive'         => '未激活',
				'sort-order'       => '优先级',
				'save-btn'         => '保存标签',
				'select-channel'   => '选择渠道',
				'select-event'     => '选择事件',
				'select-group'     => '选择群组',
				'select-status'    => '选择状态',
				'select-compaign'  => '选择活动',
				'setting'          => '设置',
				'status'           => '状态',
				'subject'          => '主题',
				'title'            => '创建标签',
				'label-name'       => '名称',
				'label-type'       => '类型',
				'label-text'       => '文本',
				'label-text-color' => '文本颜色',
				'label-bg-color'   => '背景颜色',
				'label-image'      => '图片',
				'image-width'      => '宽度 (px)',
				'image-height'     => '高度 (px)',
				'select'           => '选择',
			],

			'edit' => [
				'active'           => '激活',
				'audience'         => '受众',
				'back-btn'         => '返回',
				'channel'          => '渠道',
				'customer-group'   => '客户群',
				'compaign'         => '活动',
				'event'            => '事件',
				'general'          => '常规',
				'inactive'         => '未激活',
				'sort-order'       => '优先级',
				'save-btn'         => '更新',
				'select-event'     => '选择事件',
				'select-status'    => '选择状态',
				'select-compaign'  => '选择活动',
				'setting'          => '设置',
				'status'           => '状态',
				'subject'          => '主题',
				'title'            => '编辑标签',
				'label-name'       => '名称',
				'label-type'       => '类型',
				'label-text'       => '文本',
				'label-text-color' => '文本颜色',
				'label-bg-color'   => '背景颜色',
				'label-image'      => '图片',
				'image-width'      => '宽度 (px)',
				'image-height'     => '高度 (px)',
				'select'           => '选择',
			],
		],

		'marketing' => [
			'promotions' => [
				'cart-rules' => [
					'label' => [
						'title'                  => '标签',
						'info'                   => '为购物车规则分配标签',
						'assigned-labels'        => '已分配标签',
						'unassigned-labels'      => '未分配标签',
						'unassigned-labels-info' => '拖动这些标签以添加到选定列表中。',
					],
				]
			],
		],
	],

	'configuration' => [
		'index' => [
			'label' => [
				'info'  => '设置产品标签相关的配置。',
				'title' => '产品标签',

				'general' => [
					'info'  => '设置产品标签状态。',
					'title' => '常规',

					'settings' => [
						'title'                               => '常规',
						'info'                                => '设置产品标签相关的配置。',
						'status'                              => '状态',
						'max-label-show-on-card'              => '产品卡片上显示的标签数量',
						'max-label-show-on-card-info'         => '设置产品卡片上最多显示的标签数量。',
						'max-label-show-on-product-view'      => '产品详情页上显示的标签数量',
						'max-label-show-on-product-view-info' => '指定产品详情页上应该显示多少个标签。设置为 0 或留空以显示所有相关标签。',
						'label-image-width'                   => '桌面端标签图片宽度 (px)',
						'label-image-width-info'              => '指定桌面端标签图片的宽度。',
						'label-image-heigh'                   => '桌面端标签图片高度 (px)',
						'label-image-heigh-info'              => '指定桌面端标签图片的高度。',
						'mobile-label-image-width'            => '移动端标签图片宽度 (px)',
						'mobile-label-image-width-info'       => '指定移动端标签图片的宽度。',
						'mobile-label-image-heigh'            => '移动端标签图片高度 (px)',
						'mobile-label-image-heigh-info'       => '指定移动端标签图片的高度。',
					],
				],
			],
		],
	],

	'commands' => [
		'install' => [
			'description' => '安装产品标签插件。',
			'migrate'     => '正在将所有表迁移到数据库（需要一些时间）...',
			'seed'        => '正在向数据库插入数据...',
			'publish'     => '正在发布资源和配置...',
			'cache'       => '正在清理缓存...',
			'finish'      => '产品标签插件安装成功。',
		],

		'version' => [
			'description' => '显示当前产品标签插件的版本。',
			'comment'     => '产品标签版本: :version',
		],
	],
];
