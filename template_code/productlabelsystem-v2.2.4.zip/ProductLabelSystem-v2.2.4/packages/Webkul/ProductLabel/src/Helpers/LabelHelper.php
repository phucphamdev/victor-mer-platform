<?php

namespace Webkul\ProductLabel\Helpers;

use Webkul\ProductLabel\Repositories\LabelRepository;
use Webkul\Product\Helpers\ConfigurableOption;

use function Pest\Laravel\options;

class LabelHelper
{
    /**
     * Constructor for the class.
     *
     * @return void
     */
    public function __construct(
        protected LabelRepository $labelRepository,
        protected CartRuleHelper $cartRuleHelper,
        protected ConfigurableOption $configurableOption,
    ) {}

    /**
     * Get lables which not assigned to $cartRule.
     */
    public function getUnAssignedLabels($cartRule = null): object
    {
        return $this->labelRepository->getUnAssignedLabels($cartRule);
    }

    /**
     * Get product labels.
     *
     * @param Object $product product.
     * @param int $limit limit to fetch lables.
     *
     * @return array
     */
    public function getproductLabels($product, $limit = null): array
    {
        $cartRules = $this->cartRuleHelper->getProductApplicableCartRules($product);

        $labels = [];

        foreach ($cartRules as $rule) {
            $labels = array_merge($labels, $rule->labels->toArray());
        }

        $uniqueLabels = [];
        $seenIds = [];

        foreach ($labels as $key => $label) {
            if (!in_array($label['id'], $seenIds)) {
                $uniqueLabels[] = $label;
                $seenIds[] = $label['id'];

                if ($limit && (($key + 1) == $limit)) {
                    break;
                }
            }
        }

        return $uniqueLabels;
    }

    /**
     * Get Configurable product labels
     *
     * @param Object $product
     */
    public function getConfigurableProdcutLabels($product, $limit = null): array
    {
        $options = $this->configurableOption->getAllowedVariants($product);

        $data = [];

        if ($options) {
            foreach ($options as $product) {
                $data[$product->id] = $this->getproductLabels($product);
            }
        }

        return $data;
    }
}
