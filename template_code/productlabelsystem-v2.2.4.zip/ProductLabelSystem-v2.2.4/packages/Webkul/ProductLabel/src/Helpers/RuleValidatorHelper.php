<?php

namespace Webkul\ProductLabel\Helpers;

use Webkul\Rule\Helpers\Validator;

class RuleValidatorHelper
{

	public function __construct(
		protected Validator $validator,
	) {}

	/**
	 * Validate cart rule for condition
	 *
	 * @param  \Webkul\CartRule\Contracts\CartRule|\Webkul\CatalogRule\Contracts\CatalogRule  $rule
	 * @param  \Webkul\Checkout\Contracts\Cart|\Webkul\Checkout\Contracts\CartItem|\Webkul\Product\Contracts\Product  $entity
	 * @return bool
	 */
	public function validate($rule, $entity)
	{
		if (! $rule->conditions) {
			return true;
		}

		$validConditionCount = $totalConditionCount = 0;

		foreach ($rule->conditions as $condition) {
			if (! isset($condition['attribute']) || 
			    ! array_key_exists('value', $condition)) {
				continue;
			}

			$totalConditionCount++;

			if ($rule->condition_type == '1') {
				if (! $this->validateObject($condition, $entity)) {
					return false;
				} else {
					$validConditionCount++;
				}
			} elseif ($rule->condition_type == '2') {
				if ($this->validateObject($condition, $entity)) {
					return true;
				}
			}
		}

		return $validConditionCount == $totalConditionCount;
	}

	/**
	 * Validate object
	 *
	 * @param  array  $condition
	 * @param  \Webkul\Checkout\Contracts\CartItem  $entity
	 * @return bool
	 */
	private function validateObject($condition, $entity)
	{
		$validated = false;

		foreach ($this->getAllItems($this->getAttributeScope($condition), $entity) as $item) {
			$attributeValue = $this->getAttributeValue($condition, $item);

			if ($validated = $this->validator->validateAttribute($condition, $attributeValue)) {
				break;
			}
		}

		return $validated;
	}

	/**
	 * Return all cart items
	 *
	 * @param  string  $attributeScope
	 * @param  \Webkul\Checkout\Contracts\Cart|\Webkul\Checkout\Contracts\CartItem|\Webkul\Product\Contracts\Product  $item
	 * @return array
	 */
	private function getAllItems($attributeScope, $item)
	{
		if ($attributeScope === 'parent') {
			return [$item];
		} elseif ($attributeScope === 'children') {
			return $item->children ?: [$item];
		} else {
			$items = $item->children ?: [];

			$items[] = $item;
		}

		return $items;
	}

	/**
	 * Validate object
	 *
	 * @param  array  $condition
	 * @return string
	 */
	private function getAttributeScope($condition)
	{
		$chunks = explode('|', $condition['attribute']);

		$attributeNameChunks = explode('::', $chunks[1]);

		return count($attributeNameChunks) == 2 ? $attributeNameChunks[0] : null;
	}

	/**
	 * Return value for the attribute
	 *
	 * @param  array  $condition
	 * @param  \Webkul\Checkout\Contracts\CartItem|\Webkul\Product\Contracts\Product  $entity
	 * @return bool
	 */
	public function getAttributeValue($condition, $entity)
	{
		$chunks = explode('|', $condition['attribute']);

		$attributeNameChunks = explode('::', $chunks[1]);

		$attributeCode = $attributeNameChunks[count($attributeNameChunks) - 1];

		switch (current($chunks)) {
			case 'product':
				if ($attributeCode == 'category_ids') {
					$value = $entity->product
						? $entity->product->categories()->pluck('id')->toArray()
						: $entity->categories()->pluck('id')->toArray();

					return $value;
				} else {
					$value = $entity->product
						? $entity->product->{$attributeCode}
						: $entity->{$attributeCode};

					if (! in_array($condition['attribute_type'], ['multiselect', 'checkbox'])) {
						return $value;
					}

					return $value ? explode(',', $value) : [];
				}
		}
	}
}
