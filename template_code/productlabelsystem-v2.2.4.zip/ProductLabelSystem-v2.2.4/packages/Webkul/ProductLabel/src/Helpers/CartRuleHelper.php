<?php

namespace Webkul\ProductLabel\Helpers;

use Webkul\CartRule\Helpers\CartRule;
use Webkul\CartRule\Repositories\CartRuleCustomerRepository;

class CartRuleHelper
{
	/**
	 * @var array
	 */
	protected $cartRules = null;

	/**
	 * Create a new helper instance.
	 *
	 * @return void
	 */
	public function __construct(
		protected CartRule $cartRule,
		protected CartRuleCustomerRepository $cartRuleCustomerRepository,
		protected RuleValidatorHelper $ruleValidatorHelper,
	) {}

	/**
	 * Get prodcut applicable cart rules.
	 *
	 * @param Object $product
	 */
	public function getProductApplicableCartRules($product)
	{
		$applicableRules = [];

		if ($product && $this->cartRule->haveCartRules()) {
			foreach ($rules = $this->getCartRules() as $rule) {
				if (! $this->canProcessRule($rule)) {
					continue;
				}

				if (! $this->ruleValidatorHelper->validate($rule, $product)) {
					continue;
				}

				$applicableRules[] = $rule;
			}
		}

		return $applicableRules;
	}

	/**
	 * Returns cart rules
	 *
	 * @return \Illuminate\Support\Collection
	 */
	public function getCartRules()
	{
		if ($this->cartRules) {
			return $this->cartRules;
		}

		$cartRules = $this->cartRule->getCartRuleQuery()
			->with([
				'cart_rule_customer_groups',
				'cart_rule_channels',
				'cart_rule_coupon',
			])
			->get();

		$this->cartRules = $cartRules->filter(function ($rule) {
			$conditions = is_array($rule->conditions) ? $rule->conditions : json_decode($rule->conditions, true);

			// Skip if conditions are not valid JSON or null
			if (!is_array($conditions)) {
				return false;
			}

			// Filter rules by condition type
			return match ($rule->condition_type) {
				// 1 => collect($conditions)->every(function ($condition) {
				// 	return isset($condition['attribute']) && str_starts_with($condition['attribute'], 'product|');
				// }),
				1 => collect($conditions)->contains(function ($condition) {
					return isset($condition['attribute']) && str_starts_with($condition['attribute'], 'product|');
				}),
				2 => collect($conditions)->contains(function ($condition) {
					return isset($condition['attribute']) && str_starts_with($condition['attribute'], 'product|');
				}),
				default => false,
			};
		});

		return $this->cartRules;
	}

	/**
	 * Check if rule can be applied.
	 *
	 * @param  \Webkul\CartRule\Contracts\CartRule  $rule
	 */
	public function canProcessRule($rule): bool
	{
		if ($rule->usage_per_customer && $customer = auth()->guard('customer')->user()) {
			$ruleCustomer = $this->cartRuleCustomerRepository->findOneWhere([
				'cart_rule_id' => $rule->id,
				'customer_id'  => $customer->id,
			]);

			if (
				$ruleCustomer
				&& $ruleCustomer->times_used >= $rule->usage_per_customer
			) {
				return false;
			}
		}

		return true;
	}
}
