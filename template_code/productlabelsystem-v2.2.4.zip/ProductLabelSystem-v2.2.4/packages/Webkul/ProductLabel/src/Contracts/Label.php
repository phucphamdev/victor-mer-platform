<?php

namespace Webkul\ProductLabel\Contracts;

interface Label {}
