<?php

use Illuminate\Support\Facades\Route;
use Webkul\ProductLabel\Http\Controllers\Admin\LabelController;

Route::group(['middleware' => ['admin'], 'prefix' => 'admin/label'], function () {

    Route::controller(LabelController::class)->group(function () {
        Route::get('', 'index')->name('admin.product_label.index');

        Route::get('create', 'create')->name('admin.product_label.create');

        Route::post('create', 'store')->name('admin.product_label.store');

        Route::get('edit/{id}', 'edit')->name('admin.product_label.edit');

        Route::put('edit/{id}', 'update')->name('admin.product_label.update');

        Route::delete('delete/{id}', 'destroy')->name('admin.product_label.delete');

        Route::post('mass-update', 'massUpdate')->name('admin.product_label.mass_update');

        Route::post('mass-delete', 'massDestroy')->name('admin.product_label.mass_delete');
    });
});
