<?php

/**
 * Admin Routes.
 */
require 'admin-routes.php';

/**
 * Shop Routes.
 */
require 'shop-routes.php';
