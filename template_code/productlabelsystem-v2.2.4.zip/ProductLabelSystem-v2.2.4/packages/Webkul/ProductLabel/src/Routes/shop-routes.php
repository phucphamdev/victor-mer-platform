<?php

use Illuminate\Support\Facades\Route;
use Webkul\ProductLabel\Http\Controllers\Admin\LabelController;

Route::group([
    'middleware' => ['locale', 'theme', 'currency'],
    'prefix' => 'api/product-labels',
], function () {
    Route::controller(LabelController::class)->group(function () {
        Route::get('get-product-filters', 'getProductLabels')->name('shop.api.product.labels');
    });
});
