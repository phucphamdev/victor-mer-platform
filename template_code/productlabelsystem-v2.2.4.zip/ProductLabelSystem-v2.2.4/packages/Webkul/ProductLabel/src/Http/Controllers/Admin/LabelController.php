<?php

namespace Webkul\ProductLabel\Http\Controllers\Admin;

use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Webkul\Admin\Http\Requests\MassDestroyRequest;
use Webkul\Admin\Http\Requests\MassUpdateRequest;
use Webkul\ProductLabel\DataGrids\LabelDataGrid;
use Webkul\ProductLabel\Repositories\LabelRepository;
use Webkul\ProductLabel\Helpers\LabelHelper;
use Webkul\Product\Repositories\ProductRepository;

class LabelController extends Controller
{
    /**
     * Constructor for the class.
     *
     * @return void
     */
    public function __construct(
        protected LabelRepository $labelRepository,
        protected LabelHelper $labelHelper,
        protected ProductRepository $productRepository,
    ) {}

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        if (request()->ajax()) {
            return datagrid(LabelDataGrid::class)->process();
        }

        return view('productlabel::admin.labels.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('productlabel::admin.labels.create');
    }

    /**
     * Store a newly lable.
     *
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $data = request()->all();

        $validator = \Validator::make($data, [
            'name'             => 'required|string',
            'type'             => 'required|string|in:image,text,icon',
            'text'             => 'required_if:type,text|nullable|string',
            'text_color'       => 'required_if:type,text|nullable|string|max:20',
            'background_color' => 'required_if:type,text|nullable|string|max:20',
            'position'         => 'required|string',
            'sort_order'       => [
                'required',
                'integer',
                'min:1',
                function ($attribute, $value, $fail) {
                    if (DB::table('labels')->where('sort_order', $value)->exists()) {
                        $fail(trans('productlabel::app.validation.priority_unique'));
                    }
                },
            ],
            'image_width'  => 'nullable|integer|min:50|max:300|required_if:type,image',
            'image_height' => 'nullable|integer|min:50|max:300|required_if:type,image',
            'image'        => 'required_if:type,image|array|min:1',
            'image.*'      => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ], [
            'image.required_if' => trans('productlabel::app.validation.image_required'),
            'type.required'     => trans('productlabel::app.validation.type_required'),
        ]);

        if ($validator->fails()) {
            session()->flash('error', $validator->errors()->first());
            return redirect()->back()->withInput();
        }

        $label = $this->labelRepository->create($data);

        if (request()->hasFile('image') && $data['type'] === 'image') {
            $label->image_path = current(request()->file('image'))->store('product_label');
            $label->save();
        }

        session()->flash('success', trans('productlabel::app.admin.label.index.datagrid.create-success'));

        return redirect()->route('admin.product_label.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @return \Illuminate\View\View
     */
    public function edit(int $id)
    {
        $label = $this->labelRepository->findOrFail($id);

        return view('productlabel::admin.labels.edit', compact('label'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function update(int $id)
    {
        $this->validate(request(), [
            'name'                   => 'required|string',
            'type'                   => 'required|string|in:image,text,icon',
            'text'                   => 'required_if:type,text|nullable|string',
            'text_color'             => 'required_if:type,text|nullable|string|max:20',
            'background_color'       => 'required_if:type,text|nullable|string|max:20',
            'position'               => 'required|string',
            'sort_order'             => [
                'required',
                'integer',
                'min:1',
                function ($attribute, $value, $fail) use ($id) {
                    if (DB::table('labels')
                        ->where('sort_order', $value)
                        ->where('id', '!=', $id)
                        ->exists()
                    ) {
                        $fail("The {$attribute} value is already taken for the selected campaign.");
                    }
                },
            ],
            'image_width'  => 'nullable|integer|min:50|max:300|required_if:type,image',
            'image_height' => 'nullable|integer|min:50|max:300|required_if:type,image',
        ]);
        
        $label = $this->labelRepository->find($id);

        $data = request()->all();
        $data['status'] = isset($data['status']) ? 1 : 0;

        $label->update($data);

        if (request()->hasFile('image') && $data['type'] === 'image') {
            if ($label->image_path) {
                Storage::delete($label->image_path);
            }

            $label->image_path = current(request()->file('image'))->store('product_label');
            $label->save();
        }

        session()->flash('success', trans('productlabel::app.admin.label.index.datagrid.update-success'));

        return redirect()->route('admin.product_label.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy(int $id): JsonResponse
    {
        try {
            $this->labelRepository->delete($id);

            return new JsonResponse([
                'message' => trans('productlabel::app.admin.label.index.datagrid.delete-success'),
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'message' => trans('productlabel::app.admin.label.index.datagrid.delete-failed'),
            ], 500);
        }
    }

    /**
     * Mass update the Labels.
     *
     * @return response
     */
    public function massUpdate(MassUpdateRequest $request): JsonResponse
    {
        $this->labelRepository
            ->whereIn('id', $request->input('indices'))
            ->update(['status' => $request->input('value')]);

        return new JsonResponse([
            'message' => trans('productlabel::app.admin.label.index.datagrid.mass-update-success'),
        ]);
    }

    /**
     * Mass Delete the labels.
     *
     * @return response
     */
    public function massDestroy(MassDestroyRequest $request): JsonResponse
    {
        $this->labelRepository
            ->whereIn('id', $request->input('indices'))
            ->delete();

        return new JsonResponse([
            'message' => trans('productlabel::app.admin.label.index.datagrid.mass-delete-success'),
        ]);
    }

    /**
     * Get product labels.
     */
    public function getProductLabels()
    {
        $params = [...request('query')];

        // When change config product.
        $product_id = $params['product_type'] == 'configurable' && ! empty($params['variant_id']) ?  $params['variant_id'] : $params['product_id'];

        $product = $this->productRepository->find($product_id);

        if ($product) {

            // If bundle product update.
            if (
                $params['product_type'] == 'bundle'
                && isset($params['newPrice'])
                && ! empty($params['newPrice'])
            ) {
                $product->price = $params['newPrice'];
            }

            $prodcutLabels = $this->labelHelper->getproductLabels($product, $params['limit']);
        }

        return response()->json([
            'data' => $prodcutLabels ?? [],
        ]);
    }
}
