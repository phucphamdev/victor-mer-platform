<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('labels', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->enum('type', ['icon', 'image', 'text'])->notNullable();

            $table->string('image_path')->nullable();
            $table->integer('image_width')->notNullable();
            $table->integer('image_height')->notNullable();

            $table->string('icon')->nullable();
            $table->string('text')->nullable();
            $table->string('text_color')->nullable();
            $table->string('background_color')->nullable();

            $table->enum('position', ['top-left', 'top-right', 'bottom-left', 'bottom-right'])->notNullable();
            $table->integer('sort_order')->notNullable();
            $table->tinyInteger('status')->default(0);
            $table->timestamps();

            $table->unique(['sort_order'], 'sort_order_index_unique');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lables');
    }
};
