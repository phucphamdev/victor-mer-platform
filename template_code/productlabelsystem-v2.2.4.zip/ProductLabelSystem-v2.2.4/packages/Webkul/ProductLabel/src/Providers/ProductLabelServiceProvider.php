<?php

namespace Webkul\ProductLabel\Providers;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;
use Webkul\CartRule\Contracts\CartRule as BaseCartRule;
use Webkul\ProductLabel\Models\CartRule\CartRule;
use Webkul\Shop\Http\Controllers\API\ProductController as BaseProductController;
use Webkul\ProductLabel\Http\Controllers\Shop\API\ProductController;
use Webkul\ProductLabel\Console\Commands\InstallProductLabel;

class ProductLabelServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');

        Route::middleware('web')->group(__DIR__ . '/../Routes/web.php');

        $this->loadTranslationsFrom(__DIR__ . '/../Resources/lang', 'productlabel');

        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'productlabel');

        $this->publishAssets();

        Blade::anonymousComponentPath(__DIR__ . '/../Resources/views/shop/components', 'product-label-shop');

        if (core()->getConfigData('labels.general.settings.status')) {
            $this->mergeConfigFrom(
                dirname(__DIR__) . '/Config/admin-menu.php',
                'menu.admin'
            );

            $this->registerProviders();
            $this->overrideCoreModels();
            $this->overrideControllers();
        }

        $this->registerCommands();
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->registerConfig();
    }

    /**
     * Register package config.
     *
     * @return void
     */
    protected function registerConfig()
    {
        $this->mergeConfigFrom(
            dirname(__DIR__) . '/Config/system.php',
            'core'
        );

        $this->mergeConfigFrom(
            dirname(__DIR__) . '/Config/bagisto-vite.php',
            'bagisto-vite.viters'
        );
    }

    /**
     * Register the providers.
     */
    protected function registerProviders(): void
    {
        $this->app->register(ModuleServiceProvider::class);

        $this->app->register(EventServiceProvider::class);
    }

    /**
     * Publish the assets.
     */
    protected function publishAssets(): void
    {
        $this->publishes([
            // override admin end files.
            __DIR__ . '/../Resources/views/admin/marketing/promotions/cart-rules/create.blade.php' => resource_path('views/vendor/admin/marketing/promotions/cart-rules/create.blade.php'),

            // override front end components files.
            __DIR__ . '/../Resources/views/shop/components/products/card.blade.php' => resource_path('themes/default/views/components/products/card.blade.php'),

            // override front end product related files.
            __DIR__ . '/../Resources/views/shop/products/view' => resource_path('themes/default/views/products/view'),

            // Publish package assets.
            __DIR__ . '/../../publishable' => public_path('/'),
        ]);
    }

    /**
     * Register the commands.
     */
    protected function registerCommands(): void
    {
        if ($this->app->runningInConsole()) {
            $this->commands([
                InstallProductLabel::class,
            ]);
        }
    }


    /**
     * Override the core models.
     */
    protected function overrideCoreModels(): void
    {
        $this->app->concord->registerModel(BaseCartRule::class, CartRule::class);
    }

    /**
     * Override the core models.
     */
    protected function overrideControllers(): void
    {
        $this->app->bind(BaseProductController::class, ProductController::class);
    }
}
