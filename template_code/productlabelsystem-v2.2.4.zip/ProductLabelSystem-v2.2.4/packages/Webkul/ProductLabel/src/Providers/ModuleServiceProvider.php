<?php

namespace Webkul\ProductLabel\Providers;

use Konekt\Concord\BaseModuleServiceProvider;

class ModuleServiceProvider extends BaseModuleServiceProvider
{
    protected $models = [
        \Webkul\ProductLabel\Models\Label::class,
    ];
}
