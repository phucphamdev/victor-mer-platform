<?php

namespace Webkul\ProductLabel\Providers;

use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event handler mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        'promotions.cart_rule.create.after' => [
            'Webkul\ProductLabel\Listeners\CartRule@afterUpdate',
        ],
        'promotions.cart_rule.update.after' => [
            'Webkul\ProductLabel\Listeners\CartRule@afterUpdate',
        ],
    ];

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $eventTemplates = [
            [
                'event'    => 'bagisto.admin.layout.head.before',
                'template' => 'productlabel::layouts.style',
            ],
            [
                'event'    => 'bagisto.shop.layout.head.before',
                'template' => 'productlabel::layouts.style',
            ],
            [
                'event'    => 'bagisto.admin.marketing.promotions.cart_rules.create.card.actions.after',
                'template' => 'productlabel::admin.marketing.promotions.cart-rules.assing-label',
            ],
            [
                'event'    => 'bagisto.admin.marketing.promotions.cart_rules.edit.card.actions.after',
                'template' => 'productlabel::admin.marketing.promotions.cart-rules.assing-label',
            ],
        ];

        if (core()->getConfigData('labels.general.settings.status')) {
            foreach ($eventTemplates as $eventTemplate) {
                Event::listen(current($eventTemplate), fn($e) => $e->addTemplate(end($eventTemplate)));
            }
        }
    }
}
