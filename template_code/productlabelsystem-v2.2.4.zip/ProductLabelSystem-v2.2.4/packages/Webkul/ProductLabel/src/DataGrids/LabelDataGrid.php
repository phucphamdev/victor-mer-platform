<?php

namespace Webkul\ProductLabel\DataGrids;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Webkul\DataGrid\DataGrid;

class LabelDataGrid extends DataGrid
{
    /**
     * Review status "approved".
     */
    const STATUS_APPROVED = 1;

    /**
     * Review status "pending", indicating awaiting approval or processing.
     */
    const STATUS_PENDING = 0;

    /**
     * Label type "image".
     */
    const TYPE_IMAGE = 'image';

    /**
     * Label type "text".
     */
    const TYPE_ICON = 'icon';

    /**
     * Label type "text".
     */
    const TYPE_TEXT = 'text';

    /**
     * Prepare query builder.
     *
     * @return \Illuminate\Database\Query\Builder
     */
    public function prepareQueryBuilder()
    {
        $queryBuilder = DB::table('labels')
            ->select(
                'labels.id',
                'labels.name',
                'labels.type as type',
                'labels.image_path as image',
                'labels.image_width',
                'labels.image_height',
                'labels.text',
                'labels.text_color',
                'labels.background_color',
                'labels.sort_order',
                'labels.status',
            );

        $this->addFilter('id', 'labels.id');
        $this->addFilter('name', 'labels.name');
        $this->addFilter('type', 'labels.type');
        $this->addFilter('status', 'labels.status');

        return $queryBuilder;
    }

    /**
     * Add columns.
     *
     * @return void
     */
    public function prepareColumns()
    {
        $this->addColumn([
            'index'      => 'id',
            'label'      => trans('productlabel::app.admin.label.index.datagrid.id'),
            'type'       => 'integer',
            'searchable' => true,
            'filterable' => true,
            'sortable'   => true,
        ]);

        $this->addColumn([
            'index'      => 'name',
            'label'      => trans('productlabel::app.admin.label.index.datagrid.name'),
            'type'       => 'string',
            'searchable' => true,
            'filterable' => true,
            'sortable'   => true,
        ]);
        
        $this->addColumn([
            'index' => 'text',
            'label' => trans('productlabel::app.admin.label.index.datagrid.label'),
            'type' => 'string',
            'searchable' => true,
            'filterable' => false,
            'sortable' => true,
            'closure' => function ($row) {
                if ($row->type === self::TYPE_IMAGE) {
                    $width = $row->image_width ?? core()->getConfigData('labels.general.settings.label-image-width');
                    $height = $row->image_height ?? core()->getConfigData('labels.general.settings.label-image-heigh');
                    $image = $row->image ?: DB::table('labels')->where('id', $row->id)->value('image_path');

                    return '<img
                        class="rounded-[44px]"
                        src="' . Storage::url($image) . '"
                        style="width:' . $width . 'px; height:' . $height . 'px;"
                    />';
                }

                return '<span
                    class="max-w-max rounded-[35px] px-2.5 py-1.5 text-[12px] font-semibold"
                    style="color:' . $row->text_color . '; background-color:' . $row->background_color . ';" >'
                    . $row->text .
                '</span>';
            },
        ]);

        $this->addColumn([
            'index'      => 'status',
            'label'      => trans('productlabel::app.admin.label.index.datagrid.status'),
            'type'       => 'string',
            'searchable' => true,
            'filterable' => true,
            'filterable_type'    => 'dropdown',
            'filterable_options' => [
                [
                    'label' => trans('productlabel::app.admin.label.index.datagrid.active'),
                    'value' => self::STATUS_APPROVED,
                ],
                [
                    'label' => trans('productlabel::app.admin.label.index.datagrid.inactive'),
                    'value' => self::STATUS_PENDING,
                ],
            ],
            'sortable'   => true,
            'closure'    => function ($row) {
                if ($row->status) {
                    return '<span class="label-active">' . trans('productlabel::app.admin.label.index.datagrid.active') . '</span>';
                }

                return '<span class="label-info">' . trans('productlabel::app.admin.label.index.datagrid.inactive') . '</span>';
            },
        ]);
    }

    /**
     * Prepare actions.
     *
     * @return void
     */
    public function prepareActions()
    {
        $this->addAction([
            'icon'   => 'icon-edit',
            'title'  => trans('productlabel::app.admin.label.index.datagrid.edit'),
            'method' => 'GET',
            'url'    => function ($row) {
                return route('admin.product_label.edit', $row->id);
            },
        ]);

        $this->addAction([
            'icon'   => 'icon-delete',
            'title'  => trans('productlabel::app.admin.label.index.datagrid.delete'),
            'method' => 'DELETE',
            'url'    => function ($row) {
                return route('admin.product_label.delete', $row->id);
            },
        ]);

        $this->addMassAction([
            'title'  => trans('productlabel::app.admin.label.index.datagrid.delete'),
            'method' => 'POST',
            'url'    => route('admin.product_label.mass_delete'),
        ]);

        $this->addMassAction([
            'title'   => trans('productlabel::app.admin.label.index.datagrid.update-status'),
            'method'  => 'POST',
            'url'     => route('admin.product_label.mass_update'),
            'options' => [
                [
                    'label' => trans('productlabel::app.admin.label.index.datagrid.active'),
                    'value' => 1,
                ],
                [
                    'label' => trans('productlabel::app.admin.label.index.datagrid.inactive'),
                    'value' => 0,
                ],
            ],
        ]);
    }
}
