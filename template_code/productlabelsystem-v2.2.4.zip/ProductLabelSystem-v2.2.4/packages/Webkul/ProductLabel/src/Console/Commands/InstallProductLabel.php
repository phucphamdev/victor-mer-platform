<?php

namespace Webkul\ProductLabel\Console\Commands;

use Illuminate\Console\Command;
use Webkul\ProductLabel\Providers\ProductLabelServiceProvider;

class InstallProductLabel extends Command
{
	/**
	 * The name and signature of the console command.
	 *
	 * @var string
	 */
	protected $signature = 'product-label:install';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = '';

	/**
	 * Create a new command instance.
	 */
	public function __construct()
	{
		$this->description = trans('productlabel::app.commands.install.description');

		parent::__construct();
	}

	/**
	 * Install and configure Marketplace.
	 */
	public function handle()
	{
		$this->warn(trans('productlabel::app.commands.install.migrate'));
		$this->call('migrate');

		$this->warn(trans('productlabel::app.commands.install.publish'));
		$this->info($this->call('vendor:publish', [
			'--provider' => ProductLabelServiceProvider::class,
			'--force'    => true,
		]));

		$this->warn(trans('productlabel::app.commands.install.cache'));
		$this->call('optimize:clear');

		$this->comment(trans('productlabel::app.commands.install.finish'));
	}
}
