<?php

return [
    [
        'key'   => 'product-label',
        'name'  => 'productlabel::app.admin.components.layouts.sidebar.product-label',
        'route' => 'admin.product_label.index',
        'sort'  => 4,
        'icon'  => 'icon-product',
    ],
];
