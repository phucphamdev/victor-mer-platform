<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Product Label Vite Configuration
    |--------------------------------------------------------------------------
    |
    | Please add your Vite registry here to seamlessly support the `bagisto_assets` function.
    |
    */
    'product-label' => [
        'hot_file'                 => 'product-label-default-vite.hot',
        'build_directory'          => 'themes/product-label/build',
        'package_assets_directory' => 'src/Resources/assets',
    ],
];
