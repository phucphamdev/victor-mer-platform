# Changelog for v2.2.4

#### This changelog consists the bug & security fixes and new Features being included in the releases listed below.

## **v2.2.4( , 2025)** - *Release*

* [Feature]

* [Improvement] Image Validation for Image Type Product Label has been added.

* [Fixed] Image Type Product Label – Pixel Dimension Validation added.

* [Fixed]  Product Labels will delete Individual.

* [Fixed] Product Label Type Dropdown will Translated successfully. 

* [Fixed] While Updating Product Label from Image to Text is now fix.

* [Fixed] Product Label Status will Update active/inactive 

* [Fixed] Product Label Image are  Appeared for all language.

* [Fixed] There is Character Validation Message for Text Type in Product Label Creation.

* [Fixed] 50-Character Validation for Text Input in Product Label has been added.

* [Fixed] Validation Message for Duplicate Priority is now updated.

* [Fixed] Product Label will not Appeared When Product Attributes (New, Featured, Visible Individually, Status) Are Set to "No".

* [Fixed] Product Label will not  Appeared Despite "Manage Stock = No".

# Changelog for v2.2.3

This changelog highlights the bug fixes, security updates, and new features included in this release. The previous application has been discontinued.

## **v2.2.3(4th of February, 2025)** - _Release*

[Enhancement] Admin Will Create labels based on priority.
[Feature] Admin will assign multiple labels to the cart rule.
[Feature] Label will automatically show on the front end based on cart-rule and label priority.
[Feature] Admin will set a limit to show labels on product card and product details page.
[Feature] Admin will set image label custom height and width.

