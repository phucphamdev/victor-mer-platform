<thead {{ $attributes->merge(['class' => 'border-gray-200 bg-gray-50 text-sm text-gray-600 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300']) }}>
    {{ $slot }}
</thead>
