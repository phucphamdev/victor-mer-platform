<?php

namespace Webkul\ImageGallery\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ManageGroupProxy extends ModelProxy
{
}