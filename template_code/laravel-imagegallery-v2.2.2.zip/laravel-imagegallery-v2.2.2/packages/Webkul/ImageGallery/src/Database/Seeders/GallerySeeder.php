<?php

namespace Webkul\ImageGallery\Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GallerySeeder extends Seeder
{
    /**
     * Run the database seeds.
     * 
     * @param  array  $parameters
     */
    public function run($parameters = []): void
    {
        $defaultLocale = $parameters['default_locale'] ?? config('app.locale');

        $imageGallery = DB::table('theme_customizations')
            ->where('name', '=', 'Image Gallery')
            ->first();

        if (! $imageGallery) {
            DB::table('theme_customizations')->insert([
                [
                    'type'       => 'static_content',
                    'name'       => 'Image Gallery',
                    'sort_order' => 2,
                    'status'     => 1,
                    'channel_id' => 1,
                    'created_at' => Carbon::now(),
                    'updated_at' => Carbon::now(),
                ],
            ]);
        }

        $locales = $parameters['allowed_locales'] ?? [$defaultLocale];

        if ($imageGallery) {
            foreach ($locales as $locale) {
                DB::table('theme_customization_translations')   
                    ->insert([
                        [
                            'theme_customization_id' => $imageGallery->id,
                            'locale'                 => $locale,
                            'options'                => json_encode([
                                'css'  => '',
                                'html' => '<button class="secondary-button" style="display: block;margin-left: auto !important;margin-right: auto;">'.trans('image-gallery::app.shop.components.categories.view-gallery', [], $locale).'</button>',
                            ]),
                        ],
                ]);
            }
        }
    }
}