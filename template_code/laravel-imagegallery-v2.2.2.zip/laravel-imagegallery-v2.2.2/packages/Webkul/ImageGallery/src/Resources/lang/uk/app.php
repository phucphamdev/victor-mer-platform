<?php

return [   
    'admin' => [
        'configuration' => [
            'image-gallery' => [
                'info'  => 'Галерея Зображень',
                'title' => 'Галерея Зображень',

                'setting' => [
                    'info'  => 'Встановити одиниці параметрів для галереї зображень',
                    'title' => 'Налаштування',

                    'image-options' => [
                        'gallery-setting' => 'Налаштування Галереї',
                        'info'            => 'Встановити ефект відкривання, ефект закривання, підпис та інше.',
                        
                        'image-gallery-show' => [
                            'disable' => 'Вимкнути',
                            'enable'  => 'Увімкнути',
                            'title'   => 'Показ Галереї Зображень',
                        ],

                        'opening-effect' => [
                            'elastic' => 'Еластичний',
                            'fade'    => 'Зникання',
                            'none'    => 'Відсутній',
                            'title'   => 'Ефект Відкривання',
                        ],

                        'closing-effect' => [
                            'elastic' => 'Еластичний',
                            'fade'    => 'Зникання',
                            'none'    => 'Відсутній',
                            'title'   => 'Ефект Закривання',
                        ],

                        'caption' => [
                            'no'    => 'Ні',
                            'title' => 'Підпис',
                            'yes'   => 'Так',
                        ],

                        'caption-type' => [
                            'float'   => 'Плаваючий',
                            'info'    => "'float' та 'over' працюють з позицією 'bottom'.",
                            'inside'  => 'Всередині',
                            'outside' => 'Ззовні',
                            'over'    => 'Над',
                            'title'   => 'Тип Підпису',
                        ],

                        'caption-position' => [
                            'bottom' => 'Знизу',
                            'title'  => 'Позиція Підпису',
                            'top'    => 'Зверху',
                        ],

                        'background' => [
                            'dark'  => 'Темний',
                            'light' => 'Світлий',
                            'title' => 'Фон',
                        ],

                        'cyclic' => [
                            'no'    => 'Ні',
                            'title' => 'Циклічний',
                            'yes'   => 'Так',
                        ],

                        'interval' => [
                            'info'  => 'Тільки числові значення і мають бути між 5000 і 99999',
                            'title' => 'Інтервал',
                        ],

                        'border' => [
                            'no'    => 'Ні',
                            'title' => 'Межа',
                            'yes'   => 'Так',
                        ],

                        'slide-count' => [
                            'no'    => 'Ні',
                            'title' => 'Кількість Слайдів',
                            'yes'   => 'Так',
                        ],

                        'controls' => [
                            'no'    => 'Ні',
                            'title' => 'Керування',
                            'yes'   => 'Так',
                        ],
                    ],
                ],
            ],
        ],

        'layouts' => [
            'image-gallery'  => 'Галерея Зображень',
            'manage-gallery' => 'Керування Галереєю',
            'manage-groups'  => 'Керування Групами',
            'manage-images'  => 'Керування Зображеннями',
        ],

        'image-gallery' => [
            'manage-images' => [
                'index' => [
                    'create' => 'Додати зображення',
                    'title'  => 'Управління зображеннями',
                ],

                'create' => [
                    'back-btn'    => 'Назад',
                    'description' => 'Опис',
                    'disable'     => 'Вимкнути',
                    'enable'      => 'Увімкнути',
                    'general'     => 'Загальні',
                    'image'       => 'Зображення',
                    'page-title'  => 'Додати зображення',
                    'save-btn'    => 'Зберегти зображення',
                    'sort'        => 'Сортувати',
                    'status'      => 'Статус',
                    'title'       => 'Назва',
                ],

                'edit' => [
                    'back-btn'    => 'Назад',
                    'description' => 'Опис',
                    'disable'     => 'Вимкнути',
                    'enable'      => 'Увімкнути',
                    'general'     => 'Загальні',
                    'image'       => 'Зображення',
                    'page-title'  => 'Редагувати зображення',
                    'save-btn'    => 'Зберегти зображення',
                    'sort'        => 'Сортувати',
                    'status'      => 'Статус',
                    'title'       => 'Назва',
                ],

                'create-success'      => 'Зображення успішно додано.',
                'delete-failed'       => 'Не вдалося видалити зображення.',
                'delete-success'      => 'Зображення успішно видалено.',
                'image-error'         => 'Зображення не знайдено.',
                'image-required'      => 'Поле зображення обов\'язкове.',
                'mass-delete-success' => 'Вибрані зображення успішно видалено.',
                'mass-update-success' => 'Вибрані зображення успішно оновлено.',
                'update-success'      => 'Зображення успішно оновлено.',
            ],

            'manage-gallery' => [
                'index' => [
                    'code-note' => 'Примітка: Код галереї повинен бути алфавітно-цифровим без пробілів або спеціальних символів.',
                    'create'    => 'Створити галерею',
                    'title'     => 'Управління галереєю',
                ],

                'create' => [
                    'back-btn'           => 'Назад',
                    'description'        => 'Опис',
                    'disable'            => 'Вимкнути',
                    'enable'             => 'Увімкнути',
                    'gallery-code'       => 'Код галереї',
                    'gallery-image'      => 'Зображення галереї',
                    'gallery'            => 'Галерея',
                    'id'                 => 'ID',
                    'image-title'        => 'Назва зображення',
                    'page-title'         => 'Додати галерею',
                    'save-btn'           => 'Зберегти галерею',
                    'sort'               => 'Сортувати',
                    'status'             => 'Статус',
                    'thumbnail-image-id' => 'ID ескізу',
                    'thumbnail'          => 'Ескіз',
                    'title'              => 'Назва',
                ],

                'edit' => [
                    'back-btn'      => 'Назад',
                    'disable'       => 'Вимкнути',
                    'enable'        => 'Увімкнути',
                    'gallery-code'  => 'Код галереї',
                    'gallery-image' => 'Зображення галереї',
                    'gallery'       => 'Галерея',
                    'page-title'    => 'Редагувати галерею',
                    'save-btn'      => 'Зберегти галерею',
                    'status'        => 'Статус',
                    'title'         => 'Назва',
                ],

                'create-success'      => 'Галерею успішно створено.',
                'delete-failed'       => 'Не вдалося видалити галерею.',
                'delete-success'      => 'Галерею успішно видалено.',
                'mass-delete-success' => 'Вибрані галереї успішно видалено.',
                'mass-update-success' => 'Вибрані галереї успішно оновлено.',
                'update-success'      => 'Галерею успішно оновлено.',
            ],

            'manage-groups' => [
                'index' => [
                    'code-note' => 'Примітка: Код групи повинен бути алфавітно-цифровим без пробілів або спеціальних символів.',
                    'create'    => 'Створити групу',
                    'title'     => 'Управління групами',
                ],

                'create' => [
                    'back-btn'           => 'Назад',
                    'disable'            => 'Вимкнути',
                    'enable'             => 'Увімкнути',
                    'gallery-code'       => 'Код галереї',
                    'gallery-title'      => 'Назва галереї',
                    'group-code'         => 'Код групи',
                    'group'              => 'Група',
                    'id'                 => 'ID',
                    'image-ids'          => 'ID зображень',
                    'page-title'         => 'Додати групу',
                    'save-btn'           => 'Зберегти групу',
                    'status'             => 'Статус',
                    'thumbnail-image-id' => 'ID ескізу',
                ],

                'edit' => [
                    'back-btn'      => 'Назад',
                    'disable'       => 'Вимкнути',
                    'enable'        => 'Увімкнути',
                    'group-code'    => 'Код групи',
                    'group'         => 'Група',
                    'page-title'    => 'Редагувати групу',
                    'save-btn'      => 'Зберегти групу',
                    'status'        => 'Статус',
                ],

                'create-success'      => 'Групу успішно створено.',
                'delete-failed'       => 'Не вдалося видалити групу.',
                'delete-success'      => 'Групу успішно видалено.',
                'mass-delete-success' => 'Вибрані групи успішно видалено.',
                'mass-update-success' => 'Вибрані групи успішно оновлено.',
                'update-success'      => 'Групу успішно оновлено.',
            ],

            'datagrid' => [
                'delete'              => 'Видалити',
                'description'         => 'Опис',
                'disable'             => 'Вимкнути', 
                'edit'                => 'Редагувати',
                'enable'              => 'Увімкнути', 
                'gallery-code'        => 'Код галереї',
                'gallery-ids'         => 'ID галерей',
                'gallery-title'       => 'Назва галереї',
                'group-code'          => 'Код групи',
                'id'                  => 'ID',
                'image-ids'           => 'ID зображень',
                'image-title'         => 'Назва зображення',
                'sort'                => 'Сортувати', 
                'status'              => 'Статус', 
                'thumbnail-image-id'  => 'ID ескізу',
                'thumbnail'           => 'Ескіз', 
                'update'              => 'Оновити',
            ],
        ],
    ], 

    'shop' => [
       'components' => [
            'categories' => [
                'view-gallery' => 'Переглянути галерею',
            ],
        ],

        'image-gallery' => [
            'gallery'          => 'Галерея',
            'images'           => 'Зображення',
            'no-gallery-found' => 'Галерея не знайдена.',
            'no-image-found'   => 'Зображення не знайдено.',
            'view-gallery'     => 'Переглянути галерею',
        ],
    ],
];