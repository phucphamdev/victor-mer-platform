<?php

return [   
    'admin' => [
        'configuration' => [
            'image-gallery' => [
                'info'  => 'চিত্র গ্যালারি',
                'title' => 'চিত্র গ্যালারি',

                'setting' => [
                    'info'  => 'চিত্র গ্যালারির জন্য ইউনিট অপশন সেট করুন',
                    'title' => 'সেটিং',
                    
                    'image-options' => [
                        'gallery-setting' => 'গ্যালারি সেটিং',
                        'info'            => 'খোলার প্রভাব, বন্ধ প্রভাব, ক্যাপশন এবং অন্যান্য সেট করুন।',
                        
                        'image-gallery-show' => [
                            'disable' => 'নিষ্ক্রিয় করুন',
                            'enable'  => 'সক্ষম করুন',
                            'title'   => 'চিত্র গ্যালারি দেখান',
                        ],

                        'opening-effect' => [
                            'elastic' => 'ইলাস্টিক',
                            'fade'    => 'ফেড',
                            'none'    => 'কোনো',
                            'title'   => 'খোলার প্রভাব',
                        ],

                        'closing-effect' => [
                            'elastic' => 'ইলাস্টিক',
                            'fade'    => 'ফেড',
                            'none'    => 'কোনো',
                            'title'   => 'বন্ধ প্রভাব',
                        ],

                        'caption' => [
                            'no'    => 'না',
                            'title' => 'ক্যাপশন',
                            'yes'   => 'হ্যাঁ',
                        ],

                        'caption-type' => [
                            'float'   => 'ফ্লোট',
                            'info'    => "'ফ্লোট' এবং 'ওভার' বস্তু পজিশন 'নিচে' এর সাথে কাজ করে।",
                            'inside'  => 'অন্তর্ভুক্ত',
                            'outside' => 'বাইরে',
                            'over'    => 'ওভার',
                            'title'   => 'ক্যাপশন টাইপ',
                        ],

                        'caption-position' => [
                            'bottom' => 'নিচে',
                            'title'  => 'ক্যাপশন পজিশন',
                            'top'    => 'উপরে',
                        ],

                        'background' => [
                            'dark'  => 'অন্ধকার',
                            'light' => 'আলো',
                            'title' => 'পেছনের দিক',
                        ],

                        'cyclic' => [
                            'no'    => 'না',
                            'title' => 'সাইক্লিক',
                            'yes'   => 'হ্যাঁ',
                        ],

                        'interval' => [
                            'info'  => 'শুধুমাত্র সংখ্যাসূচক মান এবং ৫০০০ থেকে ৯৯৯৯৯ এর মধ্যে হতে হবে',
                            'title' => 'ইন্টারভাল',
                        ],

                        'border' => [
                            'no'    => 'না',
                            'title' => 'বর্ডার',
                            'yes'   => 'হ্যাঁ',
                        ],

                        'slide-count' => [
                            'no'    => 'না',
                            'title' => 'স্লাইড গণনা',
                            'yes'   => 'হ্যাঁ',
                        ],

                        'controls' => [
                            'no'    => 'No',
                            'title' => 'Controls',
                            'yes'   => 'Yes',
                        ],
                    ],
                ],
            ],
        ],

        'layouts' => [
            'image-gallery'  => 'চিত্র গ্যালারি',
            'manage-gallery' => 'গ্যালারি পরিচালনা',
            'manage-groups'  => 'গ্রুপ পরিচালনা',
            'manage-images'  => 'চিত্র পরিচালনা',
        ],

        'image-gallery' => [
            'manage-images' => [
                'index' => [
                    'create' => 'ছবি যোগ করুন',
                    'title'  => 'ছবি পরিচালনা করুন',
                ],

                'create' => [
                    'back-btn'    => 'পিছনে',
                    'description' => 'বিবরণ',
                    'disable'     => 'নিষ্ক্রিয়',
                    'enable'      => 'সক্রিয়',
                    'general'     => 'সাধারণ',
                    'image'       => 'ছবি',
                    'page-title'  => 'ছবি যোগ করুন',
                    'save-btn'    => 'ছবি সংরক্ষণ করুন',
                    'sort'        => 'বিন্যস্ত করুন',
                    'status'      => 'অবস্থা',
                    'title'       => 'শিরোনাম',
                ],

                'edit' => [
                    'back-btn'    => 'পিছনে',
                    'description' => 'বিবরণ',
                    'disable'     => 'নিষ্ক্রিয়',
                    'enable'      => 'সক্রিয়',
                    'general'     => 'সাধারণ',
                    'image'       => 'ছবি',
                    'page-title'  => 'ছবি সম্পাদনা করুন',
                    'save-btn'    => 'ছবি সংরক্ষণ করুন',
                    'sort'        => 'বিন্যস্ত করুন',
                    'status'      => 'অবস্থা',
                    'title'       => 'শিরোনাম',
                ],

                'create-success'      => 'ছবি সফলভাবে তৈরি হয়েছে।',
                'delete-failed'       => 'ছবি মুছে ফেলা সম্ভব হয়নি।',
                'delete-success'      => 'ছবি সফলভাবে মুছে ফেলা হয়েছে।',
                'image-error'         => 'ছবি পাওয়া যায়নি।',
                'image-required'      => 'ছবির ক্ষেত্র আবশ্যক।',
                'mass-delete-success' => 'নির্বাচিত ছবিগুলি সফলভাবে মুছে ফেলা হয়েছে।',
                'mass-update-success' => 'নির্বাচিত ছবিগুলি সফলভাবে আপডেট করা হয়েছে।',
                'update-success'      => 'ছবি সফলভাবে আপডেট হয়েছে।',
            ],

            'manage-gallery' => [
                'index' => [
                    'code-note' => 'নোট: গ্যালারি কোডটি অবশ্যই অ্যালফানিউমেরিক হতে হবে, কোন স্পেস বা বিশেষ অক্ষর ছাড়া।',
                    'create'    => 'গ্যালারি তৈরি করুন',
                    'title'     => 'গ্যালারি পরিচালনা করুন',
                ],

                'create' => [
                    'back-btn'           => 'পিছনে',
                    'description'        => 'বিবরণ',
                    'disable'            => 'নিষ্ক্রিয়',
                    'enable'             => 'সক্রিয়',
                    'gallery-code'       => 'গ্যালারি কোড',
                    'gallery-image'      => 'গ্যালারি ছবি',
                    'gallery'            => 'গ্যালারি',
                    'id'                 => 'আইডি',
                    'image-title'        => 'ছবির শিরোনাম',
                    'page-title'         => 'গ্যালারি যোগ করুন',
                    'save-btn'           => 'গ্যালারি সংরক্ষণ করুন',
                    'sort'               => 'বিন্যস্ত করুন',
                    'status'             => 'অবস্থা',
                    'thumbnail-image-id' => 'ছবির থাম্বনেইল আইডি',
                    'thumbnail'          => 'থাম্বনেইল',
                    'title'              => 'শিরোনাম',
                ],

                'edit' => [
                    'back-btn'      => 'পিছনে',
                    'disable'       => 'নিষ্ক্রিয়',
                    'enable'        => 'সক্রিয়',
                    'gallery-code'  => 'গ্যালারি কোড',
                    'gallery-image' => 'গ্যালারি ছবি',
                    'gallery'       => 'গ্যালারি',
                    'page-title'    => 'গ্যালারি সম্পাদনা করুন',
                    'save-btn'      => 'গ্যালারি সংরক্ষণ করুন',
                    'status'        => 'অবস্থা',
                    'title'         => 'শিরোনাম',
                ],

                'create-success'      => 'গ্যালারি সফলভাবে তৈরি হয়েছে।',
                'delete-failed'       => 'গ্যালারি মুছে ফেলা সম্ভব হয়নি।',
                'delete-success'      => 'গ্যালারি সফলভাবে মুছে ফেলা হয়েছে।',
                'mass-delete-success' => 'নির্বাচিত গ্যালারিগুলি সফলভাবে মুছে ফেলা হয়েছে।',
                'mass-update-success' => 'নির্বাচিত গ্যালারিগুলি সফলভাবে আপডেট করা হয়েছে।',
                'update-success'      => 'গ্যালারি সফলভাবে আপডেট হয়েছে।',
            ],

            'manage-groups' => [
                'index' => [
                    'code-note' => 'নোট: গ্রুপ কোডটি অবশ্যই অ্যালফানিউমেরিক হতে হবে, কোন স্পেস বা বিশেষ অক্ষর ছাড়া।',
                    'create'    => 'গ্রুপ তৈরি করুন',
                    'title'     => 'গ্রুপ পরিচালনা করুন',
                ],

                'create' => [
                    'back-btn'           => 'পিছনে',
                    'disable'            => 'নিষ্ক্রিয়',
                    'enable'             => 'সক্রিয়',
                    'gallery-code'       => 'গ্যালারি কোড',
                    'gallery-title'      => 'গ্যালারি শিরোনাম',
                    'group-code'         => 'গ্রুপ কোড',
                    'group'              => 'গ্রুপ',
                    'id'                 => 'আইডি',
                    'image-ids'          => 'ছবির আইডি',
                    'page-title'         => 'গ্রুপ যোগ করুন',
                    'save-btn'           => 'গ্রুপ সংরক্ষণ করুন',
                    'status'             => 'অবস্থা',
                    'thumbnail-image-id' => 'ছবির থাম্বনেইল আইডি',
                ],

                'edit' => [
                    'back-btn'      => 'পিছনে',
                    'disable'       => 'নিষ্ক্রিয়',
                    'enable'        => 'সক্রিয়',
                    'group-code'    => 'গ্রুপ কোড',
                    'group'         => 'গ্রুপ',
                    'page-title'    => 'গ্রুপ সম্পাদনা করুন',
                    'save-btn'      => 'গ্যালারি সংরক্ষণ করুন',
                    'status'        => 'অবস্থা',
                ],

                'create-success'      => 'গ্রুপ সফলভাবে তৈরি হয়েছে।',
                'delete-failed'       => 'গ্রুপ মুছে ফেলা সম্ভব হয়নি।',
                'delete-success'      => 'গ্রুপ সফলভাবে মুছে ফেলা হয়েছে।',
                'mass-delete-success' => 'নির্বাচিত গ্রুপগুলি সফলভাবে মুছে ফেলা হয়েছে।',
                'mass-update-success' => 'নির্বাচিত গ্রুপগুলি সফলভাবে আপডেট করা হয়েছে।',
                'update-success'      => 'গ্রুপ সফলভাবে আপডেট হয়েছে।',
            ],

            'datagrid' => [
                'delete'              => 'মুছে ফেলুন',
                'description'         => 'বিবরণ',
                'disable'             => 'নিষ্ক্রিয়', 
                'edit'                => 'সম্পাদনা',
                'enable'              => 'সক্রিয়', 
                'gallery-code'        => 'গ্যালারি কোড',
                'gallery-ids'         => 'গ্যালারি আইডি',
                'gallery-title'       => 'গ্যালারি শিরোনাম',
                'group-code'          => 'গ্রুপ কোড',
                'id'                  => 'আইডি',
                'image-ids'           => 'ছবির আইডি',
                'image-title'         => 'ছবির শিরোনাম',
                'sort'                => 'বিন্যস্ত করুন', 
                'status'              => 'অবস্থা', 
                'thumbnail-image-id'  => 'ছবির থাম্বনেইল আইডি',
                'thumbnail'           => 'থাম্বনেইল', 
                'update'              => 'আপডেট',
            ],
        ],
    ], 

    'shop' => [
       'components' => [
            'categories' => [
                'view-gallery' => 'গ্যালারি দেখুন',
            ],
        ],

        'image-gallery' => [
            'gallery'          => 'গ্যালারি',
            'images'           => 'ছবি',
            'no-gallery-found' => 'গ্যালারি পাওয়া গেল না।',
            'no-image-found'   => 'চিত্র পাওয়া গেল না।',
            'view-gallery'     => 'গ্যালারি দেখুন',
        ],
    ],
];