<?php

namespace Webkul\ImageGallery\Contracts;

interface ManageGallery
{
}