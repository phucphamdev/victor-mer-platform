<?php

namespace Webkul\ImageGallery\Contracts;

interface ManageGroup
{
}