<?php

namespace Webkul\ImageGallery\Contracts;

interface ImageGallery
{
}