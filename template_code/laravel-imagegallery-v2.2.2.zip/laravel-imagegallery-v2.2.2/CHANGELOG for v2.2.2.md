# CHANGELOG for v2.2.2

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v2.2.2(21st of Nov 2024)** - *Release*

* [compatability] compatible Bagisto v2.2.2

* [Bug] Value not saved in multi-locale.

* [Bug] Need to align the column with values on the manage gallery, manage images, manage groups and edit gallery page.

* [Bug] Responsive issue.

* [UI] Shimmer Effect is not present in gallery Image section as well as Layout Shifting in Image gallery section.

* [Buy] Image Title should also have Validation.

* [UI] Proper Spacing between Image and Footer label.


## **v2.0.0(21st of October 2023)** - *Release*

* [compatability] compatible Bagisto 2.0.0

* [Features] Admin can add Images, Images Title, Description text .

* [Features] Admin can add Gallery using Images text .

* [Features] Admin can add Group of Gallery.

* [Features] Admin can allow the style for opening and closing the Image.

* [Features] Admin can allow to show the title of image.

* [Features] Admin can decide also the position of title.

* [Features] User will able to see Galleries on Home Page.

* [Features] User can see all the Images while clicking on the Gallery

* [Features] For seeing any particular image user can click on any image and from there can also control the image to see next or previous image .


## **v1.3.1(1st of March 2023)** - *Release*

[compatability] compatible Bagisto 1.3.0

### 1. Features:

* Admin can add Images , Images Title, Description text .

* Admin can add Gallery using Images text .

* Admin can add Group of Gallery .

* Admin can allow the style for opening and closing the Image.

* Admin can allow to show the title of image.

* Admin can decide also the position of title.

* User will able to see Galleries on Home Page.

* User can see all the Images while clicking on the Gallery

* For seeing any particular image user can click on any image and from there can also control the image to see next or previous image .