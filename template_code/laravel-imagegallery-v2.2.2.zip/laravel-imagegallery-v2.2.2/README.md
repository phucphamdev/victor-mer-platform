### 1. Introduction:

Bagisto Image Gallery Extension will convert your Bagisto store into a multi vendor marketplace with separate seller product collection, order management, feedback support ratings and commissions.

It packs in lots of demanding features that allows your business to scale in no time:


### 2. Features:

* Admin can add Images , Images Title, Description text .

* Admin can add Gallery using Images text .

* Admin can add Group of Gallery .

* Admin can allow the style for opening and closing the Image.

* Admin can allow to show the title of image.

* Admin can decide also the position of title.

* User will able to see Galleries on Home Page.

* User can see all the Images while clicking on the Gallery

* For seeing any particular image user can click on any image and from there can also control the image to see next or previous image .


### 3. Requirements:

* **Bagisto**: v2.2.2


### 4. Installation:

* Unzip the respective extension zip and then merge "packages" and "public" folder into project root directory.

* Goto config/app.php file and add following line under 'providers'

~~~
Webkul\ImageGallery\Providers\ImageGalleryServiceProvider::class
~~~

* Goto composer.json file and add following line under 'psr-4'

~~~
"Webkul\\ImageGallery\\": "packages/Webkul/ImageGallery/src"
~~~

* Goto config/bagisto-vite.php and add following line under 'viters'

~~~
'image-gallery' => [
    'hot_file'                 => 'image-gallery-vite.hot',
    'build_directory'          => 'themes/image-gallery/default/build',
    'package_assets_directory' => 'src/Resources/assets',
],
~~~

* Run these commands below to complete the setup

~~~
composer dump-autoload
~~~

~~~
php artisan image-gallery:install
~~~

~~~
php artisan db:seed --class=Webkul\\ImageGallery\\Database\\Seeders\\GallerySeeder
~~~

~~~
php artisan optimize:clear
~~~
> That's it, now just execute the project on your specified domain.