<?php

return [
    'ups' => [
        'code'          => 'ups',
        'title'         => 'UPS Shipping',
        'description'   => 'UPS Shipping',
        'active'        => true,
        'class'         => 'Webkul\UpsShipping\Carriers\Ups',
    ]
];