# CHANGELOG for v1.3.x

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v1.3.3(13th of Apr, 2022)** - *Release*

* [feature] Compatible for v1.3.3.

* [bug] Wrong calculated rate from the ups api.

## **v1.3.2(23rd of October, 2021)** - *Release*

* [feature] Compatible for v1.3.2

## **v1.3.1(13th of Mar, 2021)** - *Release*

* [feature] Compatible for v1.3.1

* [Fixed][#8] Add calculate tax options in shipping method.

* [Fixed][#9] All required fields should be disable when module status is disabled.

* [Fixed][#11] UPS Shipping is not coming on checkout page.


## **v1.2.0(1 of October, 2020)** - *Release*


[feature] The admin can enable or disable the ups Shipping method.

[feature] The admin can set the ups shipping method name that will be shown from 
the front side.

[feature] The admin can define the allowed methods and weight units.

[feature] The admin can set packaging type and drop off type.

[feature] Dynamic shipping method for freight calculation.