<?php

/**
 * APIs for version 1.
 */
require 'V1/api.php';
