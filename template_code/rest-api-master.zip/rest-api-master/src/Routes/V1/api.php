<?php

/**
 * Shop routes.
 */
require 'Shop/shop.php';

/**
 * Admin routes.
 */
require 'Admin/admin.php';
