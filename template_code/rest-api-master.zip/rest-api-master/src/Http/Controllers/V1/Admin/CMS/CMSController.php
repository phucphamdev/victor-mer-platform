<?php

namespace Webkul\RestApi\Http\Controllers\V1\Admin\CMS;

use Webkul\RestApi\Http\Controllers\V1\Admin\AdminController;

class CMSController extends AdminController {}
