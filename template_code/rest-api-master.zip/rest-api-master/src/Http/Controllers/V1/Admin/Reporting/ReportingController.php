<?php

namespace Webkul\RestApi\Http\Controllers\V1\Admin\Reporting;

use Webkul\Admin\Http\Controllers\Reporting\Controller as BaseController;

class ReportingController extends BaseController {}
