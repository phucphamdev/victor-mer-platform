<?php

namespace Webkul\RestApi\Http\Controllers\V1\Admin\Customers;

use Webkul\RestApi\Http\Controllers\V1\Admin\AdminController;

class BaseController extends AdminController {}
