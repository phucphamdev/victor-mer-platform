<?php

namespace Webkul\RestApi\Http\Controllers\V1\Admin\Catalog;

use Webkul\RestApi\Http\Controllers\V1\Admin\AdminController;

class CatalogController extends AdminController {}
