<?php

namespace Webkul\RestApi\Http\Controllers\V1\Admin\User;

use Webkul\RestApi\Http\Controllers\V1\Admin\AdminController;

class UserController extends AdminController {}
