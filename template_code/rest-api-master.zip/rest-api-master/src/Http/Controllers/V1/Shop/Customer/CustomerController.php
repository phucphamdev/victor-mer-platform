<?php

namespace Webkul\RestApi\Http\Controllers\V1\Shop\Customer;

use Webkul\RestApi\Http\Controllers\V1\Shop\ShopController;

class CustomerController extends ShopController {}
