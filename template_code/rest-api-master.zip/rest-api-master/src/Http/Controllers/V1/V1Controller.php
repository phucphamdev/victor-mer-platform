<?php

namespace Webkul\RestApi\Http\Controllers\V1;

use Webkul\RestApi\Http\Controllers\RestApiController;

class V1Controller extends RestApiController {}
