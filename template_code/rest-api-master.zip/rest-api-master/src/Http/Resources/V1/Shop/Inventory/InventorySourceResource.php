<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Inventory;

use Webkul\RestApi\Http\Resources\V1\Admin\Settings\InventorySourceResource as AdminInventorySourceResource;

class InventorySourceResource extends AdminInventorySourceResource {}
