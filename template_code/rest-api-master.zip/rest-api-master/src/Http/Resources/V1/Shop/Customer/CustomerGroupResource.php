<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Customer;

use Webkul\RestApi\Http\Resources\V1\Admin\Customer\CustomerGroupResource as AdminCustomerGroupResource;

class CustomerGroupResource extends AdminCustomerGroupResource {}
