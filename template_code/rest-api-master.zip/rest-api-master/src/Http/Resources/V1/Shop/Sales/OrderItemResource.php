<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Sales;

use Webkul\RestApi\Http\Resources\V1\Admin\Sales\OrderItemResource as BaseOrderItemResource;

class OrderItemResource extends BaseOrderItemResource {}
