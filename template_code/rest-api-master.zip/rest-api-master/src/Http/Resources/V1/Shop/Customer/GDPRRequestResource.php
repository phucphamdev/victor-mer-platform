<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Customer;

use Webkul\RestApi\Http\Resources\V1\Admin\Customer\GDPRRequestResource as AdminGDPRRequestResource;

class GDPRRequestResource extends AdminGDPRRequestResource {}
