<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Core;

use Webkul\RestApi\Http\Resources\V1\Admin\Settings\CurrencyResource as AdminCurrencyResource;

class CurrencyResource extends AdminCurrencyResource {}
