# CHANGELOG

This changelog consists of the bug & security fixes and new features being included in the releases listed below.

## **v2.3.1 (4th of August 2025)** - *Release*

* Implemented E-Tag support for improved caching and response optimization.

* Refined and updated Swagger API documentation for better clarity and consistency.

## **v2.3.0 (28th of July 2025)** - *Release*

* [Compatible] - Compatible with Bagisto v2.3.x.
