## **v1.3.1(5th of April, 2021)** - *Release*

* [fixed] Compatibility issue with bagisto 1.3.1.

* [fixed][#20] update readme file for bagisto v1.3.1.

* [fixed][#19] bulk add to cart icon is missing in mobile view.

## **v1.1.2(18th of Dec, 2020)**

* [fix] Compatible with bagisto version 1.2.0.
* [fix] Compatible with all type of product.
* [fix] Added sample for all type of product.
* [fix] Error message while adding quantity more than the available inventory.
* [fix] Added confirmation message on adding the product to the cart.

## **v1.1.1(4th of June, 2020)** - *Release*

* [feature] customers can upload mass data for cart.
* [feature] compatible with all product types.
* [feature] compatible with velocity theme.

