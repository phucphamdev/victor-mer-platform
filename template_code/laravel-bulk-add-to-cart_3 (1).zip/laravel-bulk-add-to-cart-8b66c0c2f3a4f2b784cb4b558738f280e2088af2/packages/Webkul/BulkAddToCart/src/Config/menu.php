<?php

return [
    [
        'key' => 'account.bulk-add-to-cart',
        'name' => 'bulkaddtocart::app.products.bulk-add-to-cart',
        'route' =>'cart.bulk-add-to-cart.create',
        'sort' => 7
    ]
];

?>