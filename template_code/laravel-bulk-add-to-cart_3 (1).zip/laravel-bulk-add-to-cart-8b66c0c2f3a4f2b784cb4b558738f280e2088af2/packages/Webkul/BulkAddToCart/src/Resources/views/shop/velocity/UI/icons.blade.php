<li>
                                            <a href="{{ route('cart.bulk-add-to-cart.create') }}" class="unset">
                                                <i class="icon bulk-add-to-cart text-down-3"></i>
                                                <span>{{ __('bulkaddtocart::app.products.bulk-add-to-cart') }}</span>
                                            </a>
                                        </li>