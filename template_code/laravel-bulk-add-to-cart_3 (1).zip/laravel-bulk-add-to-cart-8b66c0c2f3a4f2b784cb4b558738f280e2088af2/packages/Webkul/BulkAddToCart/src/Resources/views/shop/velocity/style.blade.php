<style>
    .icon.bulk-add-to-cart:before {
        content: "\E917";
    }
</style>
