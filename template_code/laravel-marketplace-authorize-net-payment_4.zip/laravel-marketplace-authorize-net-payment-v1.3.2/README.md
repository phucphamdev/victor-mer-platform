### 1. Introduction:

Laravel Authorize.Net payment – An easy way for online payment. Today we are going to introduce Authorize.Net payment for Laravel.

Authorize.Net make it easy for customers to pay by accepting the payments they prefer, including major credit cards, signature debit cards.

* Enable/disable payment method from admin panel.
* Provide payment directly to the admin account.
* Accept all the cards that Authorize.net supports.
* Buyer can save Authorize.net cards for future payments while paying.
* PCI(Payment Card Industry) Compliance.
* 3D Secure - Added security layer.

### 2. Requirements:

* **Bagisto**: v1.3.2.

### 3. Installation:

* Unzip the respective extension zip and then merge "packages" folder into project root directory.

* Goto config/app.php file and add following line under 'providers'

~~~
Webkul\MpAuthorizeNet\Providers\MpAuthorizeNetServiceProvider::class
~~~

* Goto config/concord.php file and add following line under modules array

~~~
\Webkul\MpAuthorizeNet\Providers\ModuleServiceProvider::class,
~~~

* Goto composer.json file and add following line under 'psr-4'

~~~
"Webkul\\MpAuthorizeNet\\": "packages/Webkul/MpAuthorizeNet/src"
~~~



* Run these commands below to complete the setup

~~~
composer dump-autoload
~~~
~~~
composer require authorizenet/authorizenet
~~~
~~~
php artisan route:cache
~~~
~~~
php artisan migrate
~~~
~~~
php artisan vendor:publish

-> Press 0 and then press enter to publish all assets and configurations.

~~~

> That's it, now just execute the project on your specified domain.



