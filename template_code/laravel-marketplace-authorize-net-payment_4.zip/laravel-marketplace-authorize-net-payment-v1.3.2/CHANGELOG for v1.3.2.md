# CHANGELOG for v1.3.2

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v1.3.2(22nd of September, 2021)** - *Release*

* [feature] Compatible with Bagisto v1.3.2

## **v0.1.6(16th of Jan, 2020)** - *Release*

* [bug] able to select both card and another payment method together in payment method.

## **v0.1.5(15th of Jan, 2020)** - *Release*

* [bug] Exception during payment-fixed.

## **v0.1.4(29th of Oct, 2019)** - *Release*

* [bug] card shown after page refreshment-fixed.

## **v0.1.4(29th of Oct, 2019)** - *Release*

* [bug] card shown after page refreshment-fixed.

## **v0.1.3(16th of Oct, 2019)** - *Release*

* [bug] card shown to all customers-fixed.

## **v0.1.2(17th of Sep, 2019)** - *Release*

* [feature] User can see their saved card under customer section.

* [feature] They can make their saved card as default one.

## **v0.1.1(12th of Sep, 2019)** - *Release*

* [bug] Guest user is not able to make payment with autorize net payment method.

* [bug] Unable to proceed further after entering card details.

## **v0.1.0(12th of Sep, 2019)** - *Release*

* [feature] Enable/disable payment method from admin panel.

* [feature] Provide payment directly to the admin account.

* [feature] Accept all the cards that Authorize.net supports.

* [feature] Buyer can save Authorize.net cards for future payments while paying.

* [feature] PCI(Payment Card Industry) Compliance.

* [feature] 3D Secure - Added security layer.





