<?php

namespace Webkul\MpAuthorizeNet\Models;

use Konekt\Concord\Proxies\ModelProxy;

class MpAuthorizeNetCartProxy extends ModelProxy
{

}