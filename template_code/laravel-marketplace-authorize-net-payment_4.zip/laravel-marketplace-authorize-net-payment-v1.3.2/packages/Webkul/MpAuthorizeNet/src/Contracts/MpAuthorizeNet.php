<?php

namespace Webkul\MpAuthorizeNet\Contracts;

interface MpAuthorizeNet
{
}