<?php

namespace Webkul\MpAuthorizeNet\Contracts;

interface MpAuthorizeNetCart {

}