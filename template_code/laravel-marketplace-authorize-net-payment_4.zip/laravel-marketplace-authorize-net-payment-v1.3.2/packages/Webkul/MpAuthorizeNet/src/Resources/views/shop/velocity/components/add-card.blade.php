<div class="mpauthorizenet-add-card" style="padding-left:27px; margin-top:-15px; margin-bottom:8px; display:none">
    <span class="control-info mb-5 mt-5"> Kindly click
        <a id="open-mpauthorizenet-modal" style="color: #0041FF !important; cursor: pointer;">
            {{ __('mpauthorizenet::app.add-card') }}
        </a>
        or select from saved card below if available before place order.
    </span>
</div>