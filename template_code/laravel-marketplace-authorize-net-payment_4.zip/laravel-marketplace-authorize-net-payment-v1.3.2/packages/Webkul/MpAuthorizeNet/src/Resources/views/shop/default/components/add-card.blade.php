<div class="mpauthorizenet-add-card" style="display:none">
    <span class="control-info mb-5 mt-5">
        <a id="open-mpauthorizenet-modal" style="color: #0041FF !important; cursor: pointer;">
            {{ __('mpauthorizenet::app.add-card') }}
        </a>
    </span>
</div>