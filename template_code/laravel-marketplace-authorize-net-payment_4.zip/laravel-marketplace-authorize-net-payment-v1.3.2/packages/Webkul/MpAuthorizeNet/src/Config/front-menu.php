<?php

return [
    [
        'key' => 'account.savecard',
        'name' => 'mpauthorizenet::app.shop.account.savecard',
        'route' => 'mpauthorizenet.account.save.card', 
        'sort' => 6
    ],

];