<?php

return [
    'mpauthorizenet' => [
        'code' => 'mpauthorizenet',
        'title' => 'Authorize Net',
        'description' => 'Authorize Net',
        'class' => 'Webkul\MpAuthorizeNet\Payment\MpAuthorizeNetPayment',
        'debug' => true,
        'active' => true
    ]
];