<?php

namespace Webkul\Bulkupload\Contracts;

interface ImportProduct
{
}