<?php

namespace Webkul\Bulkupload\Contracts;

interface DataFlowProfile
{
}