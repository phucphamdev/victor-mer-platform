<?php

namespace Webkul\Bulkupload\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ImportProductProxy extends ModelProxy
{
}