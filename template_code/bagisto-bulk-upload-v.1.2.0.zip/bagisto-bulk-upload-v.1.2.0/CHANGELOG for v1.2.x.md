# CHANGELOG for v1.1.x

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v1.2.0(25th of November, 2020)** - _Release_

- [compatible] Compatible with bagisto v1.2.0
- [Feature] Added functionality to upload product attribute of type like select and checkbox.
