<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'تحویل در محل فروشگاه',
            'display_address' => 'آدرس تحویل را در فرم تسویه حساب نشان دهید'
        ]
    ]
];