<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'Retrait au magasin',
            'display_address' => 'Afficher l\'adresse de prise en charge dans le formulaire de paiement'
        ]
    ]
];