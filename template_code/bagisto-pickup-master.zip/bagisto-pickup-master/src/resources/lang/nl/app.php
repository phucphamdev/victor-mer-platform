<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'Ophalen in de winkel',
            'display_address' => 'Toon het afhaaladres in het afrekenformulier' 
        ]
    ]
];