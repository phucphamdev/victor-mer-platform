<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'mağazadan alma',
            'display_address' => 'Ödeme formunda teslim alma adresini gösterin' 
        ]
    ]
];