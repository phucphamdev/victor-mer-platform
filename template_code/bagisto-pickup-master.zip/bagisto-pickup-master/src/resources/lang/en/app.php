<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'Picking up at the store',
            'display_address' => 'Show the pick-up address in the checkout form' 
        ]
    ]
];