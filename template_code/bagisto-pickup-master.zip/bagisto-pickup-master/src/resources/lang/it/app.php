<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'Ritiro in negozio',
            'display_address' => 'Mostra l\'indirizzo di ritiro nel modulo di pagamento'
        ]
    ]
];