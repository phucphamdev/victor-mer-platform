<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'Recoger en la tienda',
            'display_address' => 'Mostrar la dirección de recogida en el formulario de pago' 
        ]
    ]
];