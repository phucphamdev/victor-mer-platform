<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'Pegando na loja',
            'display_address' => 'Mostre o endereço de retirada no formulário de checkout' 
        ]
    ]
];