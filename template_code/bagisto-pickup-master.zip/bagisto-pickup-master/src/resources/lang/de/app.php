<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'Abholung im Laden',
            'display_address' => 'Zeigen Sie die Abholadresse im Checkout-Formular an'
        ]
    ]
];