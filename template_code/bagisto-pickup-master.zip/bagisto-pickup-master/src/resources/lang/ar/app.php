<?php

return [
    'admin' => [
        'system' => [
            'pickup'          => 'الاستلام في المتجر',
            'display_address' => 'أظهر عنوان الاستلام في نموذج الخروج' 
        ]
    ]
];