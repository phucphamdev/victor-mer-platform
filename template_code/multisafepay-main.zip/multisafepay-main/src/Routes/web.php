<?php

/**
 * Multisafepay routes.
 */

require 'checkout-routes.php';

require 'pay-routes.php';
