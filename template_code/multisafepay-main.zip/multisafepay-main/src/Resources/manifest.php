<?php

return [
    'name'    => 'Bagisto MultiSafepay',
    'version' => '1.1.0',
];
