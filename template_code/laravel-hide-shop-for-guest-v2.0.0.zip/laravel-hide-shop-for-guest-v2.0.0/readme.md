### 1. Introduction:

Hide shop for guest module will allow all the users coming to your shop to register themselves
and then they can proceed to shop.

This addon is a mini addon but have a very powerful use case scenario.

### 2. Requirements:

* **Bagisto**: v2.0.0


### 3. Installation:

* Unzip the respective extension zip and then merge "packages" folders into project root directory.

* Goto composer.json file and add following line under 'psr-4'

```
"Webkul\\HideShopForGuest\\": "packages/Webkul/HideShopForGuest/src"

```

* Goto config/app.php file and add following line under 'providers'


```
Webkul\HideShopForGuest\Providers\HideShopForGuestServiceProvider::class,

```

3. Goto app/Http/Kernel.php:

Inside this file you will find an array named _\$middlewareGroups_, paste this inside it:

```
\Webkul\HideShopForGuest\Http\Middleware\HideShopForGuest::class

```

* Run these commands below to complete the setup

~~~
composer dump-autoload
~~~

~~~
php artisan optimize:clear
~~~

> now execute the project on your specified domain.
