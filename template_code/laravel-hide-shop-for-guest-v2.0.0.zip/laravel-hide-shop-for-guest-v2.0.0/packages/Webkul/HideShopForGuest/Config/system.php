<?php

return [
    [
        'key'  => 'hide-shop-for-guest',
        'name' => 'hide_shop_for_guest::app.admin.configuration.general.title',
        'info' => 'hide_shop_for_guest::app.admin.configuration.general.info',
        'sort' => 5,
    ], [
        'key'  => 'hide-shop-for-guest.settings',
        'name' => 'hide_shop_for_guest::app.admin.configuration.general.title',
        'info' => 'hide_shop_for_guest::app.admin.configuration.general.desc-info',
        'icon' => 'settings/store.svg',
        'sort' => 1,
    ], [
        'key'  => 'hide-shop-for-guest.settings.settings',
        'name' => 'hide_shop_for_guest::app.admin.configuration.general.setting',
        'info' => 'hide_shop_for_guest::app.admin.configuration.general.desc-info',
        'sort' => 1,
        'fields' => [
            [
                'name'          => 'hide-shop-before-login',
                'title'         => 'hide_shop_for_guest::app.admin.configuration.general.status.title',
                'type'          => 'boolean',
                'channel_based' => true,
                'locale_based'  => true,
            ], [
                'name'          => 'hide-shop-before-login-notification',
                'title'         => 'hide_shop_for_guest::app.admin.configuration.general.status.notification',
                'type'          => 'text',
                'channel_based' => true,
                'locale_based'  => true,
            ],
        ],
    ],
];
