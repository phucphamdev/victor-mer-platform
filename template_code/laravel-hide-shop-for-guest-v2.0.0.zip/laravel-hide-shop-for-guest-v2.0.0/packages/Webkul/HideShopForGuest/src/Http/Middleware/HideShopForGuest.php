<?php

namespace Webkul\HideShopForGuest\Http\Middleware;

use Closure;

class HideShopForGuest
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (core()->getConfigData('hide-shop-for-guest.settings.settings.hide-shop-before-login')) {
            if (
                ! auth()->guard('customer')->check()
                && ! request()->is('customer/*')
                && ! request()->is('admin/*')
            ) {
                if (core()->getConfigData('hide-shop-for-guest.settings.settings.hide-shop-before-login-notification')) {
                    session()->flash('error', core()->getConfigData('hide-shop-for-guest.settings.settings.hide-shop-before-login-notification'));
                }

                return redirect()->route('shop.customer.session.index');
            }
        }

        return $next($request);
    }
}
