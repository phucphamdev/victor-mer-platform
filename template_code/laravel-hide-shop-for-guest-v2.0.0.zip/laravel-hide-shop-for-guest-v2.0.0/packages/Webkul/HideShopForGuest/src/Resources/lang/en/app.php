<?php

return [
    'admin' => [
        'configuration' => [
            'general' => [
                'title'     => 'Hide Shop for guest',
                'info'      => 'Hide Shop for guest',
                'desc-info' => 'Hide their storefront from the guest user or unregistered customers of their website',
                'setting'   => 'Setting',

                'status' => [
                    'title'        => 'Hide shop for guest',
                    'notification' => 'Notification for customer',
                ],
            ],
        ],
    ],
];