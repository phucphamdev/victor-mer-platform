<?php

return [
    'admin' => [
        'configuration' => [
            'general' => [
                'title'     => 'Shop für Gäste verstecken',
                'info'      => 'Shop für Gäste verstecken',
                'desc-info' => 'Versteckt ihren Shopfront vom Gastbenutzer oder nicht registrierten Kunden ihrer Website',
                'setting'   => 'Einstellung',

                'status' => [
                    'title'        => 'Shop für Gäste verstecken',
                    'notification' => 'Benachrichtigung für Kunden',
                ],
            ],
        ],
    ],
];
