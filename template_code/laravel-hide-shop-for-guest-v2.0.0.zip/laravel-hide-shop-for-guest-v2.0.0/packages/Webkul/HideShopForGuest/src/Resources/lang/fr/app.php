<?php

return [
    'admin' => [
        'configuration' => [
            'general' => [
                'title'     => 'Masquer la boutique pour les invités',
                'info'      => 'Masquer la boutique pour les invités',
                'desc-info' => 'Masquer leur boutique aux utilisateurs invités ou aux clients non enregistrés de leur site web',
                'setting'   => 'Réglage',

                'status' => [
                    'title'        => 'Masquer la boutique pour les invités',
                    'notification' => 'Notification pour le client',
                ],
            ],
        ],
    ],
];