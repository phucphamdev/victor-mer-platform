<?php

return [
    'admin' => [
        'configuration' => [
            'general' => [
                'title'     => 'Verberg winkel voor gasten',
                'info'      => 'Verberg winkel voor gasten',
                'desc-info' => 'Verberg hun winkelfront voor gastgebruikers of niet-geregistreerde klanten van hun website',
                'setting'   => 'Instelling',

                'status' => [
                    'title'        => 'Verberg winkel voor gasten',
                    'notification' => 'Melding voor klant',
                ],
            ],
        ],
    ],
];