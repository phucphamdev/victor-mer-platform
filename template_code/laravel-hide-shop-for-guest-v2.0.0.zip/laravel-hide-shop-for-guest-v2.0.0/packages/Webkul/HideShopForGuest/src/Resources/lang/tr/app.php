<?php

return [
    'admin' => [
        'configuration' => [
            'general' => [
                'title'     => 'Misafirler için Mağazayı Gizle',
                'info'      => 'Misafirler için Mağazayı Gizle',
                'desc-info' => 'Web sitelerinin misafir kullanıcıları veya kayıtlı olmayan müşterileri için mağaza ön yüzünü gizleyin.',
                'setting'   => 'Ayar',

                'status' => [
                    'title'        => 'Misafirler için Mağazayı Gizle',
                    'notification' => 'Müşteri Bildirimi',
                ],
            ],
        ],
    ],
];