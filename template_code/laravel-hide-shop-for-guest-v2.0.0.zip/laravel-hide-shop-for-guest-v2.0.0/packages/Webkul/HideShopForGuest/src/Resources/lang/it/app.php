<?php

return [
    'admin' => [
        'configuration' => [
            'general' => [
                'title'     => 'Nascondi Negozio per gli ospiti',
                'info'      => 'Nascondi Negozio per gli ospiti',
                'desc-info' => 'Nascondi il loro negozio agli utenti ospiti o ai clienti non registrati del loro sito web',
                'setting'   => 'Impostazione',

                'status' => [
                    'title'        => 'Nascondi negozio per gli ospiti',
                    'notification' => 'Notifica per il cliente',
                ],
            ],
        ],
    ],
];