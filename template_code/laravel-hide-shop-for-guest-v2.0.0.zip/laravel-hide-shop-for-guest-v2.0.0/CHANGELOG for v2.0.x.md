# CHANGELOG for v2.0.x

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## v2.0.0 (06th June, 2024)

* [Feature] Compatible with Bagisto v2.0.0.

* [Suggestion] Please add the description and reposition the hide shop for guest module configuration to the top.

