<?php

namespace Webbycrown\BlogBagisto\Contracts;

interface Tag
{
}