<?php

namespace Webbycrown\BlogBagisto\Contracts;

interface Comment
{
}