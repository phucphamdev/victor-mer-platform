<?php

namespace Webbycrown\BlogBagisto\Contracts;

interface Blog
{
}