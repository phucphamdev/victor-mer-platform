<?php

namespace Webbycrown\BlogBagisto\Contracts;

interface Category
{
}