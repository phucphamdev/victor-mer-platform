/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './resources/views/admin/**/*',
  ],

  darkMode: 'class',

  theme: {
    extend: {},
  },
  plugins: [],
}
