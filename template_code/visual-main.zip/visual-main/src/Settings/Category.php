<?php

namespace BagistoPlus\Visual\Settings;

class Category extends Base
{
    public static string $component = 'category-setting';
}
