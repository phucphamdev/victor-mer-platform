<?php

namespace BagistoPlus\Visual\Settings;

class Textarea extends Text
{
    public static string $component = 'textarea-setting';
}
