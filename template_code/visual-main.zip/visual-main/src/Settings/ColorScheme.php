<?php

namespace BagistoPlus\Visual\Settings;

class ColorScheme extends Base
{
    public static string $component = 'color-scheme-setting';
}
