<?php

namespace BagistoPlus\Visual\Settings;

class CmsPage extends Base
{
    public static string $component = 'cms-page-setting';
}
