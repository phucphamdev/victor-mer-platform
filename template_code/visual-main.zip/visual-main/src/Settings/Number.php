<?php

namespace BagistoPlus\Visual\Settings;

class Number extends Base
{
    public static string $component = 'number-setting';
}
