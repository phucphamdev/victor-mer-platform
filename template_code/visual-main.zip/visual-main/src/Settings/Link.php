<?php

namespace BagistoPlus\Visual\Settings;

class Link extends Base
{
    public static string $component = 'link-setting';
}
