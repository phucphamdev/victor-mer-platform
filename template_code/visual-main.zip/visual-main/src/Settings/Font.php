<?php

namespace BagistoPlus\Visual\Settings;

class Font extends Base
{
    public static string $component = 'font-setting';
}
