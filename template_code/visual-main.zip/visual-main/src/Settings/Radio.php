<?php

namespace BagistoPlus\Visual\Settings;

/**
 * @method $this options(array $options)
 */
class Radio extends Select
{
    public static string $component = 'radio-setting';
}
