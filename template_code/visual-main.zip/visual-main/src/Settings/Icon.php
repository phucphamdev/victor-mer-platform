<?php

namespace BagistoPlus\Visual\Settings;

class Icon extends Base
{
    public static string $component = 'icon-setting';
}
