<?php

namespace BagistoPlus\Visual\Settings;

class Checkbox extends Base
{
    public static string $component = 'checkbox-setting';
}
