<?php

namespace BagistoPlus\Visual\Settings;

class Color extends Base
{
    public static string $component = 'color-setting';
}
