<?php

namespace BagistoPlus\Visual\Settings;

class Image extends Base
{
    public static string $component = 'image-setting';
}
