<?php

namespace BagistoPlus\Visual\Settings;

class Product extends Base
{
    public static string $component = 'product-setting';
}
