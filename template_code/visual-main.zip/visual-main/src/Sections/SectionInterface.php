<?php

namespace BagistoPlus\Visual\Sections;

interface SectionInterface {}
