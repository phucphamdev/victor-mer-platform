# Changelog

All notable changes to `Bagisto Visual` will be documented in this file.
