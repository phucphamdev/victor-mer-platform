<?php

// config for BagistoPlus/Visual
return [

];
