<?php

return [
    'visual_admin' => [
        'hot_file' => 'vendor/bagistoplus/visual/admin.hot',
        'build_directory' => 'vendor/bagistoplus/visual/admin',
        'package_assets_directory' => 'resources/assets/admin',
    ],
];
