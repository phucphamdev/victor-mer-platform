<?php

return [
    'data_path' => storage_path('bagisto-visual'),

    'images_storage' => 'public',

    'images_directory' => 'bagisto-visual/images',
];
