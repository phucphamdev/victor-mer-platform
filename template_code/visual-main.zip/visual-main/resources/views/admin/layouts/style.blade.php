{{-- blade-formatter-disable --}}
{{
  Vite::useHotFile('vendor/bagistoplus/visual/admin.hot')
    ->useBuildDirectory('vendor/bagistoplus/visual/admin')
    ->withEntryPoints(['resources/assets/admin/css/admin.css'])
}}
{{-- blade-formatter-enable --}}
