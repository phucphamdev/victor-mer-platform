@extends('shop::layouts.account')

@visual_content

@includeIf('shop::templates.account.edit-address')

@end_visual_content
