@extends('shop::layouts.account')

@visual_content

@includeIf('shop::templates.account.orders')

@end_visual_content
