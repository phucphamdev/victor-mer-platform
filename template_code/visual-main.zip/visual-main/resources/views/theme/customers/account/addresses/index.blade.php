@extends('shop::layouts.account')

@visual_content

@includeIf('shop::templates.account.addresses')

@end_visual_content
