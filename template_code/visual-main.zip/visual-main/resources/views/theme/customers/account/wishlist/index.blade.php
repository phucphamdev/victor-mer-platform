@extends('shop::layouts.account')

@visual_content

@includeIf('shop::templates.account.wishlist')

@end_visual_content
