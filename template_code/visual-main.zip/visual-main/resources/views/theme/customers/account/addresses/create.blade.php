@extends('shop::layouts.account')

@visual_content

@includeIf('shop::templates.account.add-address')

@end_visual_content
