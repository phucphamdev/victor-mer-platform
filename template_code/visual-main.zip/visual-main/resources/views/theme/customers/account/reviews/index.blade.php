@extends('shop::layouts.account')

@visual_content

@includeIf('shop::templates.account.reviews')

@end_visual_content
