<?php

return [
    'sidebar' => [
        'visual' => 'Bagisto Visual',
        'themes' => 'Themes',
    ],

    'themes' => [
        'title' => 'Themes',
        'customize' => 'Customize',
        'preview' => 'Preview',
    ],
];
