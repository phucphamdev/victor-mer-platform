<?php

return [
    [
        'key' => 'wishlistshare',
        'name' => 'WishlistShare',
        'route' => 'admin.wishlistshare.index',
        'sort' => 2,
        'icon' => 'temp-icon',
    ],
];
