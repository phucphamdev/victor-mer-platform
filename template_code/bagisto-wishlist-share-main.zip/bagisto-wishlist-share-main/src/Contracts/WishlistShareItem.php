<?php

namespace Ihasan\BagistoWishlistShare\Contracts;

interface WishlistShareItem
{
    //
}
