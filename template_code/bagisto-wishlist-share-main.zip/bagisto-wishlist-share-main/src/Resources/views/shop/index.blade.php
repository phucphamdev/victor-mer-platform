<x-shop::layouts>

    <!-- Title of the page -->
    <x-slot:title>
        Package WishlistShare
    </x-slot>

    <div class="main">
        Package WishlistShare
    </div>
</x-shop::layouts>