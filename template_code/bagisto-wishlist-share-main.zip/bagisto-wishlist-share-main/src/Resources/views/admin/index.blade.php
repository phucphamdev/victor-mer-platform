<x-admin::layouts>

    <!-- Title of the page -->
    <x-slot:title>
        Package WishlistShare
    </x-slot>

    <!-- Page Content -->
    <div class="page-content">
        <h1>Package WishlistShare</h1>
    </div>

</x-admin::layouts>