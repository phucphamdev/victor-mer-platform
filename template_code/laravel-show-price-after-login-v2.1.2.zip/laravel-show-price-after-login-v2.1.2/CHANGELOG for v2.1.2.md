# CHANGELOG for v2.1.2

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v2.1.2(28th of Nov, 2024)** - Release

* [fix] On the home page, the item is showing a login bug but, Here the module functionality is broken by adding an item
        to the wishlist and then adding to the cart and purchase.

* [fix] Facing redirection issue

* [fix] If the Product is falling the category where the module functionality is disabled the that product should be showing
  the same on the home page, on search

* [fix] Module configuration -> Button title field should not be the mandatory field.

* [fix] Getting migration issues while installing the module

* [Enhancement] Show Price after login module functionality should be working on selected data.

* [Enhancement] While uploading the CSV file, please add the popup message that the file was uploaded successfully.

* [Enhancement] Please add the character validation on the Button Title field

* [fix] Please make the module multi-locale support

* [fix] Here we disable the Enable Add to Cart Modification functionality but it is working on the front end.

* [fix] Please add the proper description of the module

* [fix] Getting exception while uploading the incorrect CSV file

* [fix] Please make the gap between the button and change the button name

* [fix] If applying a particular customer group type - not working for virtual and group products

* [fix] If applying a particular customer group type - guest, wholesale, general then the bundle product option is not showing fine.


## **v1.3.1(14th of Sep, 2021)** - Release

* [fix] Compatiblility with bagisto version 1.3.1

## **v0.1.2(18th of Dec, 2020)** - Release

* [fix] Compatiblility with bagisto version 1.2.0.

* [fix] Compatible with all type of product.

* [fix] Added translation for arabic

* [fix] Not hide wishlist and compare if module is enable.
