# Show price after login v2.1.2:

This is a addon that will work over Bagisto and it will help admin to get more and more control over
their shops.
With the help of this module an admin can alter many elements of products such as "price", "add to cart", "buy now", etc.

# Features:

1. The admin can set the Show Price After Login for Bagisto module status as Yes or No.
2. The admin can select multiple customer groups who can view the prices and add to the cart button from the configuration.
3. Admin can select the categories for which the product price should display in the store.
4. The admin can set a customized title for “Add to Cart” button & redirecting URL for the users who can’t view the price and Add to Cart button.
5. Show price after login can also configure according to the product configuration/general configuration.
6. Update product show price module attributes value using CSV.
7. Select function to "hide buy now and add to cart button".
8. Select function to "hide buy now and add to cart button with price" also.

# Requirements:

* **Bagisto**: v2.1.2.
* **PHP**: v8.1 or Higher.

# Installation:

1. Goto *composer.json* present in your project's root:

Under the object of *psr-4*, add the line below:

~~~
"Webkul\\ShowPriceAfterLogin\\": "packages/Webkul/ShowPriceAfterLogin/src"
~~~

2. Goto *config/app.php* from the project's root:

Under the *providers* array, add this line at the end:

~~~
Webkul\ShowPriceAfterLogin\Providers\ShowPriceAfterLoginServiceProvider::class,
~~~

3. Go to *config/bagisto-vite.php* add the following line under the 'viters' section
~~~
'showpriceafterlogin' => [
    'hot_file'                 => 'show-price-after-login-vite.hot',
    'build_directory'          => 'themes/show-price-after-login/default/build',
    'package_assets_directory' => 'src/Resources/assets',
],
~~~


4. Perform a command, from the root of your terminal:

~~~
composer dump-autoload
~~~

~~~
php artisan migrate
~~~

~~~
php artisan vendor:publish --provider="Webkul\ShowPriceAfterLogin\Providers\ShowPriceAfterLoginServiceProvider" --force
~~~
