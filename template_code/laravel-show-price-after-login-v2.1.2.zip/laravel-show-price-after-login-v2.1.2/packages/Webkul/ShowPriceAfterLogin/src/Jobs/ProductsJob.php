<?php

namespace Webkul\ShowPriceAfterLogin\Jobs;

use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Webkul\Product\Repositories\ProductRepository;
use Webkul\ShowPriceAfterLogin\Repositories\ShowPriceAfterLogin as ShowPriceAfterLoginRepository;

class ProductsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     */
    public function __construct(
        private array $rows
    ) {
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        // Initialize the $products array in one go
        $products = array_map(function ($row) {
            return array_combine($this->rows[0], $row);
        }, array_slice($this->rows, 1));

        // Pre-instantiate repositories
        $productRepository = app(ProductRepository::class);

        $showPriceRepo = app(ShowPriceAfterLoginRepository::class);

        foreach ($products as $product) {
            try {
                $data = [
                    'hide_for_guest'        => $product['hide_for_guest'] ? 'hide-price-buy-cart-guest' : 'hide-buy-cart-guest',
                    'add_to_cart_title'     => $product['add_to_cart_title'],
                    'redirect_url'          => $product['redirect_url'],
                    'product_id'            => $product['product_id'],
                    'status'                => $product['enable_status'],
                    'channel'               => core()->getRequestedChannelCode(),
                    'locale'                => core()->getRequestedLocaleCode(),
                    'add_to_cart_status'    => $product['add_to_cart_status'] ?? 0,
                    'allow_customer_groups' => array_map('intval', explode(",", $product['allow_customer_groups'] ?? '')),
                ];

                // Update product
                $productRepository->update([
                    'channel' => $data['channel']
                ], $product['product_id']);

                // Update or create show price record
                $showPriceRepo->updateOrCreate([
                        'product_id' => $product['product_id'],
                        'locale'     => $data['locale'],
                        'channel'    => $data['channel']
                    ], $data);
            } catch (Exception $e) {
                // Handle error based on exception code
                if (! $e->getCode()) {
                    session()->flash('error', trans('show_price_after_login::app.admin.products.upload-csv.invalid-file'));
                }
            }
        }
    }

}
