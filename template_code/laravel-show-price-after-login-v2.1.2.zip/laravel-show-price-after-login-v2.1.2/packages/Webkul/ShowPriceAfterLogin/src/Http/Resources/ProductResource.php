<?php

namespace Webkul\ShowPriceAfterLogin\Http\Resources;

use Webkul\Shop\Http\Resources\ProductResource as BaseProductResource;
use Webkul\ShowPriceAfterLogin\ShowPriceAfterLogin;

class ProductResource extends BaseProductResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        $product = parent::toArray($request);

        $product['show_product_price'] = app()->make(ShowPriceAfterLogin::class)->getRecord($this);

        $product['categories'] = $this->categories;

        return $product;
    }
}
