<?php

namespace Webkul\ShowPriceAfterLogin\Http\Controllers\Admin;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller;
use Maatwebsite\Excel\Facades\Excel;
use Webkul\Product\Repositories\ProductRepository;
use Webkul\ShowPriceAfterLogin\CsvImport;
use Webkul\ShowPriceAfterLogin\Repositories\ShowPriceAfterLogin as ShowPriceAfterLoginRepository;
use Webkul\ShowPriceAfterLogin\Jobs\ProductsJob;

class showPriceAfterLogin extends Controller
{
    use DispatchesJobs, ValidatesRequests;

    /**
     * Create a new controller instance.
     */
    const CSV = 'csv';

    const PRODUCT_CONFIGURATION = 'product-configuration';

    /**
     * Create controller instance
     */
    public function __construct(
        protected ShowPriceAfterLoginRepository $showPriceAfterLoginRepository,
        protected ProductRepository $productRepository,
    ) {
    }

    /**
     * Update the specified resource in storage.
     *
     * @return void
     */
    public function productShowPrice($product)
    {
        if (
            ! (core()->getConfigData('show_product_price.settings.general.status')
            && core()->getConfigData('show_product_price.settings.general.configuration_type') == self::PRODUCT_CONFIGURATION)
        ) {
            return true;
        }

        $data = request()->only([
            'enable_status',
            'hide_for_guest',
            'add_to_cart_status',
            'add_to_cart_title',
            'redirect_url',
            'allow_customer_groups',
        ]);

        $data['product_id'] = $product->id;

        $data['channel'] = core()->getRequestedChannelCode();

        $data['locale'] = core()->getRequestedLocaleCode();

        $data['status'] = @$data['enable_status'] ? 1 : 0;

        $data['add_to_cart_status'] = @$data['add_to_cart_status'] ? 1 : 0;

        if (! empty($data['allow_customer_groups'])) {
            foreach ($data['allow_customer_groups'] as $index => $customerGroup) {

                $data['allow_customer_groups'][$index] = (int) $customerGroup;
            }
        }

        $this->showPriceAfterLoginRepository->updateOrCreate([
            'product_id' => $product->id,
            'locale'     => $data['locale'],
            'channel'    => $data['channel']
        ], $data);
    }

    /**
     * get product data from csv
     *
     * @return array
     */
    public function csvUpload()
    {
        if (request()->csv->clientExtension() != self::CSV) {
            session()->flash('error', trans('show_price_after_login::app.admin.products.upload-csv.invalid-file'));

            return new JsonResponse([
                'message' => trans('show_price_after_login::app.admin.products.upload-csv.product-not-updated'),
            ], 500);
        }

        if (
            dispatch( new ProductsJob(Excel::toArray(new CsvImport, request()->csv)[0]))->onQueue('low')
            && ! session()->has('error')
        ) {
            session()->flash('success', trans('show_price_after_login::app.admin.products.upload-csv.product-updated'));

            return new JsonResponse([
                'message' => trans('show_price_after_login::app.admin.products.upload-csv.product-updated'),
            ], 200);
        }
    }
}
