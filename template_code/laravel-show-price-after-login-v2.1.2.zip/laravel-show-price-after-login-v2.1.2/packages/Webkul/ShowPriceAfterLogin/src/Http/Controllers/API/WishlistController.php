<?php

namespace Webkul\ShowPriceAfterLogin\Http\Controllers\API;

use Illuminate\Http\Resources\Json\JsonResource;
use Webkul\ShowPriceAfterLogin\Http\Resources\WishlistResource;
use Webkul\Shop\Http\Controllers\API\WishlistController as BaseWishlistController;

class WishlistController extends BaseWishlistController
{
    /**
     * Displays the listing resources if the customer has items on the wishlist.
     */
    public function index(): JsonResource
    {
        $this->removeInactiveItems();

        $items = $this->wishlistRepository
            ->where([
                'channel_id'  => core()->getCurrentChannel()->id,
                'customer_id' => auth()->guard('customer')->user()->id,
            ])
            ->get();

        return WishlistResource::collection($items);
    }

}
