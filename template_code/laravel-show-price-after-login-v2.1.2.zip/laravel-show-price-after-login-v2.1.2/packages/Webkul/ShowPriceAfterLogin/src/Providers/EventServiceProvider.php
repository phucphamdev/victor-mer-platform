<?php

namespace Webkul\ShowPriceAfterLogin\Providers;

use Illuminate\Support\Facades\Event;
use Illuminate\Support\ServiceProvider;
use Webkul\ShowPriceAfterLogin\Http\Controllers\Admin\showPriceAfterLogin;

class EventServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        Event::listen('bagisto.admin.catalog.product.edit.form.categories.after', function ($viewRenderEventManager) {
            $viewRenderEventManager->addTemplate('show_price_after_login::admin.products.showPriceAfterLogin');
        });

        Event::listen('bagisto.admin.catalog.products.create.before', function ($viewRenderEventManager) {
            $viewRenderEventManager->addTemplate('show_price_after_login::admin.products.upload-csv');
        });

        Event::listen('catalog.product.update.after', [showPriceAfterLogin::class, 'productShowPrice']);

    }
}
