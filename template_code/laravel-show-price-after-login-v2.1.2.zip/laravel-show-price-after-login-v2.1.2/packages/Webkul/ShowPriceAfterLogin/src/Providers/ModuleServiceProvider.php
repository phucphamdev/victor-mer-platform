<?php

namespace Webkul\ShowPriceAfterLogin\Providers;

use Konekt\Concord\BaseModuleServiceProvider;

class ModuleServiceProvider extends BaseModuleServiceProvider
{
    protected $models = [
        \Webkul\ShowPriceAfterLogin\Models\showPriceAfterLogin::class,
    ];
}
