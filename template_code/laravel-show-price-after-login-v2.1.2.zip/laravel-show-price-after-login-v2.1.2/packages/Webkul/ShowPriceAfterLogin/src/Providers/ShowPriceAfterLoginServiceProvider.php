<?php

namespace Webkul\ShowPriceAfterLogin\Providers;

use Illuminate\Foundation\AliasLoader;
use Illuminate\Support\ServiceProvider;
use Webkul\Shop\Http\Controllers\API\CompareController as BaseCompareController;
use Webkul\Shop\Http\Controllers\API\ProductController as ProductBaseController;
use Webkul\Shop\Http\Controllers\API\WishlistController as BaseWishlistController;
use Webkul\ShowPriceAfterLogin\Http\Controllers\API\WishlistController;
use Webkul\ShowPriceAfterLogin\Facades\ShowPriceAfterLogin as AfterLoginFacades;
use Webkul\ShowPriceAfterLogin\Http\Controllers\API\CompareController;
use Webkul\ShowPriceAfterLogin\Http\Controllers\API\ProductController;
use Webkul\ShowPriceAfterLogin\ShowPriceAfterLogin;

class ShowPriceAfterLoginServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadMigrationsFrom(__DIR__.'/../Database/Migrations');

        $this->loadRoutesFrom(__DIR__.'/../Routes/admin-routes.php');

        $this->loadViewsFrom(__DIR__.'/../Resources/views', 'show_price_after_login');

        $this->loadTranslationsFrom(__DIR__.'/../Resources/lang', 'show_price_after_login');

        $this->publishes([
            __DIR__.'/../Resources/views/shop/components/products/card.blade.php' => resource_path('views/vendor/shop/components/products/card.blade.php'),

            __DIR__.'/../Resources/views/shop/products/view.blade.php' => resource_path('views/vendor/shop/products/view.blade.php'),

            __DIR__.'/../Resources/views/shop/customers/account/wishlist/index.blade.php' => resource_path('views/vendor/shop/customers/account/wishlist/index.blade.php'),

            __DIR__.'/../Resources/views/shop/products/view' => resource_path('views/vendor/shop/products/view'),

            __DIR__. '/../Sample' => public_path('/Sample'),

            __DIR__. '/../../publishable' => public_path('/themes/show-price-after-login/default/'),
        ]);

        $this->app->register(ModuleServiceProvider::class);

        $this->app->register(EventServiceProvider::class);

        $this->mergeConfigFrom(
            dirname(__DIR__) . '/Config/system.php',
            'core'
        );

        if (core()->getConfigData('show_product_price.settings.general.status')) {

            $this->app->bind(ProductBaseController::class, ProductController::class);

            $this->app->bind(BaseCompareController::class, CompareController::class);

            $this->app->bind(BaseWishlistController::class, WishlistController::class);
        }
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $loader = AliasLoader::getInstance();

        $loader->alias('showPriceAfterLogin', AfterLoginFacades::class);

        $this->app->singleton('showPriceAfterLogin', function () {
            return app()->make(ShowPriceAfterLogin::class);
        });
    }
}
