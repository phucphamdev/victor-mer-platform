<?php

namespace Webkul\ShowPriceAfterLogin\Contracts;

interface showPriceAfterLogin {}
