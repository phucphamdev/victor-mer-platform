<?php

namespace Webkul\ShowPriceAfterLogin\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * @method static \Webkul\Customer\Contract\CustomerGroup getCustomerGroup()
 * @method static \Webkul\ShowPriceAfterLogin\Contract\ShowPriceAfterLogin getRecord($product)
 * @method static \Webkul\category\Contract\Category getCategories()
 */
class ShowPriceAfterLogin extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'showPriceAfterLogin';
    }
}
