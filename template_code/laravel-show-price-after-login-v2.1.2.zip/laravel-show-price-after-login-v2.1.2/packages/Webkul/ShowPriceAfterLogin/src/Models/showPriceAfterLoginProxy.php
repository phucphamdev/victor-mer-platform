<?php

namespace Webkul\ShowPriceAfterLogin\Models;

use Konekt\Concord\Proxies\ModelProxy;

class showPriceAfterLoginProxy extends ModelProxy {}
