<?php

namespace Webkul\ShowPriceAfterLogin\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Webkul\Product\Models\ProductProxy;
use Webkul\ShowPriceAfterLogin\Contracts\showPriceAfterLogin as showPriceAfterLoginContract;

class showPriceAfterLogin extends Model implements showPriceAfterLoginContract
{
    protected $fillable = [
        'status',
        'hide_for_guest',
        'add_to_cart_status',
        'add_to_cart_title',
        'redirect_url',
        'product_id',
        'allow_customer_groups',
        'channel',
        'locale',
    ];

    protected $table = 'show_product_price';

    /**
     * HasOne Relationship define between products and show_product_price table
     *
     * @return Illuminate\Database\Eloquent\Relations\HasOne;
     */
    public function product(): HasOne
    {
        return $this->hasOne(ProductProxy::modelClass(), 'id', 'product_id');
    }

    /**
     * Defined Accessor and Mutotar for 'allow_customer_Groups' field
     *
     * @return Illuminate\Database\Eloquent\Casts\Attribute
     */
    protected function allowCustomerGroups(): Attribute
    {
        return Attribute::make(
            get: fn (string $value) => json_decode($value),

            set: fn (array $value) => json_encode($value),
        );
    }
}
