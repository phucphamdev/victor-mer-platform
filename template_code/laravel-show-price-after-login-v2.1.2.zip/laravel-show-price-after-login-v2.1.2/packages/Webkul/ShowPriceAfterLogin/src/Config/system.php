<?php

$system = [
    [
        'key'    => 'show_product_price',
        'name'   => 'show_price_after_login::app.admin.configurations.index.title',
        'sort'   => 5,
    ], [
        'key'    => 'show_product_price.settings',
        'name'   => 'show_price_after_login::app.admin.configurations.index.settings.general.title',
        'info'   => 'show_price_after_login::app.admin.configurations.index.settings.general.info',
        'icon'   => 'settings/settings.svg',
        'sort'   => 1,
    ], [
        'key'    => 'show_product_price.settings.general',
        'name'   => 'show_price_after_login::app.admin.configurations.index.settings.general.title',
        'info'   => 'show_price_after_login::app.admin.configurations.index.settings.general.info',
        'sort'   => 1,
        'fields' => [
            [
                'name'          => 'status',
                'title'         => 'show_price_after_login::app.admin.configurations.index.settings.general.toggle',
                'type'          => 'boolean',
                'channel_based' => true,
                'locale_based'  => false,
            ], [
                'name'       => 'hide_for_guest',
                'title'      => 'show_price_after_login::app.admin.configurations.index.settings.general.hide-for-guest',
                'type'       => 'select',
                'channel_based' => true,
                'locale_based'  => false,
                'validation' => 'required_if:add_to_cart_status,0',
                'options'    => [
                    [
                        'name'  => 'hide-buy-cart-guest',
                        'title' => 'show_price_after_login::app.admin.configurations.index.settings.general.hide-buy-cart-guest',
                        'value' => 'hide-buy-cart-guest',
                    ], [
                        'name'  => 'hide-price-guest',
                        'title' => 'show_price_after_login::app.admin.configurations.index.settings.general.hide-price-guest',
                        'value' => 'hide-price-guest',
                    ], [
                        'name'  => 'hide-price-buy-cart',
                        'title' => 'show_price_after_login::app.admin.configurations.index.settings.general.hide-price-buy-cart-guest',
                        'value' => 'hide-price-buy-cart-guest',
                    ],
                ],

            ], [
                'name'          => 'add_to_cart_status',
                'title'         => 'show_price_after_login::app.admin.configurations.index.settings.general.add-to-cart-status',
                'type'          => 'boolean',
                'channel_based' => true,
                'locale_based'  => false,
            ], [
                'name'          => 'add_to_cart_title',
                'title'         => 'show_price_after_login::app.admin.configurations.index.settings.general.add-to-cart-title',
                'type'          => 'text',
                'validation'    => 'max:50',
                'channel_based' => true,
                'locale_based'  => true,
            ], [
                'name'          => 'redirect_url',
                'title'         => 'show_price_after_login::app.admin.configurations.index.settings.general.redirect-url',
                'type'          => 'text',
                'validation'    => '',
                'channel_based' => true,
                'locale_based'  => false,
            ], [
                'name'       => 'configuration_type',
                'title'      => 'show_price_after_login::app.admin.configurations.index.settings.general.configuration-type',
                'type'       => 'select',
                'validation' => 'required',
                'channel_based' => true,
                'locale_based'  => false,
                'options'    => [
                    [
                        'title' => 'show_price_after_login::app.admin.configurations.index.settings.general.general-configuration',
                        'value' => 'general-configuration',
                    ], [
                        'title' => 'show_price_after_login::app.admin.configurations.index.settings.general.product-configuration',
                        'value' => 'product-configuration',
                    ],
                ],

            ],

        ],
    ],
];

$customerGroups = [
    'name'    => 'customer_group',
    'title'   => 'show_price_after_login::app.admin.configurations.index.settings.general.allows-customre-group',
    'type'    => 'multiselect',
    'channel_based' => true,
    'locale_based'  => false,
    'options' => [
    ],

];

$categories = [
    'name'    => 'categories',
    'title'   => 'show_price_after_login::app.admin.configurations.index.settings.general.allows-categories',
    'type'    => 'multiselect',
    'channel_based' => true,
    'locale_based'  => false,
    'options' => [
    ],

];

foreach (showPriceAfterLogin::getCustomerGroup() as $coustomerGroup) {
    $customerGroups['options'][] = ['title' => $coustomerGroup->name, 'value' => $coustomerGroup->id,];
}

foreach (showPriceAfterLogin::getCategories() as $category) {

    if ($category->parent_id == 1) {

        $categories['options'][] = ['title' => $category->name, 'value' => $category->id,];

        foreach (showPriceAfterLogin::getCategories()->where('parent_id', $category->id) as $child) {

            $categories['options'][] = ['title' => '---'.$child->name, 'value' => $child->id,];
        }
    }
}

$system[2]['fields'][] = $customerGroups;

$system[2]['fields'][] = $categories;

return $system;
