<?php

use Illuminate\Support\Facades\Route;
use Webkul\ShowPriceAfterLogin\Http\Controllers\Admin\showPriceAfterLogin;

Route::group(['middleware' => ['web', 'admin'], 'prefix' => 'admin/showpriceafterlogin'], function () {

    Route::controller(showPriceAfterLogin::class)->group(function () {

        Route::post('uploadcsv', 'csvUpload')->name('showproduct.product.upload.csv');

        Route::post('updateProduct', 'updateProduct')->name('showproduct.product.upload');

        Route::get('downloadSampleCsv', 'downloadSampleCsv')->name('showproduct.product.download.sample');
    });

});
