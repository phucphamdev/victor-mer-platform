<?php

namespace Webkul\ShowPriceAfterLogin;

use Webkul\Category\Repositories\CategoryRepository;
use Webkul\Customer\Repositories\CustomerGroupRepository;
use Webkul\ShowPriceAfterLogin\Repositories\ShowPriceAfterLogin as ShowPriceAfterLoginRepo;

class ShowPriceAfterLogin
{
    /**
     * Create a new instance.
     *
     * @return void
     */
    public function __construct(
        protected CustomerGroupRepository $customerGroupRepository,
        protected ShowPriceAfterLoginRepo $ShowPriceAfterLoginRepo,
        protected CategoryRepository $categoryRepository,
    ) {}

    /**
     * Return customer groups.
     *
     * @return \Webkul\Customer\Contract\CustomerGroup
     */
    public function getCustomerGroup()
    {
        return $this->customerGroupRepository->get();
    }

    /**
     * Return show product price setting based on product id.
     *
     * @return \Webkul\ShowPriceAfterLogin\Contract\ShowPriceAfterLogin
     */
    public function getRecord($product)
    {
        return $product['show_product_price'] = $this->ShowPriceAfterLoginRepo->where(['product_id' => $product->id, 'locale' => core()->getRequestedLocaleCode(), 'channel' => core()->getRequestedChannelCode()])->first();
    }

    /**
     * Return customer groups.
     *
     * @return \Webkul\category\Contract\Category
     */
    public function getCategories()
    {
        return $this->categoryRepository->get();
    }
}
