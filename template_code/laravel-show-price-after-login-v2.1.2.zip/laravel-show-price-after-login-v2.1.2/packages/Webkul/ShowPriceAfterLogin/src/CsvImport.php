<?php

namespace Webkul\showPriceAfterLogin;

use Maatwebsite\Excel\Concerns\ToModel;

class CsvImport implements ToModel
{
    /**
     * @return array
     */
    public function model($rows)
    {
        return $rows;
    }
}
