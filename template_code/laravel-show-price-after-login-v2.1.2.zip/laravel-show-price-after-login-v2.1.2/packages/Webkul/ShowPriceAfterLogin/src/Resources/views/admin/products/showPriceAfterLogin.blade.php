<!-- Panel -->
@php
    $status = core()->getConfigData('show_product_price.settings.general.status');

    $configurationType = core()->getConfigData('show_product_price.settings.general.configuration_type');

    showPriceAfterLogin::getRecord($product);

    $customerGroups = showPriceAfterLogin::getCustomerGroup();
@endphp

@if (
     $status
     && $configurationType == 'product-configuration'
    )
    <div class="p-4 bg-white dark:bg-gray-900 rounded box-shadow">
        <!-- Panel Header -->
        <p class="flex justify-between text-base text-gray-800 dark:text-white font-semibold mb-4">
            @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.title')
        </p>

        <!-- Panel Content -->
        <div class="mb-5 text-sm text-gray-600 dark:text-gray-300">

            <v-show-price-after-login />

        </div>
    </div>
@endif

@pushOnce('scripts')
    <script
        type="text/x-template"
        id="v-show-price-after-login-template"
    >
        <x-admin::form.control-group>
            <x-admin::form.control-group.label>
                @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.toggle')
            </x-admin::form.control-group.label>
            <x-admin::form.control-group.control
                type="switch"
                name="enable_status"
                ::value="showPriceAfterLoginStatus"
                ::checked="showPriceAfterLoginStatus"
                v-on:click="showPriceAfterLoginStatus = ! showPriceAfterLoginStatus"
            />
        </x-admin::form.control-group>

        <x-admin::form.control-group v-if='showPriceAfterLoginStatus'>
            <x-admin::form.control-group.label>
                @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.hide-for-guest')
            </x-admin::form.control-group.label>

            <x-admin::form.control-group.control
                type="select"
                name="hide_for_guest"
                v-model="showType"
            >
                <option value="hide-buy-cart-guest"> @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.hide-buy-cart-guest') </option>
                <option value="hide-price-guest"> @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.hide-price-guest') </option>
                <option value="hide-price-buy-cart-guest"> @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.hide-price-buy-cart-guest') </option>
            </x-admin::form.control-group.control>
        </x-admin::form.control-group>

            <x-admin::form.control-group v-if='showPriceAfterLoginStatus'>
                <x-admin::form.control-group.label>
                    @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.allows-customre-group')
                </x-admin::form.control-group.label>

                <x-admin::form.control-group.control
                    type="multiselect"
                    name="allow_customer_groups[]"
                >
                <template v-for="customerGroup in customerGroups">
                    <option :value=customerGroup.id :selected="isSelected(customerGroup)" > @{{customerGroup.name}}</option>
                </template>
            </x-admin::form.control-group.control>
        </x-admin::form.control-group>

        <x-admin::form.control-group v-if='showPriceAfterLoginStatus'>
            <x-admin::form.control-group.label>
                @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.add-to-cart-status')
            </x-admin::form.control-group.label>

            <x-admin::form.control-group.control
                type="switch"
                name="add_to_cart_status"
                ::value="addToCartStatus"
                ::checked="addToCartStatus"
                v-on:click="addToCartStatus = ! addToCartStatus"
            />

        </x-admin::form.control-group>

        <x-admin::form.control-group v-if='addToCartStatus && showPriceAfterLoginStatus'>
            <x-admin::form.control-group.label>
                @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.add-to-cart-title')
            </x-admin::form.control-group.label>

            <x-admin::form.control-group.control
                type="text"
                name="add_to_cart_title"
                v-model='buttonTitle'
            />
        </x-admin::form.control-group>

        <x-admin::form.control-group v-if='addToCartStatus && showPriceAfterLoginStatus'>
            <x-admin::form.control-group.label>
                @lang('show_price_after_login::app.admin.products.showPriceAfterLogin.redirect-url')
            </x-admin::form.control-group.label>

            <x-admin::form.control-group.control
                type="text"
                name="redirect_url"
                v-model="redirectUrl"
            />
        </x-admin::form.control-group>
    </script>

    <script type="module">
        app.component('v-show-price-after-login', {
            template: '#v-show-price-after-login-template',

            data() {
                return {
                    showPriceAfterLoginStatus: @json(! empty($product->show_product_price) ? ($product->show_product_price->status == 1 ? true : false) : false ),

                    addToCartStatus: @json(! empty($product->show_product_price) ? ($product->show_product_price->add_to_cart_status == 1 ? true : false) : false ),

                    showType: @json(! empty($product->show_product_price) ? $product->show_product_price->hide_for_guest : null ),

                    buttonTitle: @json(! empty($product->show_product_price) ? $product->show_product_price->add_to_cart_title : null ),

                    redirectUrl: @json(! empty($product->show_product_price) ? $product->show_product_price->redirect_url : null ),

                    allowCustomerGroups: @json(! empty($product->show_product_price) ? $product->show_product_price->allow_customer_groups : []),

                    customerGroups: @json(showPriceAfterLogin::getCustomerGroup()),
                }
            },

            computed: {
                isSelected: function() {
                    return (customerGroup) => this.allowCustomerGroups ? this.allowCustomerGroups.includes(customerGroup.id) : false;
                }
            },

        });
    </script>
@endpushOnce
