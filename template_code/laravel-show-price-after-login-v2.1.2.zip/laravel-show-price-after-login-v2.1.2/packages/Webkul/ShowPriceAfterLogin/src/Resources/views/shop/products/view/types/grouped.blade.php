<v-grouped-product>

</v-grouped-product>

@pushOnce('scripts')
    <script type="text/x-template" id="v-grouped-product-template">
        @if ($product->type == 'grouped')
        {!! view_render_event('bagisto.shop.products.view.grouped_products.before', ['product' => $product]) !!}

        <div class="w-[455px] max-w-full">
            @php
                $groupedProducts = $product->grouped_products()->orderBy('sort_order')->get();
            @endphp

            @if ($groupedProducts->count())
                <div class="grid gap-5 mt-8">
                    @foreach ($groupedProducts as $groupedProduct)
                        @if ($groupedProduct->associated_product->getTypeInstance()->isSaleable())
                            <div class="flex gap-5 justify-between items-center">
                                <div class="text-sm font-medium">
                                    <p class="">
                                        @lang('shop::app.products.view.type.grouped.name')
                                    </p>

                                    <p class="text-[#6E6E6E] mt-1.5" v-if="isPriceShowable">
                                        {{ $groupedProduct->associated_product->name . ' + ' . core()->currency($groupedProduct->associated_product->getTypeInstance()->getFinalPrice()) }}
                                    </p>
                                    <p class="text-[#6E6E6E] mt-1.5" v-else>
                                        {{ $groupedProduct->associated_product->name }}
                                    </p>

                                </div>

                                <x-shop::quantity-changer
                                    name="qty[{{$groupedProduct->associated_product_id}}]"
                                    :value="$groupedProduct->qty"
                                    class="gap-x-4 py-2.5 px-3 rounded-xl"
                                    @change="updateItem($event)"
                                />
                            </div>
                        @endif
                    @endforeach
                </div>
            @endif

        </div>

        {!! view_render_event('bagisto.shop.products.view.grouped_products.before', ['product' => $product]) !!}
    @endif
    </script>
    <script type="module">
        app.component('v-grouped-product', {
            template:"#v-grouped-product-template",
            data() {
                return {
                        showProductPriceStatus: parseInt('{{ core()->getConfigData('show_product_price.settings.general.status') }}'),

                        showType: '{{ core()->getConfigData('show_product_price.settings.general.hide_for_guest') }}',

                        buttonTitle: '{{ core()->getConfigData('show_product_price.settings.general.add_to_cart_title') }}',

                        redirectUrl: '{{ core()->getConfigData('show_product_price.settings.general.redirect_url') }}',

                        addToCartStatus: '{{ core()->getConfigData('show_product_price.settings.general.add_to_cart_status') }}',

                        configurationType: '{{ core()->getConfigData('show_product_price.settings.general.configuration_type') }}',

                        loginToBuy: '{{ trans('show_price_after_login::app.shop.products.view.login-to-buy') }}',

                        loginToviewPrice: '{{ trans('show_price_after_login::app.shop.products.view.login-to-view-price') }}',

                        customButtonTitle: (this.showType == 'hide-buy-cart-guest' ? this.loginToBuy : this.loginToviewPrice),

                        product: @json($product),

                        categories: @json($product->categories),

                        customerGroups: @json(showPriceAfterLogin::getCustomerGroup()),

                        GeneralConfAllowedGroup: @json(core()->getConfigData('show_product_price.settings.general.customer_group')),

                        GeneralConfAllowedCateg: @json(core()->getConfigData('show_product_price.settings.general.categories')),

                        currentCategory: '',
                }
            },

            computed: {
                isGeneralConfiguration: function() {
                    return this.configurationType == 'general-configuration';
                },

                isAllowedCategories: function() {
                    if (this.isGeneralConfiguration) {
                        return this.groupAllowed
                        || this.productCategoryAllowed;
                    } else {
                        return this.groupAllowed
                        && this.productCategoryAllowed;
                    }
                },

                productCofigAddToCartStatus: function() {
                    return this.showProductPriceStatus
                    && ! this.isGeneralConfiguration
                    && (this.product.show_product_price ? ! this.product.show_product_price.status : 1);
                },

                isPriceShowableProductConfig: function() {
                    return (
                        this.showProductPriceStatus
                        && this.priceShowStatus
                    ) || this.isAllowedCategories;
                },

                productCofigPriceStatus: function() {
                    return ! this.isGeneralConfiguration
                    && (
                        (this.product.show_product_price ? this.product.show_product_price.hide_for_guest == 'hide-buy-cart-guest' : 0)
                        || this.productCofigAddToCartStatus
                    );
                },

                GeneralCofigPriceStatus: function() {
                    return this.isGeneralConfiguration
                    && this.showType == 'hide-buy-cart-guest';
                },

                priceShowStatus: function() {
                    return this.productCofigPriceStatus
                    || this.GeneralCofigPriceStatus;
                },

                isPriceShowable: function() {
                    return ! this.showProductPriceStatus
                    || this.isPriceShowableProductConfig;
                },

                groupAllowed: function() {
                    let GeneralConfAllowedGroup = this.GeneralConfAllowedGroup ?
                                                this.GeneralConfAllowedGroup.split(',') : [];

                    let allowedGroups = (
                                            this.product.show_product_price
                                            && this.configurationType == 'product-configuration') ? this.product.show_product_price.allow_customer_groups : GeneralConfAllowedGroup;

                    if (! allowedGroups) {
                        return 1;
                    }

                    if (
                        (
                            this.product.show_product_price
                            && this.configurationType == 'product-configuration'
                        )
                        || this.configurationType == 'general-configuration'
                    ) {
                        allowedGroups = allowedGroups.map(group => Number(group));

                        let isAllowedCustomerGroup = this.customerGroups.map(Groups =>
                            (Groups.name == '{{ auth()->user() ? auth()->user()->group->name : 'Guest' }}'
                            && allowedGroups.includes(Groups.id))
                        );

                        for (let customerGroup = 0; customerGroup < isAllowedCustomerGroup.length; customerGroup++) {
                            if (isAllowedCustomerGroup[customerGroup]) {
                                return 0;
                            }
                        }

                        return 1;
                    }

                    return 1;
                },

                productCategoryAllowed: function() {
                    let allowedCategory = this.GeneralConfAllowedCateg ?
                                        this.GeneralConfAllowedCateg.split(',') : [];

                    if (! allowedCategory.length) {
                        return 0;
                    }

                    this.currentCategory = document.referrer;

                    if (
                        this.isGeneralConfiguration
                        && this.currentCategory != ''
                    ) {
                        this.currentCategory = new URL(this.currentCategory).pathname
                                                .substring(1).split('/');

                        allowedCategory = allowedCategory.map(Number);

                        this.currentCategory = this.currentCategory[this.currentCategory.length - 1];

                        if (
                            this.currentCategory == ''
                            || ! allowedCategory.length
                        ) {
                            return 0;
                        }

                        let isAllowedCategory = this.categories.map(category => (
                            category.parent_id ?
                            (
                                category.slug == this.currentCategory
                                && (
                                    allowedCategory.includes(category.parent_id)
                                    || allowedCategory.includes(category.id)
                                )
                            ) : (
                                allowedCategory.includes(category.id)
                                && category.slug == this.currentCategory
                            )
                        ));

                        for (let category = 0; category < isAllowedCategory.length; category++) {
                            if (isAllowedCategory[category]) {
                                return 0;
                            }
                        }

                        return 1;
                    }

                    return 1;
                }
            },

        })
    </script>
@endPushOnce
