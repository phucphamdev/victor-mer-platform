@if (core()->getConfigData('show_product_price.settings.general.configuration_type') == 'product-configuration')
    <v-upload-csv>
    </v-upload-csv>
@endif
@pushOnce('scripts')
    <script type="template" id="v-upload-csv-template">
        <x-admin::modal ref="imprtModal">
            <!-- Modal Toggle -->
            <x-slot:toggle>
                <button class="transparent-button hover:bg-gray-200 dark:hover:bg-gray-800 dark:text-white">
                    <span class="icon-export text-xl text-gray-600"></span>
                    @lang('show_price_after_login::app.admin.products.upload-csv.title')
                </button>
            </x-slot>

            <!-- Modal Header -->
            <x-slot:header>
                <p class="text-lg text-gray-800 dark:text-white font-bold">
                    @lang('show_price_after_login::app.admin.products.upload-csv.title')
                </p>
            </x-slot>

            <!-- Modal Content -->
            <x-slot:content>
                <x-admin::form  ref="form">
                    <x-admin::form.control-group class="!mb-0">
                        <x-admin::form.control-group.control
                            type="file"
                            name="csv"
                            v-model="csvData"
                        >
                        </x-admin::form.control-group.control>
                    </x-admin::form.control-group><br>
                    <p class='text-gray-600 dark:text-gray-300 font-semibold'>Note. show type -> use 0 for hide Button </p>
                    <p class='text-gray-600 dark:text-gray-300 font-semibold'>Note. show type -> use 1 for hide Button and price  </p>
                </x-admin::form>
            </x-slot>

            <!-- Modal Footer -->
            <x-slot:footer >
                <button
                    type="button"
                    class="primary-button "
                    v-on:click="uploadCsv"
                >
                    @lang('show_price_after_login::app.admin.products.upload-csv.add-to-cart-title')
                </button>

                <div
                    class="secondary-button ml-2"
                    v-on:click="downloadSample"
                >
                    @lang('show_price_after_login::app.admin.products.upload-csv.download-sample')
                </div>
            </x-slot>
        </x-admin::modal>
    </script>
    <script type="module">
        app.component('v-upload-csv', {

            template: '#v-upload-csv-template',

            data() {
                return {
                    csvData: null,
                }
            },

            methods: {
                uploadCsv(e) {
                    this.$axios.post('{{ route('showproduct.product.upload.csv') }}', this.$refs.form.getValues(), {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        }
                    }).then( res => {
                        location.reload();
                    }
                ).catch( res => {
                    location.reload();
                })},

                downloadSample() {
                    window.open('{{ url('/Sample/sample.csv') }}');
                }
            },
        })
    </script>
@endPushOnce
