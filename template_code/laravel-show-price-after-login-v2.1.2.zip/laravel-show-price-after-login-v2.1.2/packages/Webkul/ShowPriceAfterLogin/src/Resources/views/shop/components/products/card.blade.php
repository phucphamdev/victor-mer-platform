<v-product-card
    {{ $attributes }}
    :product="product">
</v-product-card>

@pushOnce('scripts')
    <script
        type="text/x-template"
        id="v-product-card-template"
    >
        <!-- Grid Card -->
        <div
            class='grid gap-2.5 content-start w-full relative'
            v-if="mode != 'list'"
        >
            <div class="relative overflow-hidden group max-w-[291px] max-h-[300px] rounded">

                {!! view_render_event('bagisto.shop.components.products.card.image.before') !!}

                <a
                    :href="`{{ route('shop.product_or_category.index', '') }}/${product.url_key}`"
                    :aria-label="product.name + ' '"
                >
                    <x-shop::media.images.lazy
                        class="relative after:content-[' '] after:block after:pb-[calc(100%+9px)] bg-[#F5F5F5] group-hover:scale-105 transition-all duration-300"
                        ::src="product.base_image.medium_image_url"
                        ::key="product.id"
                        ::index="product.id"
                        width="291"
                        height="300"
                        ::alt="product.name"
                    />
                </a>

                {!! view_render_event('bagisto.shop.components.products.card.image.after') !!}

                <div class="action-items bg-black">
                    <p
                        class="inline-block absolute top-5 ltr:left-5 rtl:right-5 px-2.5  bg-[#E51A1A] rounded-[44px] text-white text-sm"
                        v-if="product.on_sale"
                    >
                        @lang('show_price_after_login::app.shop.components.products.card.sale')
                    </p>

                    <p
                        class="inline-block absolute top-5 ltr:left-5 rtl:right-5 px-2.5 bg-navyBlue rounded-[44px] text-white text-sm"
                        v-else-if="product.is_new"
                    >
                        @lang('show_price_after_login::app.shop.components.products.card.new')
                    </p>

                    <div class="group-hover:bottom-0 opacity-0 group-hover:opacity-100 transition-all duration-300 max-sm:opacity-100 max-lg:opacity-100">

                        {!! view_render_event('bagisto.shop.components.products.card.wishlist_option.before') !!}

                        @if (core()->getConfigData('general.content.shop.wishlist_option'))
                            <span
                                class="flex justify-center items-center absolute top-5 ltr:right-5 rtl:left-5 w-[30px] h-[30px] bg-white rounded-md cursor-pointer text-2xl max-sm:text-xl"
                                role="button"
                                aria-label="@lang('show_price_after_login::app.shop.components.products.card.add-to-wishlist')"
                                tabindex="0"
                                :class="product.is_wishlist ? 'icon-heart-fill' : 'icon-heart'"
                                @click="addToWishlist()"
                            >
                            </span>
                        @endif

                        {!! view_render_event('bagisto.shop.components.products.card.wishlist_option.after') !!}

                        {!! view_render_event('bagisto.shop.components.products.card.compare_option.before') !!}

                        @if (core()->getConfigData('general.content.shop.compare_option'))
                            <span
                                class="icon-compare flex justify-center items-center w-[30px] h-[30px] absolute top-16 ltr:right-5 rtl:left-5 bg-white rounded-md cursor-pointer text-2xl max-sm:text-xl"
                                role="button"
                                aria-label="@lang('show_price_after_login::app.shop.components.products.card.add-to-compare')"
                                tabindex="0"
                                @click="addToCompare(product.id)"
                            >
                            </span>
                        @endif

                        {!! view_render_event('bagisto.shop.components.products.card.compare_option.after') !!}

                        {!! view_render_event('bagisto.shop.components.products.card.add_to_cart.before') !!}

                        <button
                            class="absolute bottom-4 left-1/2 py-3 px-11 bg-white rounded-xl text-navyBlue text-xs w-max font-medium cursor-pointer -translate-x-1/2 translate-y-14 group-hover:translate-y-0 transition-all duration-300 max-sm:translate-y-2.5 max-sm:group-hover:translate-y-2.5 max-lg:translate-y-2.5 max-sm:px-7 max-sm:py-2"
                            :disabled="! product.is_saleable || isAddingToCart"
                            @click="addToCart()"
                            v-if="canAddToCart"
                        >
                            @lang('show_price_after_login::app.shop.components.products.card.add-to-cart')
                        </button>

                        <button
                            class="absolute bottom-4 left-1/2 py-3 px-11 bg-white rounded-xl text-navyBlue text-xs w-max font-medium cursor-pointer -translate-x-1/2 translate-y-14 group-hover:translate-y-0 transition-all duration-300 max-sm:translate-y-2.5 max-sm:group-hover:translate-y-2.5 max-lg:translate-y-2.5 max-sm:px-7 max-sm:py-2"
                            :disabled="! product.is_saleable || isAddingToCart"
                            @click="redirectTo(configurationType == 'product-configuration' ? (product.show_product_price ? product.show_product_price.redirect_url : ''): redirectUrl)"
                            v-else
                        >
                            @{{ title}}
                        </button>

                        {!! view_render_event('bagisto.shop.components.products.card.add_to_cart.after') !!}
                    </div>
                </div>
            </div>

            <div class="grid gap-2.5 content-start max-w-[291px]">

                {!! view_render_event('bagisto.shop.components.products.card.name.before') !!}

                <p class="text-base" v-text="product.name"></p>

                {!! view_render_event('bagisto.shop.components.products.card.name.after') !!}

                {!! view_render_event('bagisto.shop.components.products.card.price.before') !!}

                <div
                    class="flex gap-2.5 items-center font-semibold text-lg"
                    v-if="isPriceShowable"
                    v-html="product.price_html"
                >
                </div>

                {!! view_render_event('bagisto.shop.components.products.card.price.before') !!}

                <!-- Needs to implement that in future -->
                <div class="hidden flex gap-4 mt-2">
                    <span class="block w-[30px] h-[30px] bg-[#B5DCB4] rounded-full cursor-pointer"></span>

                    <span class="block w-[30px] h-[30px] bg-[#5C5C5C] rounded-full cursor-pointer"></span>
                </div>
            </div>
        </div>

        <!-- List Card -->
        <div
            class="flex gap-4 grid-cols-2 max-w-max relative max-sm:flex-wrap rounded overflow-hidden"
            v-else
        >
            <div class="relative max-w-[250px] max-h-[258px] overflow-hidden group">

                {!! view_render_event('bagisto.shop.components.products.card.image.before') !!}

                <a :href="`{{ route('shop.product_or_category.index', '') }}/${product.url_key}`">
                    <x-shop::media.images.lazy
                        class="min-w-[250px] relative after:content-[' '] after:block after:pb-[calc(100%+9px)] bg-[#F5F5F5] group-hover:scale-105 transition-all duration-300"
                        ::src="product.base_image.medium_image_url"
                        ::key="product.id"
                        ::index="product.id"
                        width="291"
                        height="300"
                        ::alt="product.name"
                    />
                </a>

                {!! view_render_event('bagisto.shop.components.products.card.image.after') !!}

                <div class="action-items bg-black">
                    <p
                        class="inline-block absolute top-5 ltr:left-5 rtl:right-5 px-2.5 bg-[#E51A1A] rounded-[44px] text-white text-sm"
                        v-if="product.on_sale"
                    >
                        @lang('show_price_after_login::app.shop.components.products.card.sale')
                    </p>

                    <p
                        class="inline-block absolute top-5 ltr:left-5 rtl:right-5 px-2.5 bg-navyBlue rounded-[44px] text-white text-sm"
                        v-else-if="product.is_new"
                    >
                        @lang('show_price_after_login::app.shop.components.products.card.new')
                    </p>

                    <div class="group-hover:bottom-0 opacity-0 transition-all duration-300 max-sm:opacity-100 group-hover:opacity-100">

                        {!! view_render_event('bagisto.shop.components.products.card.wishlist_option.before') !!}

                        @if (core()->getConfigData('general.content.shop.wishlist_option'))
                            <span
                                class="flex justify-center items-center absolute top-5 ltr:right-5 rtl:left-5 w-[30px] h-[30px] bg-white rounded-md text-2xl cursor-pointer"
                                role="button"
                                aria-label="@lang('show_price_after_login::app.shop.components.products.card.add-to-wishlist')"
                                tabindex="0"
                                :class="product.is_wishlist ? 'icon-heart-fill' : 'icon-heart'"
                                @click="addToWishlist()"
                            >
                            </span>
                        @endif

                        {!! view_render_event('bagisto.shop.components.products.card.wishlist_option.after') !!}

                        {!! view_render_event('bagisto.shop.components.products.card.compare_option.before') !!}

                        @if (core()->getConfigData('general.content.shop.compare_option'))
                            <span
                                class="icon-compare flex justify-center items-center absolute top-16 ltr:right-5 rtl:left-5 w-[30px] h-[30px] bg-white rounded-md text-2xl cursor-pointer"
                                role="button"
                                aria-label="@lang('show_price_after_login::app.shop.components.products.card.add-to-compare')"
                                tabindex="0"
                                @click="addToCompare(product.id)"
                            >
                            </span>
                        @endif

                        {!! view_render_event('bagisto.shop.components.products.card.compare_option.after') !!}
                    </div>
                </div>
            </div>

            <div class="grid gap-4 content-start">

                {!! view_render_event('bagisto.shop.components.products.card.name.before') !!}

                <p
                    class="text-base"
                    v-text="product.name"
                >
                </p>

                {!! view_render_event('bagisto.shop.components.products.card.name.after') !!}

                {!! view_render_event('bagisto.shop.components.products.card.price.before') !!}

                <div
                    class="flex gap-2.5 text-lg font-semibold"
                    v-html="product.price_html"
                    v-if="isPriceShowable"
                >
                </div>

                {!! view_render_event('bagisto.shop.components.products.card.price.after') !!}

                <!-- Needs to implement that in future -->
                <div class="hidden flex gap-4">
                    <span class="block w-[30px] h-[30px] rounded-full bg-[#B5DCB4]">
                    </span>

                    <span class="block w-[30px] h-[30px] rounded-full bg-[#5C5C5C]">
                    </span>
                </div>

                {!! view_render_event('bagisto.shop.components.products.card.price.after') !!}

                <p class="text-sm text-[#6E6E6E]" v-if="! product.avg_ratings">
                    @lang('show_price_after_login::app.shop.components.products.card.review-description')
                </p>

                {!! view_render_event('bagisto.shop.components.products.card.average_ratings.before') !!}

                <p v-else class="text-sm text-[#6E6E6E]">
                    <x-shop::products.star-rating
                        ::value="product && product.avg_ratings ? product.avg_ratings : 0"
                        :is-editable=false
                    />
                </p>

                {!! view_render_event('bagisto.shop.components.products.card.average_ratings.after') !!}

                {!! view_render_event('bagisto.shop.components.products.card.add_to_cart.before') !!}
                <x-shop::button
                    class="primary-button px-8 py-2.5 whitespace-nowrap"
                    :title="trans('show_price_after_login::app.shop.components.products.card.add-to-cart')"
                    ::loading="isAddingToCart"
                    ::disabled="! product.is_saleable || isAddingToCart"
                    @click="addToCart()"
                    v-if="canAddToCart"
                />

                <x-shop::button
                    class="primary-button px-8 py-2.5 whitespace-nowrap"
                    ::title="title"
                    ::loading="isAddingToCart"
                    ::disabled="! product.is_saleable || isAddingToCart"
                    @click="redirectTo(product)"
                    v-else
                />

                {!! view_render_event('bagisto.shop.components.products.card.add_to_cart.after') !!}
            </div>
        </div>
    </script>

    <script type="module">
        app.component('v-product-card', {
            template: '#v-product-card-template',

            props: ['mode', 'product'],

            data() {
                return {
                    isCustomer: '{{ auth()->guard('customer')->check() }}',

                    isAddingToCart: false,

                    showProductPriceStatus: parseInt('{{ core()->getConfigData('show_product_price.settings.general.status') }}'),

                    showType: '{{ core()->getConfigData('show_product_price.settings.general.hide_for_guest') }}',

                    buttonTitle: '{{ core()->getConfigData('show_product_price.settings.general.add_to_cart_title') }}',

                    redirectUrl: '{{ core()->getConfigData('show_product_price.settings.general.redirect_url') }}',

                    addToCartStatus: '{{ core()->getConfigData('show_product_price.settings.general.add_to_cart_status') }}',

                    configurationType: '{{ core()->getConfigData('show_product_price.settings.general.configuration_type') }}',

                    CustomButtonTitle: (this.showType == 'hide-buy-cart-guest' ? this.loginToBuy : this.loginToviewPrice),

                    loginToBuy: '{{ trans('show_price_after_login::app.shop.components.products.card.login-to-buy') }}',

                    loginToviewPrice: '{{ trans('show_price_after_login::app.shop.components.products.card.login-to-view-price') }}',

                    customerGroups: @json(showPriceAfterLogin::getCustomerGroup()),

                    GeneralConfAllowedGroup: @json(core()->getConfigData('show_product_price.settings.general.customer_group')),

                    GeneralConfAllowedCateg: @json(core()->getConfigData('show_product_price.settings.general.categories')),

                    currentCategory: @json(Request::path()),
                }
            },

            computed: {
                isGeneralConfiguration: function() {
                    return this.configurationType == 'general-configuration';
                },

                isAllowedCategories: function() {
                    return this.isGeneralConfiguration
                        ? this.groupAllowed || this.productCategoryAllowed
                        : this.groupAllowed && this.productCategoryAllowed;
                },

                productCofigAddToCartStatus: function() {
                    return this.showProductPriceStatus
                        && ! this.isGeneralConfiguration
                        && (
                            this.product.show_product_price
                                ? ! (this.product.show_product_price.status)
                                : 1
                        );
                },

                isPriceShowableProductConfig: function() {
                    return this.showProductPriceStatus
                        && this.priceShowStatus
                        || this.isAllowedCategories;
                },

                productCofigPriceStatus: function() {
                    return ! this.isGeneralConfiguration
                        && (
                            this.product.show_product_price
                                ? this.product.show_product_price.hide_for_guest == 'hide-buy-cart-guest'
                                : 0
                        )
                        || this.productCofigAddToCartStatus;
                },

                GeneralCofigPriceStatus: function() {
                    return this.isGeneralConfiguration
                        && this.showType == 'hide-buy-cart-guest';
                },

                priceShowStatus: function() {
                    return this.productCofigPriceStatus
                        || this.GeneralCofigPriceStatus;
                },

                isPriceShowable: function() {
                    return ! this.showProductPriceStatus
                        || this.isPriceShowableProductConfig;
                },

                canAddToCart: function() {
                    return (
                        ! this.showProductPriceStatus
                        || this.productCofigAddToCartStatus
                    )
                    || this.isAllowedCategories;
                },

                GeneralConfigButtonTitle: function() {
                    return Boolean(
                            this.buttonTitle
                            && Number(this.addToCartStatus)
                        ) ? this.buttonTitle : (
                            this.showType == 'hide-buy-cart-guest'
                                ? this.loginToBuy
                                : this.loginToviewPrice
                        );
                },

                productConfigButtonTitle: function() {
                    return this.product.show_product_price
                        ? (
                            Number(this.product.show_product_price.add_to_cart_status)
                                && this.product.show_product_price.add_to_cart_title
                                ? this.product.show_product_price.add_to_cart_title
                                : (
                                    this.product.show_product_price.hide_for_guest != "hide-buy-cart-guest"
                                        ? this.loginToviewPrice
                                        : this.loginToBuy
                                )
                        )
                        : '';
                },

                title: function() {
                    return this.isGeneralConfiguration
                        ? this.GeneralConfigButtonTitle
                        : this.productConfigButtonTitle;
                },

                groupAllowed: function() {
                    let GeneralConfAllowedGroup = this.GeneralConfAllowedGroup
                        ? this.GeneralConfAllowedGroup.split(',')
                        : [];

                    let allowedGroups = (
                        this.product.show_product_price
                        && ! this.isGeneralConfiguration
                    ) ? this.product.show_product_price.allow_customer_groups : GeneralConfAllowedGroup;

                    if (
                        (
                            (
                                this.product.show_product_price
                                && ! this.isGeneralConfiguration
                            )
                            || this.isGeneralConfiguration
                        )
                        && allowedGroups
                    ) {

                        allowedGroups = allowedGroups.map(allowedGroups => Number(allowedGroups));

                        let isAllowedCustomerGroup = this.customerGroups.map(Groups => (
                            Groups.name == '{{ auth()->user() ? auth()->user()->group->name : "Guest" }}'
                            && allowedGroups.includes(Groups.id)
                        ));

                        for (let customerGroup = 0; customerGroup < isAllowedCustomerGroup.length; customerGroup++) {
                            if (isAllowedCustomerGroup[customerGroup]) {
                                return 0;
                            }
                        }

                        return 1;
                    }

                    return 1;
                },

                productCategoryAllowed: function() {
                    let allowedCategory = this.GeneralConfAllowedCateg
                        ? this.GeneralConfAllowedCateg.split(',')
                        : [];

                    if (! allowedCategory.length) {
                        return 0;
                    }

                    if (this.isGeneralConfiguration) {
                        allowedCategory = allowedCategory.map(allowedCategory => Number(allowedCategory));

                        let isAllowedCategory = this.product.categories.map(category => (
                            allowedCategory.includes(category.id)
                            && category.slug == this.currentCategory
                        ));

                        let isCategoryInAllowedList = this.product.categories.map(category => (
                            allowedCategory.includes(category.id)
                        ));

                        for (let category = 0; category < isAllowedCategory.length; category++) {
                            if (
                                (
                                    isAllowedCategory[category]
                                    && category.slug !== this.currentCategory
                                )
                                || (
                                    isCategoryInAllowedList[category]
                                    && ['/', 'search', 'customer/wishlist'].includes(this.currentCategory)
                                )
                            ) {
                                return 0;
                            }
                        }

                        return 1;
                    }

                    return 1;
                },
            },

            methods: {
                addToWishlist() {
                    if (this.isCustomer) {
                        this.$axios.post(`{{ route('shop.api.customers.account.wishlist.store') }}`, {
                                product_id: this.product.id
                            })
                            .then(response => {
                                this.product.is_wishlist = ! this.product.is_wishlist;

                                this.$emitter.emit('add-flash', { type: 'success', message: response.data.data.message });
                            })
                            .catch(error => {});
                        } else {
                            window.location.href = "{{ route('shop.customer.session.index')}}";
                        }
                },

                addToCompare(productId) {
                    /**
                     * This will handle for customers.
                     */
                    if (this.isCustomer) {
                        this.$axios.post('{{ route("shop.api.compare.store") }}', {
                                'product_id': productId
                            })
                            .then(response => {
                                this.$emitter.emit('add-flash', { type: 'success', message: response.data.data.message });
                            })
                            .catch(error => {
                                if ([400, 422].includes(error.response.status)) {
                                    this.$emitter.emit('add-flash', { type: 'warning', message: error.response.data.data.message });

                                    return;
                                }

                                this.$emitter.emit('add-flash', { type: 'error', message: error.response.data.message});
                            });

                        return;
                    }

                    /**
                     * This will handle for guests.
                     */
                    let items = this.getStorageValue() ?? [];

                    if (items.length) {
                        if (! items.includes(productId)) {
                            items.push(productId);

                            localStorage.setItem('compare_items', JSON.stringify(items));

                            this.$emitter.emit('add-flash', { type: 'success', message: "@lang('show_price_after_login::app.shop.components.products.card.add-to-compare-success')" });
                        } else {
                            this.$emitter.emit('add-flash', { type: 'warning', message: "@lang('show_price_after_login::app.shop.components.products.card.already-in-compare')" });
                        }
                    } else {
                        localStorage.setItem('compare_items', JSON.stringify([productId]));

                        this.$emitter.emit('add-flash', { type: 'success', message: "@lang('show_price_after_login::app.shop.components.products.card.add-to-compare-success')" });

                    }
                },

                getStorageValue(key) {
                    let value = localStorage.getItem('compare_items');

                    if (! value) {
                        return [];
                    }

                    return JSON.parse(value);
                },

                addToCart() {

                    this.isAddingToCart = true;

                    this.$axios.post('{{ route("shop.api.checkout.cart.store") }}', {
                            'quantity': 1,
                            'product_id': this.product.id,
                        })
                        .then(response => {
                            if (response.data.data.redirect_uri) {
                                window.location.href = response.data.data.redirect_uri;
                            }

                            if (response.data.message) {
                                this.$emitter.emit('update-mini-cart', response.data.data );

                                this.$emitter.emit('add-flash', { type: 'success', message: response.data.message });
                            } else {
                                this.$emitter.emit('add-flash', { type: 'warning', message: response.data.data.message });
                            }

                            this.isAddingToCart = false;
                        })
                        .catch(error => {
                            this.isAddingToCart = false;

                            this.$emitter.emit('add-flash', { type: 'error', message: response.data.message });
                        });
                },

                redirectTo(product) {
                    let url = this.isGeneralConfiguration ? this.redirectUrl : (this.product.show_product_price && this.product.show_product_price.redirect_url ? this.product.show_product_price.redirect_url : '/customer/login');

                    window.location.href = '{{ url('/') }}'+ url ?? '/customer/login';
                },
            },
        });
    </script>
@endpushOnce
