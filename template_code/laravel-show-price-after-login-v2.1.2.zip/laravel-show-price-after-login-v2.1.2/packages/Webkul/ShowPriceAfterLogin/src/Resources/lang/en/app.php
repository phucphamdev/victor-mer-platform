<?php

return [
    'admin' => [
        'configurations' => [
            'index' => [
                'title'    => 'Show Price After Login',
                'settings' => [
                    'title'   => 'Settings',
                    'info'    => 'Price Show After Login',
                    'general' => [
                        'title'                     => 'General Settings',
                        'info'                      => 'The Show Price After Login module displays product prices only to logged-in users for a personalized shopping experience.',
                        'toggle'                    => 'Enable Module',
                        'hide-shop-before-login'    => 'Shop Before Login',
                        'hide-price-buy-cart-guest' => 'Price & Buy/Add to Cart ',
                        'hide-price-guest'          => 'Price',
                        'hide-buy-cart-guest'       => 'Buy/Add to Cart',
                        'hide-for-guest'            => 'Hide for Guest',
                        'configure'                 => 'Configure',
                        'configurations'            => 'Configuration',
                        'add-to-cart-title'         => 'Button Title',
                        'redirect-url'              => 'Redirect URL',
                        'add-to-cart-status'        => 'Allow Modification on Add to Cart Button',
                        'custom-category-status'    => 'Enable Custom Category',
                        'configuration-type'        => 'Configuration Priority',
                        'general-configuration'     => 'General Configuration',
                        'product-configuration'     => 'Product Configuration',
                        'allows-customre-group'     => 'Allow Customer Group',
                        'allows-categories'         => 'Allow Categories',
                    ],
                ],
            ],
        ],

        'products'   => [
            'upload-csv' => [
                'title'             => 'Upload Csv',
                'add-to-cart-title' => 'Upload',
                'download-sample'   => 'Download Sample',
                'invalid-file'      => 'Please upload a valid CSV file.',
                'product-updated'   => 'Product updated successfully.',
            ],

            'showPriceAfterLogin' => [
                'title'                     => 'Show Price After Login',
                'toggle'                    => 'Enable Module',
                'hide-shop-before-login'    => 'Shop Before Login',
                'hide-price-buy-cart-guest' => 'Price & Buy/Add to Cart',
                'hide-price-guest'          => 'Price',
                'hide-buy-cart-guest'       => 'Buy/Add to Cart',
                'hide-for-guest'            => 'Hide for Guest',
                'configure'                 => 'Configure',
                'configurations'            => 'Configuration',
                'add-to-cart-title'         => 'Button Title',
                'redirect-url'              => 'Redirect URL',
                'add-to-cart-status'        => 'Enable Add to Cart Modification',
                'custom-category-status'    => 'Enable Custom Category',
                'configuration-type'        => 'Configuration Priority',
                'general-configuration'     => 'General Configuration',
                'product-configuration'     => 'Product Configuration',
                'allows-customre-group'     => 'Allow Customer Group',
                'allows-categories'         => 'Allow Categories',
            ],
        ],
    ],

    'shop' => [
        'components' => [
            'products' => [
                'card' => [
                    'add-to-cart'                 => 'Add To Cart',
                    'add-to-compare'              => 'Add To Compare',
                    'add-to-compare-success'      => 'Item added successfully to compare list.',
                    'add-to-wishlist'             => 'Add To Wishlist',
                    'already-in-compare'          => 'Item is already added to compare list.',
                    'new'                         => 'New',
                    'review-description'          => 'Be the first to review this product',
                    'sale'                        => 'Sale',
                    'login-to-buy'                => 'Login To Buy',
                    'login-to-view-price'         => 'Login To View Price',
                ],
            ],
        ],

        'products' => [
            'view' => [
                'add-to-cart'            => 'Add To Cart',
                'add-to-compare'         => 'Product added in compare.',
                'add-to-wishlist'        => 'Add To Wishlist',
                'additional-information' => 'Additional Information',
                'already-in-compare'     => 'Product is already added in compare.',
                'buy-now'                => 'Buy Now',
                'compare'                => 'Compare',
                'description'            => 'Description',
                'related-product-title'  => 'Related Products',
                'review'                 => 'Reviews',
                'tax-inclusive'          => 'Inclusive of all taxes',
                'up-sell-title'          => 'We found other products you might like!',
                'login-to-buy'           => 'Login To Buy',
                'login-to-view-price'    => 'Login To View Price',
            ],
        ],
    ],
];
