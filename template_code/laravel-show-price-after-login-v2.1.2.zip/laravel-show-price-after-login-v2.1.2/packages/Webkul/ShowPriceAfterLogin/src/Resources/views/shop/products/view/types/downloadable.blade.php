<v-downloadable-product>

</v-downloadable-product>
@pushOnce('scripts')
    <script type="text/x-template" id="v-downloadable-product-template">
        @if ($product->type == 'downloadable')
            {!! view_render_event('bagisto.shop.products.view.downloadable.before', ['product' => $product]) !!}

            @if ($product->downloadable_samples->count())
                <div class="sample-list mb-6 mt-8">
                    <label class="flex mb-3 font-medium">
                        @lang('shop::app.products.view.type.downloadable.samples')
                    </label>

                    <ul>
                        @foreach ($product->downloadable_samples as $sample)
                            <li class="mb-2">
                                <a
                                    href="{{ route('shop.downloadable.download_sample', ['type' => 'sample', 'id' => $sample->id]) }}"
                                    class="text-[#0A49A7]"
                                    target="_blank"
                                >
                                    {{ $sample->title }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @if ($product->downloadable_links->count())
                <label class="flex mt-8 mb-4 font-medium">
                    @lang('shop::app.products.view.type.downloadable.links')
                </label>

                <div class="grid gap-4">
                    @foreach ($product->downloadable_links as $link)
                        <div class="select-none flex gap-x-4">
                            <div class="flex">
                                <v-field
                                    type="checkbox"
                                    name="links[]"
                                    value="{{ $link->id }}"
                                    id="{{ $link->id }}"
                                    class="hidden peer"
                                    rules="required"
                                    label="@lang('shop::app.products.view.type.downloadable.links')"
                                >
                                </v-field>

                                <label
                                    class="icon-uncheck text-2xl text-navyBlue peer-checked:icon-check-box peer-checked:text-navyBlue cursor-pointer"
                                    for="{{ $link->id }}"
                                ></label>

                                <label v-if="isPriceShowable"
                                    for="{{ $link->id }}"
                                    class="ltr:ml-1 rtl:mr-1 cursor-pointer"
                                >
                                    {{ $link->title . ' + ' . core()->currency($link->price) }}
                                </label>
                                <label v-else
                                    for="{{ $link->id }}"
                                    class="ltr:ml-1 rtl:mr-1 cursor-pointer"
                                >
                                    {{ $link->title  }}
                                </label>
                            </div>

                            @if (
                                $link->sample_file
                                || $link->sample_url
                            )
                                <a
                                    href="{{ route('shop.downloadable.download_sample', ['type' => 'link', 'id' => $link->id]) }}"
                                    target="_blank"
                                    class="text-[#0A49A7]"
                                >
                                    @lang('shop::app.products.view.type.downloadable.sample')
                                </a>
                            @endif
                        </div>
                    @endforeach

                    <v-error-message
                        name="links[]"
                        v-slot="{ message }"
                    >
                        <p
                            class="text-red-500 text-xs italic"
                            v-text="message"
                        >
                        </p>
                    </v-error-message>
                </div>
            @endif

            {!! view_render_event('bagisto.shop.products.view.downloadable.before', ['product' => $product]) !!}
        @endif

    </script>
    <script type="module">
        app.component('v-downloadable-product', {
            template: '#v-downloadable-product-template',

            data() {
                return {
                        showProductPriceStatus: parseInt('{{ core()->getConfigData('show_product_price.settings.general.status') }}'),

                        showType: '{{ core()->getConfigData('show_product_price.settings.general.hide_for_guest') }}',

                        buttonTitle: '{{ core()->getConfigData('show_product_price.settings.general.add_to_cart_title') }}',

                        redirectUrl: '{{ core()->getConfigData('show_product_price.settings.general.redirect_url') }}',

                        addToCartStatus: '{{ core()->getConfigData('show_product_price.settings.general.add_to_cart_status') }}',

                        configurationType: '{{ core()->getConfigData('show_product_price.settings.general.configuration_type') }}',

                        loginToBuy: '{{ trans('show_price_after_login::app.shop.products.view.login-to-buy') }}',

                        loginToviewPrice: '{{ trans('show_price_after_login::app.shop.products.view.login-to-view-price') }}',

                        customButtonTitle: (this.showType == 'hide-buy-cart-guest' ? this.loginToBuy : this.loginToviewPrice),

                        product: @json($product),

                        categories: @json($product->categories),

                        customerGroups: @json(showPriceAfterLogin::getCustomerGroup()),

                        GeneralConfAllowedGroup: @json(core()->getConfigData('show_product_price.settings.general.customer_group')),

                        GeneralConfAllowedCateg: @json(core()->getConfigData('show_product_price.settings.general.categories')),
                }
            },
            computed: {
                isGeneralConfiguration: function() {
                    return this.configurationType == 'general-configuration';
                },

                isAllowedCategories: function() {
                    if (this.isGeneralConfiguration) {
                        return this.groupAllowed
                        || this.productCategoryAllowed;
                    } else {
                        return this.groupAllowed
                        && this.productCategoryAllowed;
                    }
                },

                productCofigAddToCartStatus: function() {
                    return this.showProductPriceStatus
                    && ! this.isGeneralConfiguration
                    && (this.product.show_product_price ? ! this.product.show_product_price.status : 1);
                },

                isPriceShowableProductConfig: function() {
                    return (
                        this.showProductPriceStatus
                        && this.priceShowStatus
                    ) || this.isAllowedCategories;
                },

                productCofigPriceStatus: function() {
                    return ! this.isGeneralConfiguration
                    && (
                        (this.product.show_product_price ? this.product.show_product_price.hide_for_guest == 'hide-buy-cart-guest' : 0)
                        || this.productCofigAddToCartStatus
                    );
                },

                GeneralCofigPriceStatus: function() {
                    return this.isGeneralConfiguration
                    && this.showType == 'hide-buy-cart-guest';
                },

                priceShowStatus: function() {
                    return this.productCofigPriceStatus
                    || this.GeneralCofigPriceStatus;
                },

                isPriceShowable: function() {
                    return ! this.showProductPriceStatus
                    || this.isPriceShowableProductConfig;
                },

                groupAllowed: function() {
                    let Groups = this.customerGroups;

                    let GeneralConfAllowedGroup = this.GeneralConfAllowedGroup ?
                                                this.GeneralConfAllowedGroup.split(',') : [];

                    let allowedGroups = (
                        this.product.show_product_price
                        && this.configurationType == 'product-configuration'
                    ) ? this.product.show_product_price.allow_customer_groups : GeneralConfAllowedGroup;

                    if (! allowedGroups) {
                        return 0;
                    }

                    if (
                        (
                            this.product.show_product_price
                            && this.configurationType == 'product-configuration'
                        ) || this.isGeneralConfiguration
                    ) {

                        allowedGroups = allowedGroups.map(group => Number(group));

                        let isAllowed = Groups.map(group => (
                            group.name == '{{ auth()->user() ? auth()->user()->group->name : 'Guest' }}'
                            && allowedGroups.includes(group.id)
                        ));

                        for (let i = 0; i < isAllowed.length; i++) {
                            if (isAllowed[i]) {
                                return 1;
                            }
                        }

                        return 0;
                    }

                    return 0;
                },

                productCategoryAllowed: function() {
                    let categories = this.categories;
                    
                    let allowedCategory = this.GeneralConfAllowedCateg ?
                                        this.GeneralConfAllowedCateg.split(',') : [];

                    if (this.isGeneralConfiguration) {
                        allowedCategory = allowedCategory.map(category => Number(category));

                        let isAllowed = categories.map(category => (
                            allowedCategory.includes(category.id)
                        ));

                        for (let i = 0; i < isAllowed.length; i++) {
                            if (isAllowed[i]) {
                                return 1;
                            }
                        }

                        return 0;
                    }

                    return 0;
                }
            },

        })
    </script>
@endPushOnce
