<?php

namespace Webkul\ShowPriceAfterLogin\Repositories;

use Webkul\Core\Eloquent\Repository;

class ShowPriceAfterLogin extends Repository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return 'Webkul\ShowPriceAfterLogin\Contracts\showPriceAfterLogin';
    }
}
