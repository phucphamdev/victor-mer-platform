<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {

        if (
            ! Schema::hasColumn('show_product_price', 'locale')
            && ! Schema::hasColumn('show_product_price', 'locale')
        ) {
            Schema::table('show_product_price', function (Blueprint $table) {
                $table->string('locale');
                $table->string('channel');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (
            Schema::hasColumn('show_product_price', 'locale')
            && Schema::hasColumn('show_product_price', 'channel')
        ) {
            Schema::dropColumns('show_product_price', ['locale', 'channel']);
        }
    }
};
