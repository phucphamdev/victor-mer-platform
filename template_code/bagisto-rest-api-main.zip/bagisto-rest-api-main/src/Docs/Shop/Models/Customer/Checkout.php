<?php

namespace Webkul\RestApi\Docs\Shop\Models\Customer;

/**
 * @OA\Schema(
 *     title="Checkout",
 *     description="Checkout model",
 * )
 */
class Checkout {}
