<?php

namespace Webkul\RestApi\Http\Controllers\V1\Admin\Marketing;

use Webkul\RestApi\Http\Controllers\V1\Admin\AdminController;

class MarketingController extends AdminController {}
