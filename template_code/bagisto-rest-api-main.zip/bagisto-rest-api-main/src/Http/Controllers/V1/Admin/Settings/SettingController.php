<?php

namespace Webkul\RestApi\Http\Controllers\V1\Admin\Settings;

use Webkul\RestApi\Http\Controllers\V1\Admin\AdminController;

class SettingController extends AdminController {}
