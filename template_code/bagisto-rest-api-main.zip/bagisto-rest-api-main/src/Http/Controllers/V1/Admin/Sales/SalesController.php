<?php

namespace Webkul\RestApi\Http\Controllers\V1\Admin\Sales;

use Webkul\RestApi\Http\Controllers\V1\Admin\AdminController;

class SalesController extends AdminController {}
