<?php

namespace Webkul\RestApi\Http\Controllers\V1\Shop\Catalog;

use Webkul\RestApi\Http\Controllers\V1\Shop\ShopController;

class CatalogController extends ShopController {}
