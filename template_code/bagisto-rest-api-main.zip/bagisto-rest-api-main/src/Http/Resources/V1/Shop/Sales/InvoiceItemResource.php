<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Sales;

use Webkul\RestApi\Http\Resources\V1\Admin\Sales\InvoiceItemResource as BaseInvoiceItemResource;

class InvoiceItemResource extends BaseInvoiceItemResource {}
