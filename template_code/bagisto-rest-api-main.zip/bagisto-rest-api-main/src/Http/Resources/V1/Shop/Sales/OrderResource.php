<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Sales;

use Webkul\RestApi\Http\Resources\V1\Admin\Sales\OrderResource as BaseOrderResource;

class OrderResource extends BaseOrderResource {}
