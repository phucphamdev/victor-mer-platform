<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Core;

use Webkul\RestApi\Http\Resources\V1\Admin\Settings\ConfigurationResource as AdminConfigurationResource;

class ConfigurationResource extends AdminConfigurationResource {}
