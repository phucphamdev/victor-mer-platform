<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Catalog;

use Webkul\RestApi\Http\Resources\V1\Admin\Catalog\AttributeGroupResource as AdminAttributeGroupResource;

class AttributeGroupResource extends AdminAttributeGroupResource {}
