<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Sales;

use Webkul\RestApi\Http\Resources\V1\Admin\Sales\ShipmentItemResource as BaseShipmentItemResource;

class ShipmentItemResource extends BaseShipmentItemResource {}
