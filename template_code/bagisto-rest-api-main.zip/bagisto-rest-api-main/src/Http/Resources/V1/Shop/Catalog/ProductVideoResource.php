<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Catalog;

use Webkul\RestApi\Http\Resources\V1\Admin\Catalog\ProductVideoResource as AdminProductVideoResource;

class ProductVideoResource extends AdminProductVideoResource {}
