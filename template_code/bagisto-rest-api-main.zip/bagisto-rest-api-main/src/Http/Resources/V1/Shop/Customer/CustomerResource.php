<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Customer;

use Webkul\RestApi\Http\Resources\V1\Admin\Customer\CustomerResource as AdminCustomerResource;

class CustomerResource extends AdminCustomerResource {}
