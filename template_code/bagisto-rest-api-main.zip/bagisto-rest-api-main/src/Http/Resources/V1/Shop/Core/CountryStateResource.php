<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Core;

use Webkul\RestApi\Http\Resources\V1\Admin\Settings\CountryStateResource as AdminCountryStateResource;

class CountryStateResource extends AdminCountryStateResource {}
