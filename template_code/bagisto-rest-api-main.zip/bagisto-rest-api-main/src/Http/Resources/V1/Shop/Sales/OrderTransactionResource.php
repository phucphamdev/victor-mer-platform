<?php

namespace Webkul\RestApi\Http\Resources\V1\Shop\Sales;

use Webkul\RestApi\Http\Resources\V1\Admin\Sales\OrderTransactionResource as BaseOrderTransactionResource;

class OrderTransactionResource extends BaseOrderTransactionResource {}
