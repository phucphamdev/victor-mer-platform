### 1. Introduction:

laravel Search-suggestion is a feature to make it faster to complete searches that you're beginning to type. Its make your website more attractive.

It packs in lots of demanding features that allows your business to scale in no time:
1. product category will be visible on auto search suggestion.
2. product image will be visible on auto search suggestion result.
3. price of each product will be visible on search suggestion.
4. total searched term will be visible on search suggestion.
5. admin can disable visiblity of category/product/term from the auto search.
6. admin can set total number of categories/product visible on auto search suggestion.

### 2. Requirements:

* **Bagisto**: v2.2.2.

### 3. Installation:

* Unzip the respective extension zip and then merge "suggestion" inside the webkul package.
* Goto config/app.php file and add following line under 'providers'

~~~
Webkul\Suggestion\Providers\SuggestionServiceProvider::class,
~~~

* Goto composer.json file and add following line under 'psr-4'

~~~
"Webkul\\Suggestion\\": "packages/Webkul/Suggestion/src"
~~~
* In the `config/bagisto-vite.php` file, add the following line under the 'viters' section:

   ```php

    'suggestion' => [
        'hot_file'                 => 'suggestion-default-vite.hot',
        'build_directory'          => 'themes/suggestion/default/build',
        'package_assets_directory' => 'src/Resources/assets',
    ],  

* Run these commands below to complete the setup

~~~
composer dump-autoload
~~~

~~~
php artisan optimize
~~~

~~~
php artisan vendor:publish --provider="Webkul\Suggestion\Providers\SuggestionServiceProvider" --force

~~~
Run the following commands under the path packages/Webkul/Suggestion
   ```
   npm i
   ```

   ```
   npm run build
   ```

> That's it, now just execute the project on your specified domain.
