# CHANGELOG for v2.2.2

## **v2.2.2( 23 August, 2024)** - _Release_

* [Compatability] Compatible with bagisto v2.2.2.

* [Enhancement] When we get the search-suggestion result then if we click outside anywhere then it should be closed

* [Bug] while searching the product by name showing results of products but unable to scroll them to see
  all the search results products

* [Bug] When we search the large text then get a blank page and an exception in the console


## **v2.1.x( 06 July, 2024)** - _Release_

* [Compatability] Compatible with bagisto v2.1.x.

## **v2.0.0( 06 June, 2024)** - _Release_

* [Compatability] Compatible with bagisto v2.0.0.

* [Enhancement] In the search result if we have more than 6 products should be shown then show the show more button bottom right of the search result container.

* [Enhancement] Please add the description of the search suggestion status.

* [Enhancement] When a search suggestion is opened, it should close upon clicking elsewhere.

* [Enhancement] please change the color of the popular products section to match the color scheme of the Bagisto theme.

* [Bug] When we add a prod. in any category then Search keywords are not highlighted with product name

* [Bug] When we add a script in product name then search this product so after that shows a pop up

* [Bug] display category option is disabled still it is showing the category in the search suggestions.

* [Bug] display product option is disabled still it is showing the products in the search suggestions.

* [Bug] display term option is disabled still it is showing the term in the search suggestions.

* [Bug] Not showing variant of the configurable product in the search suggestion result.

* [Bug] Getting the page not found error when clicking the suggestion quantity on the search suggestion.

* [Bug] Search bar box is not working properly when searching the products normally.

* [Bug] After searching for the term 'do', the search suggestions highlight both 'do' and 'od' products. However, upon clicking on the search result count, only the products containing 'do' are shown.

* [Bug] Functionality is not working, When entering 5 categories & 1 product in the main configuration, multiple products are displayed instead of just one.

* [Bug] Search suggestion should work according to the show product section. Need to delete the show category section in the configuration because if shows the category for a product so enables the display category status.

* [Bug] When opening any section in the Customer profile, the My Account drop-down should be closed.

## **v1.4.3(27th of Jul, 2022)** - _Release_

* [compatability] Compatible with bagisto v1.4.3.

## **v1.3.3(9th of Feb, 2022)** - _Release_

* [compatability] Compatible with bagisto v1.3.3.

## **v1.3.1(2nd August, 2021)** - _Release_

* [compatability] Compatible with bagisto v1.3.1.

* [bug] if no product match with search term then show valid message.

* [bug] fix default theme homepage layout.

* [bug] getting error while installation.

* [bug] add space b/w the price or product name.

* [bug] getting error & blank page when view any product.
