<?php

return [
    'image-gallery' => [
        'hot_file'                 => 'image-gallery-vite.hot',
        'build_directory'          => 'themes/image-gallery/default/build',
        'package_assets_directory' => 'src/Resources/assets',
    ],
];