<?php

namespace Webkul\ImageGallery\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ManageGalleryProxy extends ModelProxy
{
}