<?php

namespace Webkul\Inventory\Models;

use Konekt\Concord\Proxies\ModelProxy;

class InventorySourceProxy extends ModelProxy
{

}