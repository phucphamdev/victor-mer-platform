<?php

namespace Webkul\Inventory\Contracts;

interface InventorySource
{
}