<?php

namespace Webkul\Category\Contracts;

interface CategoryTranslation
{
}