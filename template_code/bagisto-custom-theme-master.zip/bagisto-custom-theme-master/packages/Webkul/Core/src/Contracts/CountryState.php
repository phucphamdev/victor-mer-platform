<?php

namespace Webkul\Core\Contracts;

interface CountryState
{
}