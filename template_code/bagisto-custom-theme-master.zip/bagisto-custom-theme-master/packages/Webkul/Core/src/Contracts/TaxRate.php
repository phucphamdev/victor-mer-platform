<?php

namespace Webkul\Core\Contracts;

interface TaxRate
{
}