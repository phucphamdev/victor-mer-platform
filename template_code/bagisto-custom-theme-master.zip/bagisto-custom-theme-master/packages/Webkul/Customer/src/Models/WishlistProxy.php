<?php

namespace Webkul\Customer\Models;

use Konekt\Concord\Proxies\ModelProxy;

class WishlistProxy extends ModelProxy
{

}