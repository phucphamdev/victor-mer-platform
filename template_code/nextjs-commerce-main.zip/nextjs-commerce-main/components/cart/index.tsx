import CartModal from "./modal";
export default async function Cart() {
  return <CartModal />;
}
