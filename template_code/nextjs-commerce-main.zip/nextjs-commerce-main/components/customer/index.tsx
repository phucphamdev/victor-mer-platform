import CredentialModal from "./modal";

export default function UserAccount() {
  return <CredentialModal />;
}
