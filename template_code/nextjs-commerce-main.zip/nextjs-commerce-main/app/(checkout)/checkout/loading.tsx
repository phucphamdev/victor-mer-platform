import ProductCartSkeleton from "@/components/checkout/product-cart-skeleton";

const Loading = () => {
  return <ProductCartSkeleton />;
};

export default Loading;
