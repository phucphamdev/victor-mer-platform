import { handler } from "@/auth";

export { handler as GET, handler as POST };
