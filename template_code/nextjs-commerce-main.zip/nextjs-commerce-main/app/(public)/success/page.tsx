import EmptyCartPage from "@/components/checkout/success/empty-cart";
const CartPage = async () => {
  return <EmptyCartPage />;
};

export default CartPage;
