import { AuthPlaceHolder } from "@/components/customer/placeholder";

const Loading = () => {
  return <AuthPlaceHolder />;
};

export default Loading;
