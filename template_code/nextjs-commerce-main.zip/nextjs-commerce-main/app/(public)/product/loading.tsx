import { ProductPageSkeleton } from "@/components/product/place-order";

export default function Loading() {
  return <ProductPageSkeleton />;
}
