<tbody {{ $attributes->merge(['class' => 'bg-white']) }}>
    {{ $slot }}
</tbody>