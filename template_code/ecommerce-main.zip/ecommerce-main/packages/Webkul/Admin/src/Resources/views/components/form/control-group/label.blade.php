<label {{ $attributes->merge(['class' => 'mb-1.5 flex items-center gap-1 text-xs font-medium text-gray-800 dark:text-white']) }}>
    {{ $slot }}
</label>
