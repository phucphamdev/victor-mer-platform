<?php

return [
    [
        'key' => 'preorder',
        'name' => 'preorder::app.admin.layouts.preorder',
        'route' => 'admin.preorder.preorders.index',
        'sort' => 3,
        'icon-class' => 'preorder-icon',
    ]
];