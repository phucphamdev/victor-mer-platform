<?php

namespace Webkul\PreOrder\Contracts;

interface PreOrderItem
{
}