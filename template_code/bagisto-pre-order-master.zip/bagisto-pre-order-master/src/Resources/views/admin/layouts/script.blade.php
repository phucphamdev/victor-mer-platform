
<script src="{{ asset('vendor/webkul/preorder/assets/js/preorder.js') }}"></script>