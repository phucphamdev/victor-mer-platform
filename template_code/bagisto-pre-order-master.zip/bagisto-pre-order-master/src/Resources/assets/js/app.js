Vue.component("date", require("./components/date"));
Vue.directive("debounce", require("./directives/debounce"));

require('flatpickr/dist/flatpickr.css');
