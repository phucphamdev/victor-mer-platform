### 1. Introduction:

Bagisto CustomerCreditMax extension limit the customers to order products if they have pending invoice at the store.

It packs in lots of demanding features that allows your business to scale in no time:

* Admin can set customer credit status.
* Admin can set customer credit amount.

### 2. Requirements:

* **Bagisto**: v1.3.1


### 3. Installation:

* Unzip the respective extension zip and then merge "packages" folder into project root directory.
* Goto config/app.php file and add following line under 'providers'

~~~
Webkul\CustomerCreditMax\Providers\CustomerCreditMaxServiceProvider::class
~~~

* Goto composer.json file and add following line under 'psr-4'

~~~
"Webkul\\CustomerCreditMax\\": "packages/Webkul/CustomerCreditMax/src"
~~~

* Run these commands below to complete the setup

~~~
composer dump-autoload
~~~

~~~
php artisan vendor:publish --force
~~~

> That's it, now just execute the project on your specified domain.
