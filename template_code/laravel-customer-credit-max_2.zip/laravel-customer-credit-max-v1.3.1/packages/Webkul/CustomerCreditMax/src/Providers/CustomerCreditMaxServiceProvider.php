<?php

namespace Webkul\CustomerCreditMax\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Routing\Router;

class CustomerCreditMaxServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot(Router $router)
    {
        $this->loadTranslationsFrom(__DIR__ . '/../Resources/lang', 'customercreditmax');

        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'customercreditmax');

        $this->app->register(EventServiceProvider::class);

        $this->publishes([
            __DIR__ . '/../Resources/views/shop/velocity/customers/account/profile/index.blade.php' => resource_path('themes/velocity/views/customers/account/profile/index.blade.php'),
        ]);

        $this->publishes([
            __DIR__ . '/../Resources/views/shop/default/customers/account/profile/index.blade.php' => resource_path('themes/default/views/customers/account/profile/index.blade.php'),
        ]);
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->mergeConfigFrom(
            dirname(__DIR__) . '/Config/system.php', 'core'
        );
    }
}