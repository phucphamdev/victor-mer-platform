<?php

return [
    'admin' => [
        'system' => [
            'credit-max' => 'Credit Max',
            'use-credit-max' => 'Use Credit Max',
            'max-credit-amount' => 'Max Credit Amount'
        ]
    ],

    'shop' => [
        'layouts' => [
            'credit-max' => 'Credit Max'
        ],
        'credit-limit' => [
            'exceed-message' => 'Your available credit limit has been exceeded. Please pay your pending invoice.',
            'limit' => 'Credit Max Limit'
        ],
    ]
];