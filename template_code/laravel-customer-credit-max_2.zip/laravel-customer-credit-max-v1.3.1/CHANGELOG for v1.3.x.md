# CHANGELOG for v1.3.x

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v1.3.1(11 of may, 2021)** - *Release*

* [feature] Compatible with bagisto version 1.3.1.


## **v0.1.2(9th of Dec, 2020)** - Release

* [fix] Added credit max information in customer profile

* [fix] Added validation for customer max limit for negative value

* [fix] Fixed credit max message grammer

## **v0.1.1(28th of June, 2019)** - Release

* [bug] If customer credit max amount is reached and he try to place another order then he should get a notification to pay for previous order

* [bug] If admin cancel the order place by customer, then customer should be able to place an order again of the max credit amount.

* [bug] Getting exception when click on buy now, if customer has reached his maximum limit.

## **v0.1.0(14th of Jube, 2019)** - *Release*


* [feature] Admin can set customer credit status.

* [feature] Admin can set customer credit amount.
