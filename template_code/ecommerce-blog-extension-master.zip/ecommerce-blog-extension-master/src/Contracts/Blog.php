<?php

namespace Webkul\Article\Contracts;

interface Blog
{
}