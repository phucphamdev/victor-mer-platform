<?php

namespace Webkul\Article\Contracts;

interface Category
{
}