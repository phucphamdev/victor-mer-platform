<?php

namespace Webkul\Article\Contracts;

interface Tag
{
}