<?php

namespace Webkul\Article\Contracts;

interface Comment
{
}