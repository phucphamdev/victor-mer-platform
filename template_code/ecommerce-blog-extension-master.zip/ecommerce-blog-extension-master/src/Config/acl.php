<?php

return [
    [
        'key' => 'article',
        'name' => 'Article',
        'route' => 'admin.blog.index',
        'sort' => 2
    ]
];