@extends('shop::layouts.master')

@section('page_title')
    Package Article
@stop

@section('content-wrapper')

    <div class="main">
        Package Article
    </div>

@stop