@extends('admin::layouts.master')

@section('page_title')
    Package Article
@stop

@section('content-wrapper')

    <div class="content full-page dashboard">
        <div class="page-header">
            <div class="page-title">
                <h1>Package Article</h1>
            </div>

            <div class="page-action">
            </div>
        </div>

        <div class="page-content">
        </div>
    </div>

@stop