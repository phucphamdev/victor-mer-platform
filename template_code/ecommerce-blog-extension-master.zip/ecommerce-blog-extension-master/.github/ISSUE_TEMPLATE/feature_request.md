---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

---
name: "💡 Feature Request"
about: 'Share your ideas with our team or request new features'
---
