<?php

return [
    'stripe'  => [
        'code'        => 'stripe',
        'title'       => 'Stripe',
        'description' => 'Stripe',
        'class'       => 'Wontonee\Stripe\Payment\Stripe',
        'active'      => true,
        'sort'        => 7,
    ],
];