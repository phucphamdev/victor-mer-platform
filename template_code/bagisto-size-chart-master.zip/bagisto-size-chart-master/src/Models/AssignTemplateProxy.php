<?php

namespace Webkul\SizeChart\Models;

use Konekt\Concord\Proxies\ModelProxy;

class AssignTemplateProxy extends ModelProxy
{

}