<?php

return [
    'name'    => 'Webkul Bagisto Booking Product',
    'version' => core()->version(),
];
