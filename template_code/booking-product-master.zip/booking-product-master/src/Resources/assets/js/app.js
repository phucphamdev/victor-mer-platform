import app from '../../../../../Admin/src/Resources/assets/js/app';

import VueCal from 'vue-cal';
import 'vue-cal/dist/vuecal.css';

app.component('vue-cal', VueCal);