<div {{ $attributes->merge(['class' => 'mb-2.5']) }}>
    {{ $slot }}
</div>
