<?php

namespace Webkul\BookingProduct\Models;

use Konekt\Concord\Proxies\ModelProxy;

class BookingProxy extends ModelProxy {}
