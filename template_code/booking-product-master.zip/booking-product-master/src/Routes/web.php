<?php

/**
 * Admin routes.
 */
require 'admin-routes.php';

/**
 * Shop routes.
 */
require 'front-routes.php';
