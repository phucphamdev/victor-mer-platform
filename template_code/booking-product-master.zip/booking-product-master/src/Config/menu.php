<?php

return [
    [
        'key'   => 'sales.bookings',
        'name'  => 'booking::app.admin.sales.bookings.title',
        'route' => 'admin.sales.bookings.index',
        'sort'  => 6,
        'icon'  => '',
    ],
];
