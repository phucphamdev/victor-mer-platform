<?php

return [
    'booking' => [
        'key'   => 'booking',
        'name'  => 'booking::app.admin.catalog.products.type.booking',
        'class' => 'Webkul\BookingProduct\Type\Booking',
        'sort'  => 7,
    ],
];
