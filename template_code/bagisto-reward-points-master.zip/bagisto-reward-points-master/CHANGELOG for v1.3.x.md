# Changelog for Bagisto Rewards

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v1.3.2(10th of Jan 2022)** - *Release*

* [compatiblity] Compatiblity issue with bagisto v1.3.2.