<?php

return [
    [
        'key'   => 'account.reward_points',
        'name'  => 'rewards::app.layouts.reward_points',
        'route' => 'customer.rewards.index',
        'sort'  => 8,
    ],
];
