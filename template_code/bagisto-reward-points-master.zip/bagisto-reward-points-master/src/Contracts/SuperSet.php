<?php

namespace Webkul\TableRate\Contracts;

interface SuperSet
{
}