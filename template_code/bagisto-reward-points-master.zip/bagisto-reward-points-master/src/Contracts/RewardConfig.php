<?php

namespace Webkul\Rewards\Contracts;

interface RewardConfig
{
}