<?php

namespace Webkul\TableRate\Contracts;

interface ShippingRate
{
}