<?php

namespace Webkul\Rewards\Contracts;

interface ProductSpecificTimeReward
{
}