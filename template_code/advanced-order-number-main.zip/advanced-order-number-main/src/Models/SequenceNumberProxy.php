<?php

namespace WebbyTroops\AdvancedOrderNumber\Models;

use Konekt\Concord\Proxies\ModelProxy;

class SequenceNumberProxy extends ModelProxy
{

}