<?php
return [
    'admin' => [
        'system' => [
           'advanced-order-numbers' => 'Advanced Order Numbers',
            'general' => 'General',
            'order-number' => 'Custom Order Number',
            'invoice-number' => 'Custom Invoice Number',
            'shipment-number' => 'Custom Shipment Number',
            'refund-number' => 'Custom Refund Number',
            'advance-order-number-prefix' => 'Prefix',
            'advance-order-number-suffix' => 'Suffix',
            'advance-order-number-length' => 'Length',
            'advance-order-number-start-counter' => 'Start Counter',
            'advance-order-counter-step' => 'Counter Step',
            'advance-order-reset-counter' => 'Reset Counter Time',
            'reset_message' => 'Number reset succesful' 
        ]
    ]
    
    
];