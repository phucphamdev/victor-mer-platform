<?php

namespace WebbyTroops\AdvancedOrderNumber\Contracts;

interface SequenceNumber
{
}