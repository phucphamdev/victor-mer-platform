<?php

return [

    'modules' => [

         \WebbyTroops\AdvancedOrderNumber\Providers\ModuleServiceProvider::class

    ],
];
