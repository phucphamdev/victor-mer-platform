<?php

return [
    [
        'key' => 'suggestion',
        'name' => 'Suggestion',
        'route' => 'suggestion.admin.index',
        'sort' => 2
    ]
];