@extends('shop::layouts.master')

@section('page_title')
    Package Suggestion
@stop

@section('content-wrapper')

    <div class="main">
        Package Suggestion
    </div>

@stop