<?php
return [
    'popular_products' => 'Popular products',
    'in' =>'in',
    'no_results' => 'No Results Found',
    'starting_from' => 'Starting from',
]

?>