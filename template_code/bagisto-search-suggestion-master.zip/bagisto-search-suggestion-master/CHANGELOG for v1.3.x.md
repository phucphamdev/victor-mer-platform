# CHANGELOG for v1.3.x

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v1.3.2(12th of Jan, 2022)** - *Release*

* [compatible] Compatible with Bagisto v1.3.2