## Changelog

All notable changes to `bagisto-eu/tax-rates` will be documented in this file

## 1.0.0

- initial release