# CHANGELOG for Bagisto Product Label System

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v1.3.2(12th of Jan 2022)** - *Release*

* [compatability] compatible with Bagisto 1.3.2