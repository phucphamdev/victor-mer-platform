<?php

Route::group(['middleware' => ['web', 'theme', 'locale', 'currency']], function () {




});