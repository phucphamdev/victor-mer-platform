<?php

namespace Webkul\ProductLabelSystem\Contracts;

interface ProductLabelImage
{
}