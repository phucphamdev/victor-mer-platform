<?php

namespace Webkul\ProductLabelSystem\Contracts;

interface ProductLabel
{
}