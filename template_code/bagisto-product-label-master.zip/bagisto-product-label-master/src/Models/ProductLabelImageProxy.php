<?php

namespace Webkul\ProductLabelSystem\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ProductLabelImageProxy extends ModelProxy
{

}