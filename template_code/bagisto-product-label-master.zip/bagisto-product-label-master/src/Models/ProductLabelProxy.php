<?php

namespace Webkul\ProductLabelSystem\Models;

use Konekt\Concord\Proxies\ModelProxy;

class ProductLabelProxy extends ModelProxy
{

}