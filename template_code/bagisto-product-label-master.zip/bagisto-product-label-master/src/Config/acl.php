<?php

return [
    [
        'key' => 'productlabelsystem',
        'name' => 'productlabelsystem::app.acl.product_label_system',
        'route' => 'productlabelsystem.admin.productlabel.index',
        'sort' => 2
    ], [
        'key' => 'productlabelsystem.productlabel',
        'name' => 'productlabelsystem::app.acl.product_label',
        'route' => 'productlabelsystem.admin.productlabel.index',
        'sort' => 1
    ],
];