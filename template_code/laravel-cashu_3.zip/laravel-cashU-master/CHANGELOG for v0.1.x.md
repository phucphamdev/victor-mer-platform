# CHANGELOG for v0.1.x

## **v0.1.2(30th of September, 2020)** - Release

* [feature] compatible with Bagisto v1.2.0

## **v0.1.1(9th of August, 2019)** - Release

* [feature] customers can pay through cashU payment gateway.
