### 1. Introduction:

Bagisto CashU extension has allow customers to pay for others using this payment gateway.

### 2. Requirements:

* **Bagisto**: v0.1.6 to 1.2.0

### 3. Installation:

* Unzip the respective extension zip and then merge "packages" folder into project root directory.
* Goto config/app.php file and add following line under 'providers'.

~~~
Webkul\CashU\Providers\CashUServiceProvider::class
~~~

* Goto composer.json file and add following line under 'psr-4'

~~~
"Webkul\\CashU\\": "packages/Webkul/CashU/src"
~~~

* Goto VerifyCsrfToken.php file and add following line in protected $except array (FilePath - app->Http->Middleware->VerifyCsrfToken.php)

~~~
'cashu/callback',
'cashu/cancel'
~~~

* Cashu Merchent Account's URL

    * Return URL

    ~~~
    https://yourdomain.com/cashu/callback
    ~~~

    * Sorry URL

    ~~~
    https://yourdomain.com/cashu/cancel
    ~~~

* Run these commands below to complete the setup

~~~
composer dump-autoload
~~~

> That's it, now just execute the project on your specified domain.
