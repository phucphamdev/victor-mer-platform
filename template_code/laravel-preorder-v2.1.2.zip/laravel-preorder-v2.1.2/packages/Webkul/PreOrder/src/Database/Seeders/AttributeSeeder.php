<?php

namespace Webkul\PreOrder\Database\Seeders;

use Illuminate\Database\Seeder;
use Webkul\Attribute\Repositories\AttributeRepository;
use Webkul\Attribute\Repositories\AttributeFamilyRepository;

class AttributeSeeder extends Seeder
{
    public function run()
    {
        $allowPreOrderAttribute = app(AttributeRepository::class)->create([
            "code"                => "allow_preorder",
            "type"                => "boolean",
            "admin_name"          => "Allow Preorder",
            "is_required"         => 0,
            "is_unique"           => 0,
            "validation"          => "",
            "value_per_locale"    => 0,
            "value_per_channel"   => 1,
            "is_filterable"       => 0,
            "is_configurable"     => 0,
            "is_visible_on_front" => 0,
            "is_user_defined"     => 1,
            "use_in_flat"         => 1,
        ]);

        $preOrderQtyAttribute = app(AttributeRepository::class)->create([
            "code"                => "preorder_qty",
            "type"                => "text",
            "admin_name"          => "Preorder Qty",
            "is_required"         => 0,
            "is_unique"           => 0,
            "validation"          => "numeric",
            "value_per_locale"    => 0,
            "value_per_channel"   => 1,
            "is_filterable"       => 0,
            "is_configurable"     => 0,
            "is_visible_on_front" => 0,
            "is_user_defined"     => 1,
            "use_in_flat"         => 1,
        ]);

        $preOrderAvailabilityAttribute = app(AttributeRepository::class)->create([
            "code"                => "preorder_availability",
            "type"                => "date",
            "admin_name"          => "Product Availability",
            "is_required"         => 0,
            "is_unique"           => 0,
            "validation"          => "",
            "value_per_locale"    => 0,
            "value_per_channel"   => 1,
            "is_filterable"       => 0,
            "is_configurable"     => 0,
            "is_visible_on_front" => 0,
            "is_user_defined"     => 1,
            "use_in_flat"         => 1,
        ]);

        $attributeFamilies = app(AttributeFamilyRepository::class)->all();

        foreach ($attributeFamilies as $attributeFamily) {
            $generalGroup = $attributeFamily->attribute_groups()->where('name', 'General')->first();

            $generalGroup->custom_attributes()->save($allowPreOrderAttribute, [ 'position' => $generalGroup->custom_attributes()->count() + 1 ]);

            $generalGroup->custom_attributes()->save($preOrderQtyAttribute, [ 'position' => $generalGroup->custom_attributes()->count() + 2 ]);

            $generalGroup->custom_attributes()->save($preOrderAvailabilityAttribute, [ 'position' => $generalGroup->custom_attributes()->count() + 3 ]);
        }
    }
}