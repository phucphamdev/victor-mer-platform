<?php

namespace Webkul\PreOrder\Contracts;

interface PreOrderItem
{
    /**
     * Pre-order type is partial.
     */
    public const TYPE_PARTIAL = 'partial';

    /**
     * Pre-order status is pending.
     */
    public const STATUS_PENDING = 'pending';

    /**
     * Pre-order status is completed.
     */
    public const STATUS_COMPLETED = 'completed';
}