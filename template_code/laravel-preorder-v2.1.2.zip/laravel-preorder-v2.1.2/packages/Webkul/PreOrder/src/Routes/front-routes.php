<?php
use Illuminate\Support\Facades\Route;
use Webkul\PreOrder\Http\Controllers\Shop\PreOrderController;

Route::group(['middleware' => ['theme', 'locale', 'currency']], function () {
    Route::controller(PreOrderController::class)->group(function () {
        Route::get('complete-preorder/{token}', 'complete')->name('pre_order.shop.pre_order.complete');
    });
});