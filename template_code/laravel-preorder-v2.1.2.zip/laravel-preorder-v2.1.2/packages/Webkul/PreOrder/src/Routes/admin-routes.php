<?php

use Illuminate\Support\Facades\Route;
use Webkul\PreOrder\Http\Controllers\Admin\PreOrderController;

Route::group(['middleware' => ['admin']], function () {
    Route::controller(PreOrderController::class)->prefix('admin')->group(function () {          
        Route::get('pre-orders', 'index')->name('admin.pre_order.pre_orders.index');

        Route::post('pre-orders/notify-customer', 'notifyCustomer')->name('admin.pre_order.pre_orders.notify_customer');
    });
});