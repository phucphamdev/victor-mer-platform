<?php

namespace Webkul\PreOrder\Http\Controllers\Shop;

use Illuminate\Http\Resources\Json\JsonResource;
use Webkul\Category\Repositories\CategoryRepository;
use Webkul\PreOrder\Http\Resources\ProductResource;
use Webkul\Product\Repositories\ProductRepository;
use Webkul\Shop\Http\Controllers\API\ProductController as BaseProductController;

class ProductController extends BaseProductController
{
    /**
     * Create a controller instance.
     *
     * @return void
     */
    public function __construct(
        protected CategoryRepository $categoryRepository,
        protected ProductRepository $productRepository,
    ) {}

    /**
     * Product listings.
     */
    public function index(): JsonResource
    {
        return ProductResource::collection($this->productRepository->getAll());
    }
}