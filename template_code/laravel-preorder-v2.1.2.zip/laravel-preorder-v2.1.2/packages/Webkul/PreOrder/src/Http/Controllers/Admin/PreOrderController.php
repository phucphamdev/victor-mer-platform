<?php

namespace Webkul\PreOrder\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Mail;
use Webkul\PreOrder\DataGrids\Admin\PreOrder;
use Webkul\PreOrder\Mail\ProductInStockNotification;
use Webkul\PreOrder\Repositories\PreOrderItemRepository;

class PreOrderController extends Controller
{
    /**
     * @var int
     */
    public const ONE = 1;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(protected PreOrderItemRepository $preOrderItemRepository) 
    {}

    /**
     * Method to populate the seller order page which will be populated.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        if (request()->ajax()) {
            return app(PreOrder::class)->toJson();
        }
        
        return view('pre_order::admin.pre-orders.index');
    }

    /**
     * Mass notify customers for in stock Pre-order products.
     * 
     * @return \Illuminate\Http\JsonResponse
     */
    public function notifyCustomer()
    {
        $preOrderItemIds = request()->input('indices');

        foreach ($preOrderItemIds as $preOrderItemId) {
            $preOrderItem = $this->preOrderItemRepository->find($preOrderItemId);

            $result = $this->preOrderItemRepository->canBeComplete($preOrderItem->order_item);
            
            if (
                $result['isInStock'] 
                && $result['condition']
            ) {
                try {
                    Mail::send(new ProductInStockNotification($preOrderItem));
    
                    $this->preOrderItemRepository->update([
                        'email_sent' => self::ONE,
                    ], $preOrderItem->id);

                    return new JsonResponse([
                        'message' => trans('pre_order::app.admin.pre-orders.mass-notify-success'),
                    ], 200);
                } catch (\Exception $e) {   
                }
            } 

            return new JsonResponse([
                'message' => trans('pre_order::app.admin.pre-orders.mass-notify-error'),
            ], 500);
        }
    }
}