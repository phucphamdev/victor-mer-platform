<?php

namespace Webkul\PreOrder\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Webkul\Shop\Http\Resources\ProductResource;

class WishlistResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'      => $this->id,
            'options' => array_values($this->resource->additional['attributes'] ?? []),
            'product' => new ProductResource($this->product),
        ];
    }
}