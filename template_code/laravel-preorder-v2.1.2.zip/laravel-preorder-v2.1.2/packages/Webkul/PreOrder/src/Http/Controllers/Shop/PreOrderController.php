<?php

namespace Webkul\PreOrder\Http\Controllers\Shop;

use Illuminate\Support\Facades\Event;
use Illuminate\Support\Str;
use App\Http\Controllers\Controller;
use Webkul\CartRule\Repositories\CartRuleRepository;
use Webkul\Checkout\Facades\Cart;
use Webkul\PreOrder\Repositories\PreOrderItemRepository;
use Webkul\Product\Repositories\ProductRepository;
use Webkul\Sales\Repositories\OrderItemRepository;
use Webkul\Sales\Repositories\OrderRepository;

class PreOrderController extends Controller
{
    /**
     * Create a new controller instance.
     * 
     * @return void
     */
    public function __construct(
        protected CartRuleRepository $cartRuleRepository,
        protected OrderItemRepository $orderItemRepository,
        protected OrderRepository $orderRepository,
        protected PreOrderItemRepository $preOrderItemRepository,
        protected ProductRepository $productRepository,
    ) {
    }

    /**
     * Complete Pre-Order.
     * 
     * @return \Illuminate\Http\Response
     */
    public function complete()
    {
        try {
            $preOrderItem = $this->preOrderItemRepository->findOneByField('token', request()->route('token'))
                ?? $this->preOrderItemRepository->find(request()->input('id'));

            if (! $preOrderItem) {
                return;
            }

            if ($preOrderItem->payment_order_item_id != null) {
                throw new \Exception(trans('pre_order::app.shop.checkout.cart.error.payment-done'));
            }

            $orderItem = $this->orderItemRepository->findOrFail($preOrderItem->order_item_id);

            $orderData = $this->orderRepository->findOrFail($preOrderItem->order_id);

            $cartRuleData = null;

            if ($orderData->applied_cart_rule_ids != null) {
                $cartRuleData = $this->cartRuleRepository->findOrFail($orderData->applied_cart_rule_ids);
            }

            if (! $this->preOrderItemRepository->canBeComplete($orderItem)) {
                session()->flash('error', trans('pre_order::app.shop.customers.account.orders.complete-preorder-error'));
                
                return request()->route('token') ? redirect()->route('shop.home.index') : back();
            }

            $data = [
                'pre_order_payment' => true,
                'order_item_id'     => $preOrderItem->order_item_id,
                'product'           => $orderItem->product_id,
                'quantity'          => $orderItem->qty_ordered,
                'discounted_amount' => $orderItem->discount_amount,
                'is_configurable'   => $orderItem->type == 'configurable',
            ];

            if (isset($cartRuleData->action_type)) {
                $data['discount_type'] = $cartRuleData->action_type;
            }

            if ($orderItem->type == 'configurable') {
                $data['selected_configurable_option'] = $orderItem->child->product_id;

                foreach ($this->productRepository->getSuperAttributes($orderItem->product) as $attribute) {
                    $data['super_attribute'][$attribute['id']] = $orderItem->child->product->{$attribute['code']};
                }
            }

            request()->merge(["order_item_id" => $preOrderItem->order_item_id]);

            Event::dispatch('checkout.cart.add.before', $data['product']);

            Cart::addProduct($data['product'], $data);

            return redirect()->route('shop.checkout.onepage.index');
        } catch (\Exception $e) {
            if (! Str::contains($e->getMessage(), "Unknown column 'price' in 'field list'")) {
                session()->flash('error', trans($e->getMessage()));

                return redirect()->back();
            }

            return redirect()->route('shop.checkout.onepage.index');
        }
    }
}