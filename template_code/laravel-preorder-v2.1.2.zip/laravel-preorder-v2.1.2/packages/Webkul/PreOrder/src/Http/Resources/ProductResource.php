<?php

namespace Webkul\PreOrder\Http\Resources;

use Webkul\Shop\Http\Resources\ProductResource as BaseProductResource;

class ProductResource extends BaseProductResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            ...parent::toArray($request),

            'allow_preorder' => $this->allow_preorder,
            'quantity'       => $this->getTypeInstance()->totalQuantity(),
        ];  
    }
}