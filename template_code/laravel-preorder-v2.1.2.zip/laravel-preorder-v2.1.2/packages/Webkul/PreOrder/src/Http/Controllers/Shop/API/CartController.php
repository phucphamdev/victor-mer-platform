<?php

namespace Webkul\PreOrder\Http\Controllers\Shop\API;

use Illuminate\Http\Resources\Json\JsonResource;
use Webkul\CartRule\Repositories\CartRuleCouponRepository;
use Webkul\Checkout\Facades\Cart;
use Webkul\Customer\Repositories\WishlistRepository;
use Webkul\Product\Repositories\ProductFlatRepository;
use Webkul\Product\Repositories\ProductRepository;
use Webkul\Shop\Http\Controllers\API\CartController as BaseCartController;
use Webkul\Shop\Http\Resources\CartResource;

class CartController extends BaseCartController
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        protected CartRuleCouponRepository $cartRuleCouponRepository,
        protected ProductFlatRepository $productFlatRepository,
        protected ProductRepository $productRepository,
        protected WishlistRepository $wishlistRepository,
    ) {
    }

    /**
     * Cart.
     */
    public function index(): JsonResource
    {
        Cart::collectTotals();

        $response = [
            'data' => ($cart = Cart::getCart()) ? new CartResource($cart) : null
        ];

        foreach ($cart->items ?? [] as $item) {
            $product = $this->productFlatRepository->findOneByField('product_id', $item->product_id);
            
            $item->price = $product->price;
        }

        if (session()->has('info')) {
            $response['message'] = session()->get('info');
        }

        return new JsonResource($response);
    }
}