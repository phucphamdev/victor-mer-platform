<?php

namespace Webkul\PreOrder\Http\Controllers\Shop;

use Illuminate\Http\Resources\Json\JsonResource;
use Webkul\Checkout\Facades\Cart;
use Webkul\Payment\Facades\Payment;
use Webkul\Shipping\Facades\Shipping;
use Webkul\Shop\Http\Controllers\API\OnepageController as BaseOnepageController;
use Webkul\Shop\Http\Requests\CartAddressRequest;

class OnepageController extends BaseOnepageController
{
    /**
     * @var int
     */
    public const ZERO = 0;

    /**
     * Store customer address.
     */
    public function storeAddress(CartAddressRequest $cartAddressRequest): JsonResource
    {
        $params = $cartAddressRequest->all();

        if (
            ! auth()->guard('customer')->check()
            && ! Cart::getCart()->hasGuestCheckoutItems()
        ) {
            return new JsonResource([
                'redirect' => true,
                'data'     => route('shop.customer.session.index'),
            ]);
        }

        if (Cart::hasError()) {
            return new JsonResource([
                'redirect'     => true,
                'redirect_url' => route('shop.checkout.cart.index'),
            ]);
        }

        $cart = Cart::getCart();

        foreach($cart->items as $item) {
            $additionalProperties = $item->additional;

            $isPreOrderPayment = $additionalProperties['pre_order_payment'] ?? self::ZERO;
        }

        Cart::saveAddresses($params);

        Cart::collectTotals();

        $rates = Shipping::collectRates();

        if (isset($rates['shippingMethods']['free'])) {
            $freeShippingMethod = $rates['shippingMethods']['free'];

            if ($isPreOrderPayment) {
                $rates['shippingMethods'] = [];
    
                $rates['shippingMethods']['free'] = $freeShippingMethod;
            }
        }

        if ($cart->haveStockableItems()) {
            if (! $rates = Shipping::collectRates()) {
                return new JsonResource([
                    'redirect'     => true,
                    'redirect_url' => route('shop.checkout.cart.index'),
                ]);
            }

            return new JsonResource([
                'redirect' => false,
                'data'     => $rates,
            ]);
        }

        return new JsonResource([
            'redirect' => false,
            'data'     => Payment::getSupportedPaymentMethods(),
        ]);
    }
}