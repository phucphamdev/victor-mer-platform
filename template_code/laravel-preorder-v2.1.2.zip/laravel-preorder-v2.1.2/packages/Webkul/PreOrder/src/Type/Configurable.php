<?php

namespace Webkul\PreOrder\Type;

use Webkul\Product\Type\Configurable as BaseConfigurable;

class Configurable extends BaseConfigurable
{
    /**
     * Add product. Returns error message if can't prepare product.
     *
     * @param  array  $data
     * @return array|string
     */
    public function prepareForCart($data)
    {
        if (empty($data['selected_configurable_option'])) {
            if ($this->getDefaultVariantId()) {
                $data['selected_configurable_option'] = $this->getDefaultVariantId();
            } else {
                return trans('shop::app.checkout.cart.missing-options');
            }
        }

        $data = $this->getQtyRequest($data);

        $childProduct = $this->productRepository->find($data['selected_configurable_option']);

        if (! $this->product->allow_preorder) {
            if (! $childProduct->haveSufficientQuantity($data['quantity'])) {
                return trans('shop::app.checkout.cart.inventory-warning');
            }
        }

        if (
            $this->product->allow_preorder
            && ! core()->getConfigData('pre_order.settings.general.enable_pre_order')
        ) {
            if (! $this->haveSufficientQuantity($data['quantity'])) {
                return trans('shop::app.checkout.cart.inventory-warning');
            }
        }

        $price = $childProduct->getTypeInstance()->getFinalPrice();

        return [
            [
                'product_id'        => $this->product->id,
                'sku'               => $this->product->sku,
                'name'              => $this->product->name,
                'type'              => $this->product->type,
                'quantity'          => $data['quantity'],
                'price'             => $convertedPrice = core()->convertPrice($price),
                'base_price'        => $price,
                'total'             => $convertedPrice * $data['quantity'],
                'base_total'        => $price * $data['quantity'],
                'weight'            => $childProduct->weight,
                'total_weight'      => $childProduct->weight * $data['quantity'],
                'base_total_weight' => $childProduct->weight * $data['quantity'],
                'allow_preorder'    => $this->product->allow_preorder,
                'additional'        => $this->getAdditionalOptions($data),
            ],
            [
                'parent_id'  => $this->product->id,
                'product_id' => (int) $data['selected_configurable_option'],
                'sku'        => $childProduct->sku,
                'name'       => $childProduct->name,
                'type'       => $childProduct->type,
                'additional' => [
                    'product_id' => (int) $data['selected_configurable_option'],
                    'parent_id'  => $this->product->id,
                ],
            ],
        ];
    }

    /**
     * Return total quantity.
     *
     * @return int
     */
    public function totalQuantity()
    {
        $total = 0;

        foreach ($this->product->variants as $variant) {
            $inventoryIndex = $variant->totalQuantity();

            $total += $inventoryIndex;
        }

        return $total;
    }
}