<?php

namespace Webkul\PreOrder\Type;

use Webkul\Product\Type\Simple as BaseSimpleType;

class Simple extends BaseSimpleType
{
    /**
     * Add product. Returns error message if can't prepare product.
     *
     * @param  array  $data
     * @return array
     */
    public function prepareForCart($data)
    {    
        if (! $this->product->allow_preorder) {
            if (! $this->haveSufficientQuantity($data['quantity'])) {
                return trans('shop::app.checkout.cart.inventory-warning');
            }
        }     

        if (
            $this->product->allow_preorder
            && ! core()->getConfigData('pre_order.settings.general.enable_pre_order')
        ) {
            if (! $this->haveSufficientQuantity($data['quantity'])) {
                return trans('shop::app.checkout.cart.inventory-warning');
            }
        }    

        $price = $this->getFinalPrice();

        $products = [
            [
                'product_id'        => $this->product->id,
                'sku'               => $this->product->sku,
                'quantity'          => $data['quantity'],
                'name'              => $this->product->name,
                'price'             => $convertedPrice = core()->convertPrice($price),
                'base_price'        => $price,
                'total'             => $convertedPrice * $data['quantity'],
                'base_total'        => $price * $data['quantity'],
                'weight'            => $this->product->weight ?? 0,
                'total_weight'      => ($this->product->weight ?? 0) * $data['quantity'],
                'base_total_weight' => ($this->product->weight ?? 0) * $data['quantity'],
                'type'              => $this->product->type,
                'additional'        => $this->getAdditionalOptions($data),
            ],
        ];

        return $products;
    }
}