@php
    $quantity = $product->totalQuantity();

    if ($product->type == 'configurable') {
        foreach ($product->variants as $variant) {
            $quantity = $variant->totalQuantity();
            
            break;
        }
    }
@endphp

@if (
    $product->type == 'simple' 
    && $quantity < 1 
    && $product->allow_preorder
)

    <div class="box-shadow rounded-xl border bg-white p-4 dark:bg-gray-900">
        @if (
            core()->getConfigData('pre_order.settings.general.pre_order_type') == 'partial'
            && core()->getConfigData('pre_order.settings.general.percent')
        )
            <p class="pl-1 text-xl font-semibold text-blue-950">
                @lang('pre_order::app.shop.customers.account.orders.percent-to-pay', ['percent' => core()->getConfigData('pre_order.settings.general.percent')])
            </p>
        @endif
        
        @if (core()->getConfigData('pre_order.settings.general.message') != '')
            <p class="pl-1">
               {{ core()->getConfigData('pre_order.settings.general.message') }}
            </p>
        @endif

        @if (
            $product->preorder_availability 
            && \Carbon\Carbon::parse($product->preorder_availability) > \Carbon\Carbon::now()
        )
            <p class="pl-1">
               @lang('pre_order::app.shop.products.available-on', [
                        'date' => core()->formatDate(\Carbon\Carbon::parse($product->preorder_availability), 'F d, Y'),
                    ])
            </p>
        @endif
    </div>
@elseif (
    $product->type == 'configurable'
    && $quantity < 1 
    && $product->allow_preorder
)
    <div class="box-shadow rounded-lg border bg-white dark:bg-gray-900">
        @if (
            core()->getConfigData('pre_order.settings.general.pre_order_type') == 'partial'
            && core()->getConfigData('pre_order.settings.general.percent')
        )
            <p class="pl-2 text-2xl font-semibold text-blue-950">
                @lang('pre_order::app.shop.customers.account.orders.percent-to-pay', ['percent' => core()->getConfigData('pre_order.settings.general.percent')])
            </p>
        @endif

        @if (core()->getConfigData('pre_order.settings.general.message') != '')
            <p class="pl-2">
                {{ core()->getConfigData('pre_order.settings.general.message') }}
            </p>
        @endif

        @if (
            $product->preorder_availability 
            && \Carbon\Carbon::parse($product->preorder_availability) > \Carbon\Carbon::now()
        )
            <p class="pl-2">
               @lang('pre_order::app.shop.products.available-on', [
                    'date' => core()->formatDate(\Carbon\Carbon::parse($product->preorder_availability), 'F d, Y'),
                ])
            </p>
        @endif
    </div>
@endif