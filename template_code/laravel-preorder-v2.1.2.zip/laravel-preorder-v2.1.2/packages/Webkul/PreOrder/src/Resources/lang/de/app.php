<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Vorbestellung',
        ],

        'catalog' => [
            'title' => 'Vorbestellung zulassen',

            'attributes' => [
                'allow-preorder'       => 'Vorbestellung zulassen',
                'product-availability' => 'Produktverfügbarkeit',
                'product-qty'          => 'Produktmenge',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'Bestandsbenachrichtigungs-E-Mail nicht versendet.',
            'mass-notify-success' => 'Bestandsbenachrichtigungs-E-Mail erfolgreich versendet.',
            'title'               => 'Vorbestellungen',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Zahlungsbestellung: ',
                'preorder-information'         => 'Vorbestellungsinformationen',
                'preorder-payment-information' => 'Vorbestellungs-Zahlungsinformationen',
                'preorder-summary'             => 'Diese Bestellung enthält Vorbestellungsartikel.',
                'reference-order'              => 'Referenzbestellung: ',
                'status'                       => 'Status: ',
                'type'                         => 'Typ: ',
            ],
        ],

        'configuration' => [
            'info'     => 'Vorbestellungsoptionen festlegen.',
            'title'    => 'Vorbestellung',

            'settings' => [
                'info'  => 'Vorbestellungsoptionen festlegen.',
                'title' => 'Einstellungen',
            ],

            'system' => [
                'complete-payment'       => 'Vollständige Zahlung',
                'enable-automatic-mail'  => 'Automatische E-Mail aktivieren',
                'enable-pre-order'       => 'Vorbestellung aktivieren',
                'message'                => 'Nachricht',
                'partial-payment'        => 'Teilzahlung',
                'pre-order-percent-info' => 'Dieser Wert wird verwendet, wenn "Vorbestellungsart" als "Teilzahlung" ausgewählt ist.',
                'pre-order-percent'      => 'Vorbestellungsprozentsatz',
                'pre-order-type'         => 'Vorbestellungsart',
                'preorder'               => 'Vorbestellung',
                'settings'               => 'Einstellungen',
                
                'general' => [
                    'info'   => 'Vorbestellungsart, Vorbestellungsprozentsatz und Nachricht festlegen.',
                    'title'  => 'Allgemein',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'Kanalname',
            'complete-payment' => 'Vollständige Zahlung',
            'completed'        => 'Abgeschlossen',
            'created-at'       => 'Erstellt am',
            'customer-email'   => 'Kunden-E-Mail',
            'customer-name'    => 'Kundenname',
            'email-sent'       => 'E-Mail gesendet',
            'id'               => 'ID',
            'image'            => 'Bild',
            'location'         => 'Ort',
            'no'               => 'Nein',
            'normal-order'     => 'Normale Bestellung',
            'not-applicable'   => 'Nicht anwendbar',
            'notify-customer'  => 'Kunden benachrichtigen',
            'order-id'         => 'Bestell-ID',
            'order-type'       => 'Bestellart',
            'paid-amount'      => 'Bezahlter Betrag',
            'partial-payment'  => 'Teilzahlung',
            'pay-by'           => 'Bezahlt mit',
            'payment-order-id' => 'ID der Zahlungsbestellung',
            'pending'          => 'Ausstehend',
            'pre-order-type'   => 'Vorbestellungsart',
            'preorder'         => 'Vorbestellung',
            'processing'       => 'In Bearbeitung',
            'product-name'     => 'Produktname',
            'remaining-amount' => 'Verbleibender Betrag',
            'status'           => 'Status',
            'yes'              => 'Ja',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Liebe:r :name',
            'info'    => 'Produkt :name ist jetzt auf Lager eingetroffen. <a style="color:#0041FF" href=":link">Klicken Sie hier</a>, um die Vorbestellung abzuschließen.',
            'subject' => 'Benachrichtigung über Produktverfügbarkeit im Lager',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Verfügbar ab:</span> :date',
                    'available-soon-for-preorder'  => 'Demnächst für Vorbestellung verfügbar',
                    'complete-preorder-error'      => 'Vorbestellungszahlung konnte nicht abgeschlossen werden.',
                    'complete-preorder'            => 'Vorbestellung abschließen',
                    'nothing-to-pay'               => 'Für Vorbestellung ist nichts zu bezahlen.',
                    'payment-order'                => 'Zahlungsbestellung',
                    'percent-to-pay'               => ':percent% als Vorbestellung bezahlen.',
                    'preorder-information'         => 'Vorbestellungsinformationen',
                    'preorder-payment-information' => 'Vorbestellungs-Zahlungsinformationen',
                    'preorder-summary'             => 'Diese Bestellung enthält Vorbestellungsartikel.',
                    'preorder'                     => 'Vorbestellung',
                    'reference-order'              => 'Referenzbestellung',
                    'status'                       => 'Status: ',
                    'type'                         => 'Typ: ',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>Verfügbar ab:</span> :date',
            'preorder'     => 'Vorbestellung',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'Zahlung für diese Bestellung wurde bereits abgeschlossen',
                    'preorder-payment'      => 'Vorbestellungszahlung kann nicht mit anderen Produkten hinzugefügt werden.',
                    'product-not-added'     => 'Produkt kann nicht mit Vorbestellungszahlung hinzugefügt werden.',
                    'quantity-error'        => 'Für Vorbestellung angeforderte Menge nicht verfügbar.',
                    'quantity-update-error' => 'Vorbestellungsmenge kann nicht aktualisiert werden.',
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'Kunden benachrichtigen',
        'pre-order'       => 'Vorbestellung',
    ],
];