<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Ön Sipariş',
        ],

        'catalog' => [
            'title' => 'Ön Siparişe İzin Ver',

            'attributes' => [
                'allow-preorder'       => 'Ön Siparişe İzin Ver',
                'product-availability' => 'Ürün Bulunabilirliği',
                'product-qty'          => 'Ürün Miktarı',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'Stok bildirim e-postası gönderilemedi.',
            'mass-notify-success' => 'Stok bildirim e-postası başarıyla gönderildi.',
            'title'               => 'Ön Siparişler',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Ödeme Siparişi: ',
                'preorder-information'         => 'Ön Sipariş Bilgisi',
                'preorder-payment-information' => 'Ön Sipariş Ödeme Bilgisi',
                'preorder-summary'             => 'Bu sipariş ön sipariş içermektedir.',
                'reference-order'              => 'Referans Sipariş: ',
                'status'                       => 'Durum: ',
                'type'                         => 'Tür: ',
            ],
        ],

        'configuration' => [
            'info'     => 'Ön sipariş seçeneklerini ayarlayın.',
            'title'    => 'Ön Sipariş',

            'settings' => [
                'info'  => 'Ön sipariş seçeneklerini ayarlayın.',
                'title' => 'Ayarlar',
            ],

            'system' => [
                'complete-payment'       => 'Tam Ödeme',
                'enable-automatic-mail'  => 'Otomatik E-postayı Etkinleştir',
                'enable-pre-order'       => 'Ön Siparişi Etkinleştir',
                'message'                => 'Mesaj',
                'partial-payment'        => 'Kısmi Ödeme',
                'pre-order-percent-info' => 'Bu değer, "Ön Sipariş Türü" "Kısmi Ödeme" olarak seçildiğinde kullanılacaktır.',
                'pre-order-percent'      => 'Ön Sipariş Yüzdesi',
                'pre-order-type'         => 'Ön Sipariş Türü',
                'preorder'               => 'Ön Sipariş',
                'settings'               => 'Ayarlar',
                
                'general' => [
                    'info'   => 'Ön sipariş türünü, ön sipariş yüzdesini ve mesajı ayarlayın.',
                    'title'  => 'Genel',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'Kanal Adı',
            'complete-payment' => 'Tam Ödeme',
            'completed'        => 'Tamamlandı',
            'created-at'       => 'Oluşturulma Tarihi',
            'customer-email'   => 'Müşteri E-postası',
            'customer-name'    => 'Müşteri Adı',
            'email-sent'       => 'E-posta Gönderildi',
            'id'               => 'ID',
            'image'            => 'Görüntü',
            'location'         => 'Konum',
            'no'               => 'Hayır',
            'normal-order'     => 'Normal Sipariş',
            'not-applicable'   => 'Uygulanamaz',
            'notify-customer'  => 'Müşteriyi Bildir',
            'order-id'         => 'Sipariş ID',
            'order-type'       => 'Sipariş Türü',
            'paid-amount'      => 'Ödenen Miktar',
            'partial-payment'  => 'Kısmi Ödeme',
            'pay-by'           => 'Ödeme Yöntemi',
            'payment-order-id' => 'Ödeme Sipariş ID',
            'pending'          => 'Beklemede',
            'pre-order-type'   => 'Ön Sipariş Türü',
            'preorder'         => 'Ön Sipariş',
            'processing'       => 'İşleniyor',
            'product-name'     => 'Ürün Adı',
            'remaining-amount' => 'Kalan Miktar',
            'status'           => 'Durum',
            'yes'              => 'Evet',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Sayın :name',
            'info'    => ':name ürünü şu anda stokta mevcut. Ön siparişi tamamlamak için <a style="color:#0041FF" href=":link">buraya tıklayın</a>.',
            'subject' => 'Stokta Ürün Bildirimi',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Şurada Mevcut:</span> :date',
                    'available-soon-for-preorder'  => 'Ön sipariş için yakında mevcut',
                    'complete-preorder-error'      => 'Ön sipariş ödemesi tamamlanamadı.',
                    'complete-preorder'            => 'Ön Siparişi Tamamla',
                    'nothing-to-pay'               => 'Ön sipariş için ödenecek bir şey yok.',
                    'payment-order'                => 'Ödeme Siparişi',
                    'percent-to-pay'               => ':percent% olarak Ön Sipariş Öde',
                    'preorder-information'         => 'Ön Sipariş Bilgisi',
                    'preorder-payment-information' => 'Ön Sipariş Ödeme Bilgisi',
                    'preorder-summary'             => 'Bu sipariş ön sipariş ürünleri içeriyor.',
                    'preorder'                     => 'Ön Sipariş',
                    'reference-order'              => 'Referans Sipariş',
                    'status'                       => 'Durum: ',
                    'type'                         => 'Tür: ',
                ],
            ],

            'products' => [
                'available-on' => '<span>Şurada Mevcut:</span> :date',
                'preorder'     => 'Ön Sipariş',
            ],

            'checkout' => [
                'cart' => [
                    'error' => [
                        'payment-done'          => 'Bu sipariş için ödeme yapıldı',
                        'preorder-payment'      => 'Ön sipariş ödemesi başka ürünle eklenemez.',
                        'product-not-added'     => 'Ürün ön sipariş ödemesiyle eklenemez.',
                        'quantity-error'        => 'Ön sipariş için istenen miktar mevcut değil.',
                        'quantity-update-error' => 'Ön sipariş miktarı güncellenemiyor.',
                    ],
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'Müşteriyi Bildir',
        'pre-order'       => 'Ön Sipariş',
    ],
];