<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'පෙර ලැබීම',
        ],

        'catalog' => [
            'title' => 'පෙර ලබා දැමීම විධාන',

            'attributes' => [
                'allow-preorder'       => 'පෙර ලබා දැමීම ඉඩ දෙන්න',
                'product-availability' => 'නිෂ්පාදන ලබා ගැනීම',
                'product-qty'          => 'නිෂ්පාදන ප්‍රමාණය',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'නාගරිකයෙකුට නිෂ්පාදන ඇමතුම් ඊමේල් යවන ලදි නොවේ.',
            'mass-notify-success' => 'නාගරිකයෙකුට නිෂ්පාදන ඇමතුම් ඊමේල් එසේ හිමිකමින් යවන ලදි.',
            'title'               => 'පෙර ලබා දැමීම්',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'ගෙවීම් ඇණවුම: ',
                'preorder-information'         => 'පෙර ලබා දැමීමේ තොරතුරු',
                'preorder-payment-information' => 'පෙර ගෙවීම් තොරතුරු',
                'preorder-summary'             => 'මෙම ඇනවුම පෙර ලබා දැමීමේ අයිතිකරුගේ ඇණවුමට අදාළ අයිතිකරුගේ.',
                'reference-order'              => 'සම්මන්ත ඇණවුම: ',
                'status'                       => 'ස්ථානය: ',
                'type'                         => 'වර්ගය: ',
            ],
        ],

        'configuration' => [
            'info'     => 'පෙර ලබා දැමීමේ විකල්ප සකසන්න.',
            'title'    => 'පෙර ලබා දැමීම',

            'settings' => [
                'info'  => 'පෙර ලබා දැමීමේ සැකසුම් සකසන්න.',
                'title' => 'සැකසුම්',
            ],

            'system' => [
                'complete-payment'       => 'සම්පූර්ණ ගෙවීම',
                'enable-automatic-mail'  => 'ස්වයංක්රීය තැපැල් ක්‍රමය සක්‍රිය කරන්න',
                'enable-pre-order'       => 'පෙර ලබා දැමීම සක්‍රිය කරන්න',
                'message'                => 'සන්නිවේදනය',
                'partial-payment'        => 'අඩු ගෙවීම',
                'pre-order-percent-info' => 'මෙය "පෙර ලබා දැමීමේ වර්ගය" වර්ගය වෙත තෝරා ඇති විට භාවිතා කරනු ලැබේ.',
                'pre-order-percent'      => 'පෙර ලබා දැමීම් ප්‍රතිශතය',
                'pre-order-type'         => 'පෙර ලබා දැමීම් වර්ගය',
                'preorder'               => 'පෙර ලබා දැමීම',
                'settings'               => 'සැකසුම්',
                
                'general' => [
                    'info'   => 'පෙර ලබා දැමීමේ වර්ගය, පෙර ලබා දැමීම් ප්‍රතිශත සහ පණිවුඩය සකසන්න.',
                    'title'  => 'සාමාන්‍ය',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'සබැඳිය නම',
            'complete-payment' => 'සම්පූර්ණ ගෙවීම',
            'completed'        => 'සම්පූර්ණ විය',
            'created-at'       => 'තනන්නා විය',
            'customer-email'   => 'පාරිභෝගිකයා ඊමේල්',
            'customer-name'    => 'පාරිභෝගිකයා නම',
            'email-sent'       => 'ඊමේල් යවා ඇත',
            'id'               => 'අංකය',
            'image'            => 'පින්තූරය',
            'location'         => 'ස්ථානය',
            'no'               => 'නෑ',
            'normal-order'     => 'සාමාන්‍ය ඇණවුම',
            'not-applicable'   => 'අදාළ නොවේ',
            'notify-customer'  => 'පාරිභෝගිකයට දැනුම් දරන්න',
            'order-id'         => 'ඇණවුම අංකය',
            'order-type'       => 'ඇණවුම් වර්ගය',
            'paid-amount'      => 'ගෙවූ මුදල',
            'partial-payment'  => 'අඩු ගෙවීම',
            'pay-by'           => 'ගෙවූ විය',
            'payment-order-id' => 'ගෙවූ ඇණවුම අංකය',
            'pending'          => 'අර්ථ දැක්වීමට',
            'pre-order-type'   => 'අරුත පෙළ වර්ගය',
            'preorder'         => 'අරුත පෙළ',
            'processing'       => 'ප්‍රාද්දී වෙමින්',
            'product-name'     => 'නිෂ්පාදන නම',
            'remaining-amount' => 'ඉතිරි මුදල',
            'status'           => 'තත්ත්වය',
            'yes'              => 'ඔව්',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'ස්තුතියි :name',
            'info'    => 'නිෂ්පාදන :name දැක්වීම දැන් ගන්නා ලදි. <a style="color:#0041FF" href=":link">මතක තබන්න</a>, පෙර ලබා දැමීම කිරීමට.',
            'subject' => 'නිෂ්පාදන ප්‍රතිඵල දැක්වීම',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>ලබා දැමීම වලින්:</span> :date',
                    'available-soon-for-preorder'  => 'පෙර ලබා දැමීම සඳහා ඉල්ලුම් වෙත',
                    'complete-preorder-error'      => 'පෙර ලබා දැමීමේ ගෙවීම සම්පුර්ණ නොවිය.',
                    'complete-preorder'            => 'පෙර ලබා දැමීම අවසානයක්',
                    'nothing-to-pay'               => 'පෙර ලබා දැමීම සඳහා කිසිදු ගෙවිය යුතු නොහැක.',
                    'payment-order'                => 'ගෙවීම් ඇණවුම',
                    'percent-to-pay'               => 'පෙර ලබා දැමීමට :percent% ගෙවිය යුතුය.',
                    'preorder-information'         => 'පෙර ලබා දැමීමේ තොරතුරු',
                    'preorder-payment-information' => 'පෙර ගෙවීම් තොරතුරු',
                    'preorder-summary'             => 'මෙම ඇනවුම පෙර ලබා දැමීම අයිතිකරුගේ ඇණවුමට අදාළ අයිතිකරුගේ.',
                    'preorder'                     => 'පෙර ලබා දැමීම',
                    'reference-order'              => 'සම්මන්ත ඇණවුම',
                    'status'                       => 'ස්ථානය: ',
                    'type'                         => 'වර්ගය: ',
                ],
            ],

            'products' => [
                'available-on' => '<span>ලබා දැමීම වලින්:</span> :date',
                'preorder'     => 'පෙර ලබා දැමීම',
            ],

            'checkout' => [
                'cart' => [
                    'error' => [
                        'payment-done'          => 'මෙම ඇණවුම සම්පූර්ණ කර ඇත.',
                        'preorder-payment'      => 'පෙර ලබා දැමීමේ ගෙවීම වෙනස් කිරීම් සමඟ අයෙකු නොවේ.',
                        'product-not-added'     => 'පෙර ලබා දැමීම ගෙවිය හැකි නොසිටි නම් නොවේ.',
                        'quantity-error'        => 'අවශ්‍ය වෛද්‍යවරයක් සඳහා ඉල්ලීම ලබා දී ඇත.',
                        'quantity-update-error' => 'පෙර ලබා දැමීමේ ප්‍රමාණය යළි වෙනස් කිරීම් නොවේ.',
                    ],
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'පාරිභෝගිකයට දැනුම් දරන්න',
        'pre-order'       => 'පෙර ලැබීම',
    ],
];