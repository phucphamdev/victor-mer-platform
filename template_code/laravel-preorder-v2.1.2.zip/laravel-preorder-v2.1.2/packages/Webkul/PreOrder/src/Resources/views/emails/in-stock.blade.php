@component('shop::emails.layout')
    <div style="padding: 30px;">
        <div style="font-size: 20px;color: #242424;line-height: 30px;margin-bottom: 34px;">
            <p style="font-size: 16px;color: #5E5E5E;line-height: 24px;">
               @lang('pre_order::app.mail.in-stock.dear', ['name' => $item->order->customer_full_name]),
            </p>

            <p style="font-size: 16px;color: #5E5E5E;line-height: 24px;">
                {!!
                    trans('pre_order::app.mail.in-stock.info', [
                        'name' => '<a style="color:#0041FF" href="' . route('shop.product_or_category.index', $item->order_item->product->url_key) . '">' . $item->order_item->product->name . '</a>',
                        'link' => $item->order->is_guest ? route('pre_order.shop.pre_order.complete', ['token' => $item->token]) : route('shop.customers.account.orders.view', ['id' => $item->order_id])
                    ])
                !!}
            </p>
        </div>
    </div>
@endcomponent