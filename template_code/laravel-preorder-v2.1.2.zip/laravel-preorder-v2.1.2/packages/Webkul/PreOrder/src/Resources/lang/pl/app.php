<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Przedpremiera',
        ],

        'catalog' => [
            'title' => 'Zezwól na przedpremierę',

            'attributes' => [
                'allow-preorder'       => 'Zezwól na przedpremierę',
                'product-availability' => 'Dostępność produktu',
                'product-qty'          => 'Ilość produktów',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'E-mail z powiadomieniem o stanie magazynu nie został wysłany.',
            'mass-notify-success' => 'E-mail z powiadomieniem o stanie magazynu został pomyślnie wysłany.',
            'title'               => 'Przedpremiery',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Zamówienie płatności: ',
                'preorder-information'         => 'Informacje o przedpremierze',
                'preorder-payment-information' => 'Informacje o płatności przedpremierowej',
                'preorder-summary'             => 'Ta zamówienie zawiera przedpremierowe przedmioty.',
                'reference-order'              => 'Zamówienie referencyjne: ',
                'status'                       => 'Status: ',
                'type'                         => 'Typ: ',
            ],
        ],

        'configuration'=> [
            'info'     => 'Ustaw opcje przedpremierowe.',
            'title'    => 'Przedpremiera',

            'settings' => [
                'info'  => 'Ustaw opcje przedpremierowe.',
                'title' => 'Ustawienia',
            ],

            'system' => [
                'complete-payment'       => 'Płatność pełna',
                'enable-automatic-mail'  => 'Włącz automatyczną pocztę',
                'enable-pre-order'       => 'Włącz przedpremierę',
                'message'                => 'Wiadomość',
                'partial-payment'        => 'Częściowa płatność',
                'pre-order-percent-info' => 'Ta wartość będzie używana, jeśli "Typ przedpremiery" jest wybrany jako "Częściowa płatność".',
                'pre-order-percent'      => 'Procent przedpremierowy',
                'pre-order-type'         => 'Typ przedpremiery',
                'preorder'               => 'Przedpremiera',
                'settings'               => 'Ustawienia',
                
                'general' => [
                    'info'   => 'Ustaw typ przedpremierowy, procent przedpremierowy i wiadomość.',
                    'title'  => 'Ogólne',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'Nazwa Kanału',
            'complete-payment' => 'Pełna Płatność',
            'completed'        => 'Zakończone',
            'created-at'       => 'Utworzono',
            'customer-email'   => 'E-mail Klienta',
            'customer-name'    => 'Nazwa Klienta',
            'email-sent'       => 'E-mail Wysłany',
            'id'               => 'ID',
            'image'            => 'Obraz',
            'location'         => 'Lokalizacja',
            'no'               => 'Nie',
            'normal-order'     => 'Zwykłe Zamówienie',
            'not-applicable'   => 'Nie Dotyczy',
            'notify-customer'  => 'Powiadom Klienta',
            'order-id'         => 'ID Zamówienia',
            'order-type'       => 'Typ Zamówienia',
            'paid-amount'      => 'Zapłacona Kwota',
            'partial-payment'  => 'Częściowa Płatność',
            'pay-by'           => 'Płatność przez',
            'payment-order-id' => 'ID Zamówienia Płatności',
            'pending'          => 'Oczekujące',
            'pre-order-type'   => 'Typ Przed zamówieniem',
            'preorder'         => 'Przed zamówieniem',
            'processing'       => 'W trakcie realizacji',
            'product-name'     => 'Nazwa Produktu',
            'remaining-amount' => 'Pozostała Kwota',
            'status'           => 'Status',
            'yes'              => 'Tak',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Szanowny/a :name',
            'info'    => 'Produkt :name jest teraz dostępny. <a style="color:#0041FF" href=":link">Kliknij tutaj</a>, aby zakończyć przedpremierę.',
            'subject' => 'Powiadomienie o dostępności produktu',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Dostępny od:</span> :date',
                    'available-soon-for-preorder'  => 'Wkrótce dostępny do przedpremierowego zakupu',
                    'complete-preorder-error'      => 'Płatność przedpremierowa nie została ukończona.',
                    'complete-preorder'            => 'Zakończ przedpremierę',
                    'nothing-to-pay'               => 'Nic do zapłacenia za przedpremierę.',
                    'payment-order'                => 'Zamówienie płatności',
                    'percent-to-pay'               => 'Zapłać :percent% jako przedpremiera.',
                    'preorder-information'         => 'Informacje o przedpremierze',
                    'preorder-payment-information' => 'Informacje o płatności przedpremierowej',
                    'preorder-summary'             => 'To zamówienie zawiera przedpremierowe przedmioty.',
                    'preorder'                     => 'Przedpremiera',
                    'reference-order'              => 'Zamówienie referencyjne',
                    'status'                       => 'Status: ',
                    'type'                         => 'Typ: ',
                ],
            ],

            'products' => [
                'available-on' => '<span>Dostępny od:</span> :date',
                'preorder'     => 'Przedpremiera',
            ],

            'checkout' => [
                'cart' => [
                    'error' => [
                        'payment-done'          => 'Płatność została już dokonana dla tego zamówienia',
                        'preorder-payment'      => 'Płatność przedpremierowa nie może być dodana do innych produktów.',
                        'product-not-added'     => 'Produkt nie może być dodany z płatnością przedpremierową.',
                        'quantity-error'        => 'Żądana ilość nie jest dostępna dla przedpremierowego zakupu.',
                        'quantity-update-error' => 'Ilość płatności przedpremierowej nie może być zaktualizowana.',
                    ],
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'Powiadom Klienta',
        'pre-order'       => 'Przedpremiera',
    ],
];