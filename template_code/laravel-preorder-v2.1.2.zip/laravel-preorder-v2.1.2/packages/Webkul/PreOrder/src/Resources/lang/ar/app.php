<?php

return [
    'admin' => [
        'layouts' => [
            'preorder' => 'الطلب المسبق',
        ],

        'catalog' => [
            'title' => 'السماح بالطلب المسبق',

            'attributes' => [
                'allow-preorder'       => 'السماح بالطلب المسبق',
                'product-availability' => 'توافر المنتج',
                'product-qty'          => 'كمية المنتج',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'فشل إرسال إشعار الأسهم بالبريد الإلكتروني.',
            'mass-notify-success' => 'تم إرسال إشعار الأسهم بالبريد الإلكتروني بنجاح.',
            'title'               => 'الطلبات المسبقة',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'طلب الدفع: ',
                'preorder-information'         => 'معلومات الطلب المسبق',
                'preorder-payment-information' => 'معلومات دفع الطلب المسبق',
                'preorder-summary'             => 'يحتوي هذا الطلب على عناصر الطلب المسبق.',
                'reference-order'              => 'الطلب المرجعي: ',
                'status'                       => 'الحالة: ',
                'type'                         => 'النوع: ',
            ],
        ],

        'configuration' => [
            'info'     => 'تعيين خيارات الطلب المسبق.',
            'title'    => 'الطلب المسبق',

            'settings' => [
                'info'  => 'تعيين خيارات الطلب المسبق.',
                'title' => 'الإعدادات',
            ],

            'system' => [
                'complete-payment'       => 'الدفع الكامل',
                'enable-automatic-mail'  => 'تمكين البريد الآلي',
                'enable-pre-order'       => 'تمكين الطلب المسبق',
                'message'                => 'الرسالة',
                'partial-payment'        => 'الدفع الجزئي',
                'pre-order-percent-info' => 'سيتم استخدام هذه القيمة إذا تم اختيار "نوع الطلب المسبق" كـ "الدفع الجزئي".',
                'pre-order-percent'      => 'نسبة الطلب المسبق',
                'pre-order-type'         => 'نوع الطلب المسبق',
                'preorder'               => 'الطلب المسبق',
                'settings'               => 'الإعدادات',
                
                'general' => [
                    'info'   => 'تعيين نوع الطلب المسبق ونسبة الطلب المسبق والرسالة.',
                    'title'  => 'عام',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'اسم القناة',
            'complete-payment' => 'الدفع الكامل',
            'completed'        => 'مكتمل',
            'created-at'       => 'تم الإنشاء في',
            'customer-email'   => 'بريد العميل الإلكتروني',
            'customer-name'    => 'اسم العميل',
            'email-sent'       => 'تم إرسال البريد الإلكتروني',
            'id'               => 'المعرف',
            'image'            => 'الصورة',
            'location'         => 'الموقع',
            'no'               => 'لا',
            'normal-order'     => 'الطلب العادي',
            'not-applicable'   => 'غير قابل للتطبيق',
            'notify-customer'  => 'إعلام العميل',
            'order-id'         => 'رقم الطلب',
            'order-type'       => 'نوع الطلب',
            'paid-amount'      => 'المبلغ المدفوع',
            'partial-payment'  => 'الدفع الجزئي',
            'pay-by'           => 'الدفع عن طريق',
            'payment-order-id' => 'رقم أمر الدفع',
            'pending'          => 'قيد الانتظار',
            'pre-order-type'   => 'نوع الطلب المسبق',
            'preorder'         => 'الطلب المسبق',
            'processing'       => 'قيد المعالجة',
            'product-name'     => 'اسم المنتج',
            'remaining-amount' => 'المبلغ المتبقي',
            'status'           => 'الحالة',
            'yes'              => 'نعم',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'عزيزي :name',
            'info'    => 'تم وصول المنتج :name إلى المخزون الآن. <a style="color:#0041FF" href=":link">انقر هنا</a> لاستكمال الطلب المسبق.',
            'subject' => 'إشعار بتوفر المنتج',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>متاح في:</span> :date',
                    'available-soon-for-preorder'  => 'متوفر قريبًا للطلب المسبق',
                    'complete-preorder-error'      => 'لم يتم اكتمال دفع الطلب المسبق.',
                    'complete-preorder'            => 'اكتمال الطلب المسبق',
                    'nothing-to-pay'               => 'لا شيء للدفع للطلب المسبق.',
                    'payment-order'                => 'طلب الدفع',
                    'percent-to-pay'               => 'ادفع :percent% كطلب مسبق.',
                    'preorder-information'         => 'معلومات الطلب المسبق',
                    'preorder-payment-information' => 'معلومات دفع الطلب المسبق',
                    'preorder-summary'             => 'يحتوي هذا الطلب على عناصر الطلب المسبق.',
                    'preorder'                     => 'طلب مسبق',
                    'reference-order'              => 'الطلب المرجعي',
                    'status'                       => 'الحالة: ',
                    'type'                         => 'النوع: ',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>متاح في:</span> :date',
            'preorder'     => 'طلب مسبق',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'تم الدفع لهذا الطلب بالفعل',
                    'preorder-payment'      => 'لا يمكن إضافة دفع الطلب المسبق مع منتج آخر.',
                    'product-not-added'     => 'لا يمكن إضافة المنتج مع دفع الطلب المسبق.',
                    'quantity-error'        => 'الكمية المطلوبة غير متوفرة للطلب المسبق.',
                    'quantity-update-error' => 'لا يمكن تحديث كمية دفع الطلب المسبق.',
                ],
            ],
        ],
    ],

    'acl' => [
       'notify-customer' => 'إعلام العميل',
       'pre-order'       => 'الطلب المسبق',
    ],
];