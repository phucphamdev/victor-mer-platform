<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Pré-venda',
        ],

        'catalog' => [
            'title' => 'Permitir Pré-venda',

            'attributes' => [
                'allow-preorder'       => 'Permitir Pré-venda',
                'product-availability' => 'Disponibilidade do Produto',
                'product-qty'          => 'Quantidade do Produto',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'E-mail de notificação de estoque não enviado.',
            'mass-notify-success' => 'E-mail de notificação de estoque enviado com sucesso.',
            'title'               => 'Pré-vendas',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Pedido de Pagamento: ',
                'preorder-information'         => 'Informações da Pré-venda',
                'preorder-payment-information' => 'Informações de Pagamento da Pré-venda',
                'preorder-summary'             => 'Este pedido contém itens em pré-venda.',
                'reference-order'              => 'Pedido de Referência: ',
                'status'                       => 'Status: ',
                'type'                         => 'Tipo: ',
            ],
        ],

        'configuration' => [
            'info'     => 'Defina as opções de pré-venda.',
            'title'    => 'Pré-venda',

            'settings' => [
                'info'  => 'Defina as opções de pré-venda.',
                'title' => 'Configurações',
            ],

            'system' => [
                'complete-payment'       => 'Pagamento Completo',
                'enable-automatic-mail'  => 'Ativar E-mail Automático',
                'enable-pre-order'       => 'Ativar Pré-venda',
                'message'                => 'Mensagem',
                'partial-payment'        => 'Pagamento Parcial',
                'pre-order-percent-info' => 'Este valor será utilizado se o "Tipo de Pré-venda" for selecionado como "Pagamento Parcial".',
                'pre-order-percent'      => 'Percentual de Pré-venda',
                'pre-order-type'         => 'Tipo de Pré-venda',
                'preorder'               => 'Pré-venda',
                'settings'               => 'Configurações',
                
                'general' => [
                    'info'   => 'Defina o tipo de pré-venda, percentual de pré-venda e mensagem.',
                    'title'  => 'Geral',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'Nome do Canal',
            'complete-payment' => 'Pagamento Completo',
            'completed'        => 'Completo',
            'created-at'       => 'Criado em',
            'customer-email'   => 'E-mail do Cliente',
            'customer-name'    => 'Nome do Cliente',
            'email-sent'       => 'E-mail Enviado',
            'id'               => 'ID',
            'image'            => 'Imagem',
            'location'         => 'Localização',
            'no'               => 'Não',
            'normal-order'     => 'Pedido Normal',
            'not-applicable'   => 'Não Aplicável',
            'notify-customer'  => 'Notificar Cliente',
            'order-id'         => 'ID do Pedido',
            'order-type'       => 'Tipo de Pedido',
            'paid-amount'      => 'Valor Pago',
            'partial-payment'  => 'Pagamento Parcial',
            'pay-by'           => 'Forma de Pagamento',
            'payment-order-id' => 'ID do Pedido de Pagamento',
            'pending'          => 'Pendente',
            'pre-order-type'   => 'Tipo de Pré-venda',
            'preorder'         => 'Pré-venda',
            'processing'       => 'Processando',
            'product-name'     => 'Nome do Produto',
            'remaining-amount' => 'Valor Restante',
            'status'           => 'Status',
            'yes'              => 'Sim',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Prezado/a :name',
            'info'    => 'O produto :name agora está em estoque. <a style="color:#0041FF" href=":link">Clique aqui</a> para concluir a pré-venda.',
            'subject' => 'Notificação de Produto em Estoque',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Disponível Em:</span> :date',
                    'available-soon-for-preorder'  => 'Disponível em breve para Pré-venda',
                    'complete-preorder-error'      => 'Pagamento da Pré-venda não concluído.',
                    'complete-preorder'            => 'Concluir Pré-venda',
                    'nothing-to-pay'               => 'Nada a pagar pela Pré-venda.',
                    'payment-order'                => 'Pedido de Pagamento',
                    'percent-to-pay'               => 'Pagar :percent% como Pré-venda.',
                    'preorder-information'         => 'Informações da Pré-venda',
                    'preorder-payment-information' => 'Informações de Pagamento da Pré-venda',
                    'preorder-summary'             => 'Este pedido contém itens em pré-venda.',
                    'preorder'                     => 'Pré-venda',
                    'reference-order'              => 'Pedido de Referência',
                    'status'                       => 'Status: ',
                    'type'                         => 'Tipo: ',
                ],
            ],

            'products' => [
                'available-on' => '<span>Disponível Em:</span> :date',
                'preorder'     => 'Pré-venda',
            ],

            'checkout' => [
                'cart' => [
                    'error' => [
                        'payment-done'          => 'O pagamento já foi feito para este pedido',
                        'preorder-payment'      => 'O pagamento de pré-venda não pode ser adicionado com outro produto.',
                        'product-not-added'     => 'O produto não pode ser adicionado com pagamento de pré-venda.',
                        'quantity-error'        => 'Quantidade solicitada não disponível para pré-venda.',
                        'quantity-update-error' => 'A quantidade de pagamento de pré-venda não pode ser atualizada.',
                    ],
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'Notificar Cliente',
        'pre-order'       => 'Pré-venda',
    ],
];