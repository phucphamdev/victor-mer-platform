<x-admin::layouts>
    <!-- Page Title -->
    <x-slot:title>
        @lang('pre_order::app.admin.pre-orders.title')
    </x-slot>

    <div class="flex items-center justify-between gap-3 max-sm:flex-wrap">
        <p class="text-xl font-bold text-gray-800 dark:text-white">
            @lang('pre_order::app.admin.pre-orders.title')
        </p>
      
        <div class="flex items-center gap-x-1.5">
            <!-- Export Modal -->
            <x-admin::datagrid.export src="{{ route('admin.pre_order.pre_orders.index') }}" />
        </div>
    </div>
    
    {!! view_render_event('bagisto.admin.pre_order.list.before') !!}
    
    <x-admin::datagrid :src="route('admin.pre_order.pre_orders.index')" :isMultiRow="true" />

    {!! view_render_event('bagisto.admin.pre_order.list.after') !!}
</x-admin::layouts>