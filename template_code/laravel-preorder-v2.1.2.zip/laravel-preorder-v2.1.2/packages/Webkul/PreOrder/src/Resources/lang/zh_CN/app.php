<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => '预购',
        ],

        'catalog' => [
            'title' => '允许预购',

            'attributes' => [
                'allow-preorder'       => '允许预购',
                'product-availability' => '产品可用性',
                'product-qty'          => '产品数量',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => '库存通知邮件发送失败。',
            'mass-notify-success' => '库存通知邮件发送成功。',
            'title'               => '预购订单',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => '付款订单：',
                'preorder-information'         => '预购信息',
                'preorder-payment-information' => '预购付款信息',
                'preorder-summary'             => '此订单包含预购商品。',
                'reference-order'              => '参考订单：',
                'status'                       => '状态：',
                'type'                         => '类型：',
            ],
        ],

        'configuration' => [
            'info'     => '设置预购选项。',
            'title'    => '预购',

            'settings' => [
                'info'  => '设置预购选项。',
                'title' => '设置',
            ],

            'system' => [
                'complete-payment'       => '完全付款',
                'enable-automatic-mail'  => '启用自动邮件',
                'enable-pre-order'       => '启用预购',
                'message'                => '消息',
                'partial-payment'        => '部分付款',
                'pre-order-percent-info' => '如果选择“部分付款”作为“预购类型”，则将使用此值。',
                'pre-order-percent'      => '预购百分比',
                'pre-order-type'         => '预购类型',
                'preorder'               => '预购',
                'settings'               => '设置',
                
                'general' => [
                    'info'   => '设置预购类型、预购百分比和消息。',
                    'title'  => '常规',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => '默认',
            'complete-payment' => '完全付款',
            'completed'        => '已完成',
            'created-at'       => '创建时间',
            'customer-email'   => '客户电子邮件',
            'customer-name'    => '客户姓名',
            'email-sent'       => '邮件已发送',
            'id'               => 'ID',
            'image'            => '图像',
            'location'         => '位置',
            'no'               => '否',
            'normal-order'     => '正常订单',
            'not-applicable'   => '不适用',
            'notify-customer'  => '通知客户',
            'order-id'         => '订单ID',
            'order-type'       => '订单类型',
            'paid-amount'      => '已付金额',
            'partial-payment'  => '部分付款',
            'pay-by'           => '支付方式',
            'payment-order-id' => '付款订单ID',
            'pending'          => '待处理',
            'pre-order-type'   => '预购类型',
            'preorder'         => '预购',
            'processing'       => '处理中',
            'product-name'     => '产品名称',
            'remaining-amount' => '剩余金额',
            'status'           => '状态',
            'yes'              => '是',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => '亲爱的:name',
            'info'    => ':name 商品现在有货了。点击<a style="color:#0041FF" href=":link">此处</a>完成预购。',
            'subject' => '商品现货通知',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>可用日期：</span> :date',
                    'available-soon-for-preorder'  => '即将供预购',
                    'complete-preorder-error'      => '预购付款未完成。',
                    'complete-preorder'            => '完成预购',
                    'nothing-to-pay'               => '预购无需支付任何费用。',
                    'payment-order'                => '付款订单',
                    'percent-to-pay'               => '支付 :percent% 作为预购。',
                    'preorder-information'         => '预购信息',
                    'preorder-payment-information' => '预购付款信息',
                    'preorder-summary'             => '此订单包含预购商品。',
                    'preorder'                     => '预购',
                    'reference-order'              => '参考订单',
                    'status'                       => '状态：',
                    'type'                         => '类型：',
                ],
            ],

            'products' => [
                'available-on' => '<span>可用日期：</span> :date',
                'preorder'     => '预购',
            ],

            'checkout' => [
                'cart' => [
                    'error' => [
                        'payment-done'          => '此订单已完成支付',
                        'preorder-payment'      => '预购付款无法与其他产品一起添加。',
                        'product-not-added'     => '产品无法与预购付款一起添加。',
                        'quantity-error'        => '预购所需数量不可用。',
                        'quantity-update-error' => '无法更新预购付款数量。',
                    ],
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => '通知客户',
        'pre-order'       => '预购',
    ],
];