<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Предзаказ',
        ],

        'catalog' => [
            'title' => 'Разрешить предзаказ',

            'attributes' => [
                'allow-preorder'       => 'Разрешить предзаказ',
                'product-availability' => 'Доступность продукта',
                'product-qty'          => 'Количество продукта',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'Электронное письмо с уведомлением о наличии товара не отправлено.',
            'mass-notify-success' => 'Электронное письмо с уведомлением о наличии товара успешно отправлено.',
            'title'               => 'Предзаказы',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Заказ оплаты: ',
                'preorder-information'         => 'Информация о предзаказе',
                'preorder-payment-information' => 'Информация о предварительной оплате',
                'preorder-summary'             => 'Этот заказ содержит товары для предзаказа.',
                'reference-order'              => 'Ссылка на заказ: ',
                'status'                       => 'Статус: ',
                'type'                         => 'Тип: ',
            ],
        ],

        'configuration' => [
            'info'     => 'Настройте параметры предзаказа.',
            'title'    => 'Предзаказ',

            'settings' => [
                'info'  => 'Настройте параметры предзаказа.',
                'title' => 'Настройки',
            ],

            'system' => [
                'complete-payment'       => 'Полная оплата',
                'enable-automatic-mail'  => 'Включить автоматическую почту',
                'enable-pre-order'       => 'Включить предзаказ',
                'message'                => 'Сообщение',
                'partial-payment'        => 'Частичная оплата',
                'pre-order-percent-info' => 'Это значение будет использоваться, если выбран тип "Частичная оплата".',
                'pre-order-percent'      => 'Процент предзаказа',
                'pre-order-type'         => 'Тип предзаказа',
                'preorder'               => 'Предзаказ',
                'settings'               => 'Настройки',
                
                'general'               => [
                    'info'   => 'Установите тип предзаказа, процент предзаказа и сообщение.',
                    'title'  => 'Общие',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'Название канала',
            'complete-payment' => 'Полная оплата',
            'completed'        => 'Завершено',
            'created-at'       => 'Создано',
            'customer-email'   => 'Электронная почта клиента',
            'customer-name'    => 'Имя клиента',
            'email-sent'       => 'Электронное письмо отправлено',
            'id'               => 'ID',
            'image'            => 'Изображение',
            'location'         => 'Местоположение',
            'no'               => 'Нет',
            'normal-order'     => 'Обычный заказ',
            'not-applicable'   => 'Не применимо',
            'notify-customer'  => 'Уведомить клиента',
            'order-id'         => 'ID заказа',
            'order-type'       => 'Тип заказа',
            'paid-amount'      => 'Оплаченная сумма',
            'partial-payment'  => 'Частичная оплата',
            'pay-by'           => 'Оплачено через',
            'payment-order-id' => 'ID платежного заказа',
            'pending'          => 'В ожидании',
            'pre-order-type'   => 'Тип предварительного заказа',
            'preorder'         => 'Предварительный заказ',
            'processing'       => 'Обрабатывается',
            'product-name'     => 'Название продукта',
            'remaining-amount' => 'Оставшаяся сумма',
            'status'           => 'Статус',
            'yes'              => 'Да',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Уважаемый/Уважаемая :name',
            'info'    => 'Товар :name теперь доступен на складе. <a style="color:#0041FF" href=":link">Нажмите здесь</a>, чтобы завершить предзаказ.',
            'subject' => 'Уведомление о наличии товара',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Доступно с:</span> :date',
                    'available-soon-for-preorder'  => 'Скоро доступно для предзаказа',
                    'complete-preorder-error'      => 'Оплата предзаказа не завершена.',
                    'complete-preorder'            => 'Завершить предзаказ',
                    'nothing-to-pay'               => 'Ничего не нужно оплачивать за предзаказ.',
                    'payment-order'                => 'Заказ оплаты',
                    'percent-to-pay'               => 'Оплатить :percent% в качестве предзаказа.',
                    'preorder-information'         => 'Информация о предзаказе',
                    'preorder-payment-information' => 'Информация о предварительной оплате',
                    'preorder-summary'             => 'Этот заказ содержит товары для предзаказа.',
                    'preorder'                     => 'Предзаказ',
                    'reference-order'              => 'Ссылка на заказ',
                    'status'                       => 'Статус: ',
                    'type'                         => 'Тип: ',
                ],
            ],

            'products' => [
                'available-on' => '<span>Доступно с:</span> :date',
                'preorder'     => 'Предзаказ',
            ],

            'checkout' => [
                'cart' => [
                    'error' => [
                        'payment-done'          => 'Оплата уже выполнена за этот заказ',
                        'preorder-payment'      => 'Оплата предзаказа не может быть добавлена с другим продуктом.',
                        'product-not-added'     => 'Продукт не может быть добавлен с оплатой предзаказа.',
                        'quantity-error'        => 'Запрошенное количество недоступно для предзаказа.',
                        'quantity-update-error' => 'Количество оплаты предзаказа не может быть обновлено.',
                    ],
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'Уведомить клиента',
        'pre-order'       => 'Предзаказ',
    ],
];