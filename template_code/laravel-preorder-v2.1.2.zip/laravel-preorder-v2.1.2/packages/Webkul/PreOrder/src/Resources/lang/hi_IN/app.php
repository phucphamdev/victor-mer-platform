<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'पूर्वाग्रह',
        ],

        'catalog' => [
            'title' => 'पूर्वाग्रह की अनुमति दें',

            'attributes' => [
                'allow-preorder'       => 'पूर्वाग्रह की अनुमति दें',
                'product-availability' => 'उत्पाद उपलब्धता',
                'product-qty'          => 'उत्पाद मात्रा',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'स्टॉक सूचना ईमेल नहीं भेजी गई।',
            'mass-notify-success' => 'स्टॉक सूचना ईमेल सफलतापूर्वक भेजी गई।',
            'title'               => 'पूर्वाग्रह',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'भुगतान आदेश : ',
                'preorder-information'         => 'पूर्वाग्रह जानकारी',
                'preorder-payment-information' => 'पूर्वाग्रह भुगतान जानकारी',
                'preorder-summary'             => 'यह आदेश पूर्वाग्रह आइटम शामिल करता है।',
                'reference-order'              => 'संदर्भ आदेश : ',
                'status'                       => 'स्थिति : ',
                'type'                         => 'प्रकार : ',
            ],
        ],

        'configuration' => [
            'info'     => 'पूर्वाग्रह विकल्प सेट करें।',
            'title'    => 'पूर्वाग्रह',

            'settings' => [
                'info'  => 'पूर्वाग्रह विकल्प सेट करें।',
                'title' => 'सेटिंग्स',
            ],

            'system' => [
                'complete-payment'       => 'पूर्ण भुगतान',
                'enable-automatic-mail'  => 'स्वचालित मेल सक्षम करें',
                'enable-pre-order'       => 'पूर्वाग्रह सक्षम करें',
                'message'                => 'संदेश',
                'partial-payment'        => 'आंशिक भुगतान',
                'pre-order-percent-info' => 'यह मूल्य उपयोग किया जाएगा अगर "पूर्वाग्रह प्रकार" को "आंशिक भुगतान" के रूप में चुना गया है।',
                'pre-order-percent'      => 'पूर्वाग्रह प्रतिशत',
                'pre-order-type'         => 'पूर्वाग्रह प्रकार',
                'preorder'               => 'पूर्वाग्रह',
                'settings'               => 'सेटिंग्स',

                'general' => [
                    'info'   => 'पूर्वाग्रह प्रकार, पूर्वाग्रह प्रतिशत और संदेश सेट करें।',
                    'title'  => 'सामान्य',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'चैनल का नाम',
            'complete-payment' => 'पूर्ण भुगतान',
            'completed'        => 'पूर्ण',
            'created-at'       => 'सृजित किया गया',
            'customer-email'   => 'ग्राहक ईमेल',
            'customer-name'    => 'ग्राहक का नाम',
            'email-sent'       => 'ईमेल भेजा गया',
            'id'               => 'आईडी',
            'image'            => 'छवि',
            'location'         => 'स्थान',
            'no'               => 'नहीं',
            'normal-order'     => 'सामान्य आदेश',
            'not-applicable'   => 'लागू नहीं',
            'notify-customer'  => 'ग्राहक को सूचित करें',
            'order-id'         => 'आदेश आईडी',
            'order-type'       => 'आदेश का प्रकार',
            'paid-amount'      => 'भुगतान की गई राशि',
            'partial-payment'  => 'आंशिक भुगतान',
            'pay-by'           => 'द्वारा भुगतान',
            'payment-order-id' => 'भुगतान का आदेश आईडी',
            'pending'          => 'अपूर्ण',
            'pre-order-type'   => 'पूर्व-आदेश का प्रकार',
            'preorder'         => 'पूर्व-आदेश',
            'processing'       => 'प्रसंस्करण में',
            'product-name'     => 'उत्पाद का नाम',
            'remaining-amount' => 'शेष राशि',
            'status'           => 'स्थिति',
            'yes'              => 'हां',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'प्रिय :name',
            'info'    => 'उत्पाद :name अब ऑनलाइन उपलब्ध है। <a style="color:#0041FF" href=":link">यहाँ क्लिक करें</a> पूर्वाग्रह को पूरा करने के लिए।',
            'subject' => 'उत्पाद ऑनलाइन उपलब्ध सूचना',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>उपलब्ध है :</span> :date',
                    'available-soon-for-preorder'  => 'पूर्वाग्रह के लिए जल्द ही उपलब्ध होगा',
                    'complete-preorder-error'      => 'पूर्वाग्रह भुगतान पूरा नहीं हो सका।',
                    'complete-preorder'            => 'पूर्ण पूर्वाग्रह',
                    'nothing-to-pay'               => 'पूर्वाग्रह के लिए कुछ नहीं भुगतान करना है।',
                    'payment-order'                => 'भुगतान आदेश',
                    'percent-to-pay'               => 'पूर्वाग्रह के रूप में :percent% भुगतान करें।',
                    'preorder-information'         => 'पूर्वाग्रह जानकारी',
                    'preorder-payment-information' => 'पूर्वाग्रह भुगतान जानकारी',
                    'preorder-summary'             => 'यह आदेश पूर्वाग्रह आइटम शामिल करता है।',
                    'preorder'                     => 'पूर्वाग्रह',
                    'reference-order'              => 'संदर्भ आदेश',
                    'status'                       => 'स्थिति : ',
                    'type'                         => 'प्रकार : ',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>उपलब्ध है :</span> :date',
            'preorder'     => 'पूर्वाग्रह',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'इस आदेश के लिए भुगतान किया गया है',
                    'preorder-payment'      => 'अन्य उत्पाद के साथ पूर्वाग्रह भुगतान नहीं जोड़ा जा सकता।',
                    'product-not-added'     => 'पूर्वाग्रह भुगतान के साथ उत्पाद नहीं जोड़ा जा सकता।',
                    'quantity-error'        => 'पूर्वाग्रह के लिए अनुरोधित मात्रा उपलब्ध नहीं है।',
                    'quantity-update-error' => 'पूर्वाग्रह भुगतान मात्रा को अद्यतन नहीं किया जा सकता।',
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'ग्राहक को सूचित करें',
        'pre-order'       => 'पूर्वाग्रह',
    ],
];