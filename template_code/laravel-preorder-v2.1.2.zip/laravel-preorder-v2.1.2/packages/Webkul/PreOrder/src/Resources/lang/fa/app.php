<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'پیش‌خرید',
        ],

        'catalog' => [
            'title' => 'اجازه‌ی پیش‌خرید',

            'attributes' => [
                'allow-preorder'       => 'اجازه‌ی پیش‌خرید',
                'product-availability' => 'دسترسی محصول',
                'product-qty'          => 'تعداد محصول',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'ایمیل اعلان موجودی ارسال نشد.',
            'mass-notify-success' => 'ایمیل اعلان موجودی با موفقیت ارسال شد.',
            'title'               => 'پیش‌خریدها',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'سفارش پرداخت: ',
                'preorder-information'         => 'اطلاعات پیش‌خرید',
                'preorder-payment-information' => 'اطلاعات پرداخت پیش‌خرید',
                'preorder-summary'             => 'این سفارش شامل موارد پیش‌خرید می‌شود.',
                'reference-order'              => 'سفارش مرجع: ',
                'status'                       => 'وضعیت: ',
                'type'                         => 'نوع: ',
            ],
        ],

        'configuration' => [
            'info'     => 'تنظیم گزینه‌های پیش‌خرید.',
            'title'    => 'پیش‌خرید',

            'settings' => [
                'info'  => 'تنظیم گزینه‌های پیش‌خرید.',
                'title' => 'تنظیمات',
            ],

            'system' => [
                'complete-payment'       => 'پرداخت کامل',
                'enable-automatic-mail'  => 'فعال‌سازی ایمیل خودکار',
                'enable-pre-order'       => 'فعال‌سازی پیش‌خرید',
                'message'                => 'پیام',
                'partial-payment'        => 'پرداخت جزئی',
                'pre-order-percent-info' => 'این مقدار در صورت انتخاب "نوع پیش‌خرید" به عنوان "پرداخت جزئی" استفاده می‌شود.',
                'pre-order-percent'      => 'درصد پیش‌خرید',
                'pre-order-type'         => 'نوع پیش‌خرید',
                'preorder'               => 'پیش‌خرید',
                'settings'               => 'تنظیمات',
                
                'general'               => [
                    'info'   => 'تعیین نوع پیش‌خرید، درصد پیش‌خرید و پیام.',
                    'title'  => 'عمومی',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'نام کانال',
            'complete-payment' => 'پرداخت کامل',
            'completed'        => 'تکمیل شده',
            'created-at'       => 'ایجاد شده در',
            'customer-email'   => 'ایمیل مشتری',
            'customer-name'    => 'نام مشتری',
            'email-sent'       => 'ایمیل ارسال شده',
            'id'               => 'شناسه',
            'image'            => 'تصویر',
            'location'         => 'مکان',
            'no'               => 'خیر',
            'normal-order'     => 'سفارش عادی',
            'not-applicable'   => 'ناقابل اجرا',
            'notify-customer'  => 'اطلاع رسانی به مشتری',
            'order-id'         => 'شناسه سفارش',
            'order-type'       => 'نوع سفارش',
            'paid-amount'      => 'مبلغ پرداخت شده',
            'partial-payment'  => 'پرداخت جزئی',
            'pay-by'           => 'پرداخت توسط',
            'payment-order-id' => 'شناسه سفارش پرداخت',
            'pending'          => 'در انتظار',
            'pre-order-type'   => 'نوع پیش سفارش',
            'preorder'         => 'پیش سفارش',
            'processing'       => 'در حال پردازش',
            'product-name'     => 'نام محصول',
            'remaining-amount' => 'مبلغ باقی‌مانده',
            'status'           => 'وضعیت',
            'yes'              => 'بله',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'عزیز :name',
            'info'    => 'محصول :name هم‌اکنون در انبار موجود است. <a style="color:#0041FF" href=":link">اینجا کلیک کنید</a> تا پیش‌خرید را تکمیل کنید.',
            'subject' => 'اعلان موجودی محصول',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>در دسترس از:</span> :date',
                    'available-soon-for-preorder'  => 'به زودی برای پیش‌خرید موجود است',
                    'complete-preorder-error'      => 'پرداخت پیش‌خرید تکمیل نشده است.',
                    'complete-preorder'            => 'پیش‌خرید را تکمیل کنید',
                    'nothing-to-pay'               => 'برای پیش‌خرید چیزی پرداخت نشده است.',
                    'payment-order'                => 'سفارش پرداخت',
                    'percent-to-pay'               => 'پرداخت :percent% به عنوان پیش‌خرید.',
                    'preorder-information'         => 'اطلاعات پیش‌خرید',
                    'preorder-payment-information' => 'اطلاعات پرداخت پیش‌خرید',
                    'preorder-summary'             => 'این سفارش شامل موارد پیش‌خرید می‌شود.',
                    'preorder'                     => 'پیش‌خرید',
                    'reference-order'              => 'سفارش مرجع',
                    'status'                       => 'وضعیت: ',
                    'type'                         => 'نوع: ',
                ],
            ],
        ],
        
        'products' => [
            'available-on' => '<span>در دسترس در تاریخ:</span> :date',
            'preorder'     => 'پیش‌خرید',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'پرداخت برای این سفارش انجام شده است',
                    'preorder-payment'      => 'پرداخت پیش‌خرید نمی‌تواند با محصول دیگری اضافه شود.',
                    'product-not-added'     => 'محصول نمی‌تواند با پرداخت پیش‌خرید اضافه شود.',
                    'quantity-error'        => 'مقدار درخواستی برای پیش‌خرید موجود نیست.',
                    'quantity-update-error' => 'مقدار پرداخت پیش‌خرید نمی‌تواند به‌روزرسانی شود.',
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'اطلاع رسانی به مشتری',
        'pre-order'       => 'پیش‌خرید',
    ],
];