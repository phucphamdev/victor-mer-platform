<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Reserva anticipada',
        ],

        'catalog' => [
            'title' => 'Permitir reserva anticipada',

            'attributes' => [
                'allow-preorder'       => 'Permitir reserva anticipada',
                'product-availability' => 'Disponibilidad del producto',
                'product-qty'          => 'Cantidad del producto',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'Correo electrónico de notificación de existencias no enviado.',
            'mass-notify-success' => 'Correo electrónico de notificación de existencias enviado correctamente.',
            'title'               => 'Reservas anticipadas',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Pedido de pago: ',
                'preorder-information'         => 'Información de reserva anticipada',
                'preorder-payment-information' => 'Información de pago de reserva anticipada',
                'preorder-summary'             => 'Este pedido contiene artículos de reserva anticipada.',
                'reference-order'              => 'Pedido de referencia: ',
                'status'                       => 'Estado: ',
                'type'                         => 'Tipo: ',
            ],
        ],

        'configuration' => [
            'info'     => 'Configurar opciones de reserva anticipada.',
            'title'    => 'Reserva anticipada',

            'settings' => [
                'info'  => 'Configurar opciones de reserva anticipada.',
                'title' => 'Configuración',
            ],

            'system' => [
                'complete-payment'       => 'Pago completo',
                'enable-automatic-mail'  => 'Habilitar correo automático',
                'enable-pre-order'       => 'Habilitar reserva anticipada',
                'message'                => 'Mensaje',
                'partial-payment'        => 'Pago parcial',
                'pre-order-percent-info' => 'Este valor se utilizará si se selecciona "Pago parcial" como "Tipo de reserva anticipada".',
                'pre-order-percent'      => 'Porcentaje de reserva anticipada',
                'pre-order-type'         => 'Tipo de reserva anticipada',
                'preorder'               => 'Reserva anticipada',
                'settings'               => 'Configuración',
                
                'general' => [
                    'info'   => 'Establecer tipo de reserva anticipada, porcentaje de reserva anticipada y mensaje.',
                    'title'  => 'General',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'Nombre del Canal',
            'complete-payment' => 'Pago Completo',
            'completed'        => 'Completado',
            'created-at'       => 'Creado en',
            'customer-email'   => 'Correo Electrónico del Cliente',
            'customer-name'    => 'Nombre del Cliente',
            'email-sent'       => 'Correo Electrónico Enviado',
            'id'               => 'ID',
            'image'            => 'Imagen',
            'location'         => 'Ubicación',
            'no'               => 'No',
            'normal-order'     => 'Pedido Normal',
            'not-applicable'   => 'No Aplicable',
            'notify-customer'  => 'Notificar al Cliente',
            'order-id'         => 'ID de Pedido',
            'order-type'       => 'Tipo de Pedido',
            'paid-amount'      => 'Cantidad Pagada',
            'partial-payment'  => 'Pago Parcial',
            'pay-by'           => 'Pago por',
            'payment-order-id' => 'ID de Pedido de Pago',
            'pending'          => 'Pendiente',
            'pre-order-type'   => 'Tipo de Preventa',
            'preorder'         => 'Preventa',
            'processing'       => 'Procesando',
            'product-name'     => 'Nombre del Producto',
            'remaining-amount' => 'Cantidad Restante',
            'status'           => 'Estado',
            'yes'              => 'Sí',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Estimado/a :name',
            'info'    => 'El producto :name ya está disponible en stock. <a style="color:#0041FF" href=":link">Haz clic aquí</a> para completar la reserva anticipada.',
            'subject' => 'Notificación de producto en stock',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Disponible en:</span> :date',
                    'available-soon-for-preorder'  => 'Próximamente disponible para reserva anticipada',
                    'complete-preorder-error'      => 'El pago de reserva anticipada no se pudo completar.',
                    'complete-preorder'            => 'Completar reserva anticipada',
                    'nothing-to-pay'               => 'Nada que pagar por la reserva anticipada.',
                    'payment-order'                => 'Pedido de pago',
                    'percent-to-pay'               => 'Pagar :percent% como reserva anticipada.',
                    'preorder-information'         => 'Información de reserva anticipada',
                    'preorder-payment-information' => 'Información de pago de reserva anticipada',
                    'preorder-summary'             => 'Este pedido contiene artículos de reserva anticipada.',
                    'preorder'                     => 'Reserva anticipada',
                    'reference-order'              => 'Pedido de referencia',
                    'status'                       => 'Estado: ',
                    'type'                         => 'Tipo: ',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>Disponible en:</span> :date',
            'preorder'     => 'Reserva anticipada',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'El pago de este pedido ya se ha realizado',
                    'preorder-payment'      => 'El pago de reserva anticipada no se puede agregar con otros productos.',
                    'product-not-added'     => 'El producto no se puede agregar con el pago de reserva anticipada.',
                    'quantity-error'        => 'Cantidad solicitada no disponible para reserva anticipada.',
                    'quantity-update-error' => 'No se puede actualizar la cantidad de reserva anticipada.',
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'Notificar al Cliente',
        'pre-order'       => 'Reserva anticipada',
    ],
];