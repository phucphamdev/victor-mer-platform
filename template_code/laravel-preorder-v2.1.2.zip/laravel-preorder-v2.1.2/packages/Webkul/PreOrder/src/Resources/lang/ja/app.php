<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => '予約注文',
        ],

        'catalog' => [
            'title' => '予約を許可する',

            'attributes' => [
                'allow-preorder'       => '予約を許可する',
                'product-availability' => '製品の入手可能性',
                'product-qty'          => '製品数量',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => '在庫通知メールの送信に失敗しました。',
            'mass-notify-success' => '在庫通知メールが正常に送信されました。',
            'title'               => '予約注文',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => '支払い注文：',
                'preorder-information'         => '予約情報',
                'preorder-payment-information' => '予約支払い情報',
                'preorder-summary'             => 'この注文には予約商品が含まれています。',
                'reference-order'              => '参照注文：',
                'status'                       => 'ステータス：',
                'type'                         => 'タイプ：',
            ],
        ],

        'configuration' => [
            'info'  => '予約オプションを設定します。',
            'title' => '予約',

            'settings' => [
                'info'  => '予約オプションを設定します。',
                'title' => '設定',
            ],

            'system' => [
                'complete-payment'       => '完全な支払い',
                'enable-automatic-mail'  => '自動メールを有効にする',
                'enable-pre-order'       => '予約を有効にする',
                'message'                => 'メッセージ',
                'partial-payment'        => '部分支払い',
                'pre-order-percent-info' => '「予約タイプ」が「部分支払い」に選択されている場合、この値が使用されます。',
                'pre-order-percent'      => '予約パーセント',
                'pre-order-type'         => '予約タイプ',
                'preorder'               => '予約',
                'settings'               => '設定',
                
                'general' => [
                    'info'   => '予約タイプ、予約パーセンテージ、およびメッセージを設定します。',
                    'title'  => '一般',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'チャネル名',
            'complete-payment' => '完全支払い',
            'completed'        => '完了',
            'created-at'       => '作成日時',
            'customer-email'   => '顧客メールアドレス',
            'customer-name'    => '顧客名',
            'email-sent'       => 'メール送信済み',
            'id'               => 'ID',
            'image'            => '画像',
            'location'         => '場所',
            'no'               => 'いいえ',
            'normal-order'     => '通常注文',
            'not-applicable'   => '該当なし',
            'notify-customer'  => '顧客に通知',
            'order-id'         => '注文ID',
            'order-type'       => '注文タイプ',
            'paid-amount'      => '支払金額',
            'partial-payment'  => '一部支払い',
            'pay-by'           => '支払い方法',
            'payment-order-id' => '支払い注文ID',
            'pending'          => '保留中',
            'pre-order-type'   => '事前注文タイプ',
            'preorder'         => '事前注文',
            'processing'       => '処理中',
            'product-name'     => '製品名',
            'remaining-amount' => '残高',
            'status'           => 'ステータス',
            'yes'              => 'はい',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => ':name 様',
            'info'    => '商品 :name は現在在庫があります。予約を完了するには<a style="color:#0041FF" href=":link">こちら</a>をクリックしてください。',
            'subject' => '在庫商品の通知',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>利用可能日：</span> :date',
                    'available-soon-for-preorder'  => 'すぐに予約できるようになります',
                    'complete-preorder-error'      => '予約支払いが完了しませんでした。',
                    'complete-preorder'            => '予約を完了する',
                    'nothing-to-pay'               => '予約金はありません。',
                    'payment-order'                => '支払い注文',
                    'percent-to-pay'               => '予約金として :percent% を支払う。',
                    'preorder-information'         => '予約情報',
                    'preorder-payment-information' => '予約支払情報',
                    'preorder-summary'             => 'この注文には予約商品が含まれています。',
                    'preorder'                     => '予約',
                    'reference-order'              => '参照注文',
                    'status'                       => 'ステータス：',
                    'type'                         => 'タイプ：',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>利用可能日：</span> :date',
            'preorder'     => '予約',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'この注文に対する支払いが完了しています。',
                    'preorder-payment'      => '他の商品と一緒に予約支払いを追加できません。',
                    'product-not-added'     => '予約金で商品を追加できません。',
                    'quantity-error'        => '予約用に要求された数量は利用できません。',
                    'quantity-update-error' => '予約支払いの数量を更新できません。',
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => '顧客に通知',
        'pre-order'       => '予約注文',
    ],
];