<?php 

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'প্রি-অর্ডার',
        ],

        'catalog' => [
            'title' => 'প্রি-অর্ডার অনুমোদন',

            'attributes' => [
                'allow-preorder'       => 'প্রি-অর্ডার অনুমোদন করুন',
                'product-availability' => 'পণ্যের উপলব্ধতা',
                'product-qty'          => 'পণ্যের পরিমাণ',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'স্টক বিজ্ঞপ্তি ইমেল প্রেরণ ব্যর্থ হয়েছে।',
            'mass-notify-success' => 'স্টক বিজ্ঞপ্তি ইমেল সফলভাবে প্রেরিত হয়েছে।',
            'title'               => 'প্রি-অর্ডার',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'পেমেন্ট অর্ডার: ',
                'preorder-information'         => 'প্রি-অর্ডার তথ্য',
                'preorder-payment-information' => 'প্রি-অর্ডার পেমেন্টের তথ্য',
                'preorder-summary'             => 'এই অর্ডারে প্রি-অর্ডার আইটেম রয়েছে।',
                'reference-order'              => 'রেফারেন্স অর্ডার: ',
                'status'                       => 'অবস্থা: ',
                'type'                         => 'ধরন: ',
            ],
        ],

        'configuration' => [
            'info'     => 'প্রি-অর্ডার বিকল্পগুলি নির্ধারণ করুন।',
            'title'    => 'প্রি-অর্ডার',

            'settings' => [
                'info'  => 'প্রি-অর্ডার বিকল্পগুলি নির্ধারণ করুন।',
                'title' => 'সেটিংস',
            ],

            'system' => [
                'complete-payment'       => 'সম্পূর্ণ পেমেন্ট',
                'enable-automatic-mail'  => 'স্বয়ংক্রিয় ইমেল সক্রিয় করুন',
                'enable-pre-order'       => 'প্রি-অর্ডার সক্রিয় করুন',
                'message'                => 'বার্তা',
                'partial-payment'        => 'আংশিক পেমেন্ট',
                'pre-order-percent-info' => 'এই মানটি ব্যবহৃত হবে যদি "প্রি-অর্ডার ধরন" নির্বাচিত হয় "আংশিক পেমেন্ট" হিসাবে।',
                'pre-order-percent'      => 'প্রি-অর্ডার শতাংশ',
                'pre-order-type'         => 'প্রি-অর্ডার ধরন',
                'preorder'               => 'প্রি-অর্ডার',
                'settings'               => 'সেটিংস',
                
                'general'               => [
                    'info'   => 'প্রি-অর্ডার ধরন, প্রি-অর্ডার শতাংশ এবং বার্তা নির্ধারণ করুন।',
                    'title'  => 'সাধারণ',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'চ্যানেলের নাম',
            'complete-payment' => 'সম্পূর্ণ পরিশোধ',
            'completed'        => 'সম্পন্ন',
            'created-at'       => 'তৈরি করা হয়েছে',
            'customer-email'   => 'গ্রাহকের ইমেল',
            'customer-name'    => 'ক্রেতার নাম',
            'email-sent'       => 'ইমেইল প্রেরিত',
            'id'               => 'আইডি',
            'image'            => 'ছবি',
            'location'         => 'অবস্থান',
            'no'               => 'না',
            'normal-order'     => 'সাধারণ অর্ডার',
            'not-applicable'   => 'প্রযোজ্য নয়',
            'notify-customer'  => 'গ্রাহককে অবহিত করুন',
            'order-id'         => 'অর্ডার আইডি',
            'order-type'       => 'অর্ডারের ধরণ',
            'paid-amount'      => 'পরিশোধিত পরিমাণ',
            'partial-payment'  => 'আংশিক পরিশোধ',
            'pay-by'           => 'অর্থ প্রদানের মাধ্যম',
            'payment-order-id' => 'অর্থ প্রদান অর্ডার আইডি',
            'pending'          => 'মুলতুবি',
            'pre-order-type'   => 'প্রি-অর্ডার প্রকার',
            'preorder'         => 'প্রি-অর্ডার',
            'processing'       => 'প্রসেসিং',
            'product-name'     => 'পণ্যের নাম',
            'remaining-amount' => 'অবশিষ্ট পরিমাণ',
            'status'           => 'অবস্থা',
            'yes'              => 'হ্যাঁ',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'প্রিয় :name',
            'info'    => 'পণ্য :name এখন স্টকে আসেছে। <a style="color:#0041FF" href=":link">এখানে ক্লিক করুন</a> প্রি-অর্ডার সম্পন্ন করতে।',
            'subject' => 'পণ্য স্টকে অবগতি ইমেল',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>উপলব্ধ:</span> :date',
                    'available-soon-for-preorder'  => 'প্রি-অর্ডার জন্য শীঘ্রই উপলব্ধ',
                    'complete-preorder-error'      => 'প্রি-অর্ডার পেমেন্ট সম্পন্ন হয়নি।',
                    'complete-preorder'            => 'প্রি-অর্ডার সম্পন্ন করুন',
                    'nothing-to-pay'               => 'প্রি-অর্ডার হিসাবে কোনও পরিশোধ নেই।',
                    'payment-order'                => 'পেমেন্ট অর্ডার',
                    'percent-to-pay'               => ':percent% প্রি-অর্ডার হিসাবে পরিশোধ করুন।',
                    'preorder-information'         => 'প্রি-অর্ডার তথ্য',
                    'preorder-payment-information' => 'প্রি-অর্ডার পেমেন্টের তথ্য',
                    'preorder-summary'             => 'এই অর্ডারে প্রি-অর্ডার আইটেম রয়েছে।',
                    'preorder'                     => 'প্রি-অর্ডার',
                    'reference-order'              => 'রেফারেন্স অর্ডার',
                    'status'                       => 'অবস্থা: ',
                    'type'                         => 'ধরন: ',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>উপলব্ধ:</span> :date',
            'preorder'     => 'প্রি-অর্ডার',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'এই অর্ডারের জন্য পেমেন্ট সম্পন্ন হয়েছে',
                    'preorder-payment'      => 'প্রি-অর্ডার পেমেন্ট অন্যান্য পণ্যের সাথে যুক্ত করা যাবে না।',
                    'product-not-added'     => 'প্রি-অর্ডার পেমেন্ট সহ পণ্য যুক্ত করা যাবে না।',
                    'quantity-error'        => 'প্রি-অর্ডারের জন্য অনুরোধকৃত পরিমাণ পাওয়া যায়নি।',
                    'quantity-update-error' => 'প্রি-অর্ডারের পরিমাণ আপডেট করা যায়নি।',
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'গ্রাহককে অবহিত করুন',
        'pre-order'       => 'প্রি-অর্ডার',
    ],
];