<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Voorbestelling',
        ],

        'catalog' => [
            'title' => 'Voorbestelling toestaan',

            'attributes' => [
                'allow-preorder'       => 'Voorbestelling toestaan',
                'product-availability' => 'Productbeschikbaarheid',
                'product-qty'          => 'Producthoeveelheid',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'Voorraadmelding per e-mail niet verzonden.',
            'mass-notify-success' => 'Voorraadmelding per e-mail succesvol verzonden.',
            'title'               => 'Voorbestellingen',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Betalingsbestelling: ',
                'preorder-information'         => 'Voorbestellinginformatie',
                'preorder-payment-information' => 'Voorbestellingsbetalingsinformatie',
                'preorder-summary'             => 'Deze bestelling bevat voorbestelde items.',
                'reference-order'              => 'Referentiebestelling: ',
                'status'                       => 'Status: ',
                'type'                         => 'Type: ',
            ],
        ],

        'configuration' => [
            'info'     => 'Voorbestellingsopties instellen.',
            'title'    => 'Voorbestelling',

            'settings' => [
                'info'  => 'Voorbestellingsopties instellen.',
                'title' => 'Instellingen',
            ],

            'system' => [
                'complete-payment'       => 'Volledige betaling',
                'enable-automatic-mail'  => 'Automatische e-mail inschakelen',
                'enable-pre-order'       => 'Voorbestelling inschakelen',
                'message'                => 'Bericht',
                'partial-payment'        => 'Gedeeltelijke betaling',
                'pre-order-percent-info' => 'Deze waarde wordt gebruikt als "Voorbestellingstype" is geselecteerd als "Gedeeltelijke betaling".',
                'pre-order-percent'      => 'Percentage voorbestelling',
                'pre-order-type'         => 'Voorbestellingstype',
                'preorder'               => 'Voorbestelling',
                'settings'               => 'Instellingen',
                
                'general' => [
                    'info'   => 'Voorbestellingstype, percentage voorbestelling en bericht instellen.',
                    'title'  => 'Algemeen',
                ],
            ],
        ],
        
        'datagrid' => [
            'channel-name'     => 'Kanaalnaam',
            'complete-payment' => 'Volledige betaling',
            'completed'        => 'Voltooid',
            'created-at'       => 'Aangemaakt op',
            'customer-email'   => 'E-mail klant',
            'customer-name'    => 'Naam klant',
            'email-sent'       => 'E-mail verzonden',
            'id'               => 'ID',
            'image'            => 'Afbeelding',
            'location'         => 'Locatie',
            'no'               => 'Nee',
            'normal-order'     => 'Normale bestelling',
            'not-applicable'   => 'Niet van toepassing',
            'notify-customer'  => 'Klant op de hoogte stellen',
            'order-id'         => 'Bestel-ID',
            'order-type'       => 'Besteltype',
            'paid-amount'      => 'Betaald bedrag',
            'partial-payment'  => 'Gedeeltelijke betaling',
            'pay-by'           => 'Betaald via',
            'payment-order-id' => 'Betaal-ID',
            'pending'          => 'In afwachting',
            'pre-order-type'   => 'Pre-order type',
            'preorder'         => 'Pre-order',
            'processing'       => 'Wordt verwerkt',
            'product-name'     => 'Productnaam',
            'remaining-amount' => 'Resterend bedrag',
            'status'           => 'Status',
            'yes'              => 'Ja',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Beste :name',
            'info'    => 'Product :name is nu op voorraad. <a style="color:#0041FF" href=":link">Klik hier</a> om de voorbestelling te voltooien.',
            'subject' => 'Product op voorraad melding',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Beschikbaar op:</span> :date',
                    'available-soon-for-preorder'  => 'Binnenkort beschikbaar voor voorbestelling',
                    'complete-preorder-error'      => 'Voorbestellingsbetaling niet voltooid.',
                    'complete-preorder'            => 'Voorbestelling voltooien',
                    'nothing-to-pay'               => 'Niets te betalen voor de voorbestelling.',
                    'payment-order'                => 'Betalingsbestelling',
                    'percent-to-pay'               => ':percent% betalen als voorbestelling.',
                    'preorder-information'         => 'Voorbestellinginformatie',
                    'preorder-payment-information' => 'Voorbestellingsbetalingsinformatie',
                    'preorder-summary'             => 'Deze bestelling bevat voorbestelde items.',
                    'preorder'                     => 'Voorbestelling',
                    'reference-order'              => 'Referentiebestelling',
                    'status'                       => 'Status: ',
                    'type'                         => 'Type: ',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>Beschikbaar op:</span> :date',
            'preorder'     => 'Voorbestelling',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'Betaling is al voltooid voor deze bestelling',
                    'preorder-payment'      => 'Voorbestellingsbetaling kan niet worden toegevoegd met ander product.',
                    'product-not-added'     => 'Product kan niet worden toegevoegd met voorbestellingsbetaling.',
                    'quantity-error'        => 'Gevraagde hoeveelheid niet beschikbaar voor voorbestelling.',
                    'quantity-update-error' => 'Voorbestellingsbetalingshoeveelheid kan niet worden bijgewerkt.',
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'Klant op de hoogte stellen',
        'pre-order'       => 'Voorbestelling',
    ],
];