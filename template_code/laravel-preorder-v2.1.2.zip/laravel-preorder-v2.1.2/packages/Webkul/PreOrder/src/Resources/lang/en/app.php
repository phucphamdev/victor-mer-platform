<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Preorder',
        ],

        'catalog' => [
            'title' => 'Allow Preorder',

            'attributes' => [
                'allow-preorder'       => 'Allow Preorder',
                'product-availability' => 'Product Availablity',
                'product-qty'          => 'Product Quantity',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'Stock notification email not sent.',
            'mass-notify-success' => 'Stock notification email sent successfully.',
            'title'               => 'Preorders',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Payment Order : ',
                'preorder-information'         => 'Preorder Information',
                'preorder-payment-information' => 'Preorder Payment Information',
                'preorder-summary'             => 'This order contains preorder items.',
                'reference-order'              => 'Reference Order : ',
                'status'                       => 'Status : ',
                'type'                         => 'Type : ',
            ],
        ],

        'configuration' => [
            'info'     => 'Set preorder options.',
            'title'    => 'Preorder',

            'settings' => [
                'info'  => 'Set preorder options.',
                'title' => 'Settings',
            ],

            'system' => [
                'complete-payment'       => 'Complete Payment',
                'enable-automatic-mail'  => 'Enable Automatic Mail',
                'enable-pre-order'       => 'Enable PreOrder',
                'message'                => 'Message',
                'partial-payment'        => 'Partial Payment',
                'pre-order-percent-info' => 'This value will be used if "Preorder Type" is selected as "Partial Payment".',
                'pre-order-percent'      => 'Preorder Percent',
                'pre-order-type'         => 'Preorder Type',
                'preorder'               => 'Preorder',
                'settings'               => 'Settings',
                
                'general' => [
                    'info'   => 'Set preorder type, preorder percentage and message.',
                    'title'  => 'General',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'default',
            'complete-payment' => 'Complete Payment',
            'completed'        => 'Completed',
            'created-at'       => 'Created_at',
            'customer-email'   => 'Customer Email',
            'customer-name'    => 'Customer Name',
            'email-sent'       => 'Email Sent',
            'id'               => 'Id',
            'image'            => 'Image',
            'location'         => 'Location',
            'no'               => 'No',
            'normal-order'     => 'Normal Order',
            'not-applicable'   => 'N/A',
            'notify-customer'  => 'Notify Customer',
            'order-id'         => 'Order Id',
            'order-type'       => 'Order Type',
            'paid-amount'      => 'Paid Amount',
            'partial-payment'  => 'Partial Payment',
            'pay-by'           => 'Pay Via',
            'payment-order-id' => 'Payment Order Id',
            'pending'          => 'Pending',
            'pre-order-type'   => 'Preorder Type',
            'preorder'         => 'Preorder',
            'processing'       => 'Processing',
            'product-name'     => 'Product Name',
            'remaining-amount' => 'Remaining',
            'status'           => 'Status',
            'yes'              => 'Yes',
        ],
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Dear :name',
            'info'    => 'Product :name has been arrived in stock now. <a style="color:#0041FF" href=":link">Click here</a> to complete preorder.',
            'subject' => 'Product in stock notification',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Available on:</span> :date',
                    'available-soon-for-preorder'  => 'Available soon',
                    'complete-preorder-error'      => 'Preorder payment not be completed.',
                    'complete-preorder'            => 'Complete Preorder',
                    'nothing-to-pay'               => 'Nothing to pay for Preorder.',
                    'payment-order'                => 'Payment Order',
                    'percent-to-pay'               => 'Pay :percent% as Preorder.',
                    'preorder-information'         => 'Preorder Information',
                    'preorder-payment-information' => 'Preorder Payment Information',
                    'preorder-summary'             => 'This order contains preorder items.',
                    'preorder'                     => 'Preorder',
                    'reference-order'              => 'Reference Order',
                    'status'                       => 'Status : ',
                    'type'                         => 'Type : ',
                ],
            ],
        ],
        
        'products' => [
            'available-on' => '<span>Available On:</span> :date',
            'preorder'     => 'Preorder',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'Payment has been done for this order',
                    'preorder-payment'      => 'Preorder payment can not be added with other product.',
                    'product-not-added'     => 'Product can not be added with preorder payment.',
                    'quantity-error'        => 'Requested quantity not available for preorder.',
                    'quantity-update-error' => 'Preorder payment quantity can not be updated.',
                ],
            ],
        ],
    ],

    'acl' => [
       'notify-customer' => 'Notify Customer',
       'pre-order'       => 'Preorder',
    ],
];