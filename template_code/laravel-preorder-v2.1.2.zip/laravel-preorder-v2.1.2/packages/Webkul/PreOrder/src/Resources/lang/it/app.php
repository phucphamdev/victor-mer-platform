<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Pre-ordine',
        ],

        'catalog' => [
            'title' => 'Consenti pre-ordini',

            'attributes' => [
                'allow-preorder'       => 'Consenti pre-ordini',
                'product-availability' => 'Disponibilità prodotto',
                'product-qty'          => 'Quantità prodotto',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'Email di notifica disponibilità non inviata.',
            'mass-notify-success' => 'Email di notifica disponibilità inviata con successo.',
            'title'               => 'Pre-ordini',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Ordine di pagamento : ',
                'preorder-information'         => 'Informazioni pre-ordine',
                'preorder-payment-information' => 'Informazioni pagamento pre-ordine',
                'preorder-summary'             => 'Questo ordine contiene articoli in pre-ordine.',
                'reference-order'              => 'Ordine di riferimento : ',
                'status'                       => 'Stato : ',
                'type'                         => 'Tipo : ',
            ],
        ],

        'configuration' => [
            'info'     => 'Imposta le opzioni per i pre-ordini.',
            'title'    => 'Pre-ordine',

            'settings' => [
                'info'  => 'Imposta le opzioni per i pre-ordini.',
                'title' => 'Impostazioni',
            ],

            'system' => [
                'complete-payment'       => 'Pagamento completo',
                'enable-automatic-mail'  => 'Abilita email automatiche',
                'enable-pre-order'       => 'Abilita pre-ordine',
                'message'                => 'Messaggio',
                'partial-payment'        => 'Pagamento parziale',
                'pre-order-percent-info' => 'Questo valore verrà utilizzato se il "Tipo pre-ordine" è selezionato come "Pagamento parziale".',
                'pre-order-percent'      => 'Percentuale pre-ordine',
                'pre-order-type'         => 'Tipo pre-ordine',
                'preorder'               => 'Pre-ordine',
                'settings'               => 'Impostazioni',
                
                'general' => [
                    'info'   => 'Imposta il tipo di pre-ordine, la percentuale di pre-ordine e il messaggio.',
                    'title'  => 'Generale',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'Nome Canale',
            'complete-payment' => 'Pagamento Completo',
            'completed'        => 'Completato',
            'created-at'       => 'Creato il',
            'customer-email'   => 'Email Cliente',
            'customer-name'    => 'Nome Cliente',
            'email-sent'       => 'Email Inviata',
            'id'               => 'ID',
            'image'            => 'Immagine',
            'location'         => 'Posizione',
            'no'               => 'No',
            'normal-order'     => 'Ordine Normale',
            'not-applicable'   => 'Non Applicabile',
            'notify-customer'  => 'Notifica Cliente',
            'order-id'         => 'ID Ordine',
            'order-type'       => 'Tipo Ordine',
            'paid-amount'      => 'Importo Pagato',
            'partial-payment'  => 'Pagamento Parziale',
            'pay-by'           => 'Pagato tramite',
            'payment-order-id' => 'ID Ordine di Pagamento',
            'pending'          => 'In attesa',
            'pre-order-type'   => 'Tipo Pre-ordine',
            'preorder'         => 'Pre-ordine',
            'processing'       => 'In elaborazione',
            'product-name'     => 'Nome Prodotto',
            'remaining-amount' => 'Importo Rimasto',
            'status'           => 'Stato',
            'yes'              => 'Sì',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Caro :name',
            'info'    => 'Il prodotto :name è ora disponibile. <a style="color:#0041FF" href=":link">Clicca qui</a> per completare il pre-ordine.',
            'subject' => 'Notifica disponibilità prodotto',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Disponibile il:</span> :date',
                    'available-soon-for-preorder'  => 'Disponibile presto per il pre-ordine',
                    'complete-preorder-error'      => 'Pagamento pre-ordine non completato.',
                    'complete-preorder'            => 'Completa pre-ordine',
                    'nothing-to-pay'               => 'Nulla da pagare per il pre-ordine.',
                    'payment-order'                => 'Ordine pagamento',
                    'percent-to-pay'               => 'Paga :percent% come pre-ordine.',
                    'preorder-information'         => 'Informazioni pre-ordine',
                    'preorder-payment-information' => 'Informazioni pagamento pre-ordine',
                    'preorder-summary'             => 'Questo ordine contiene articoli in pre-ordine.',
                    'preorder'                     => 'Pre-ordine',
                    'reference-order'              => 'Ordine di riferimento',
                    'status'                       => 'Stato : ',
                    'type'                         => 'Tipo : ',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>Disponibile il:</span> :date',
            'preorder'     => 'Pre-ordine',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'Pagamento già effettuato per questo ordine',
                    'preorder-payment'      => 'Il pagamento pre-ordine non può essere aggiunto con altri prodotti.',
                    'product-not-added'     => 'Il prodotto non può essere aggiunto con il pagamento pre-ordine.',
                    'quantity-error'        => 'Quantità richiesta non disponibile per il pre-ordine.',
                    'quantity-update-error' => 'La quantità del pagamento pre-ordine non può essere aggiornata.',
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer' => 'Notifica Cliente',
        'pre-order'       => 'Pre-ordine',
    ],
];