<?php

return [
    'admin' => [
        'layouts' => [
            'pre-order' => 'Précommande',
        ],

        'catalog' => [
            'title' => 'Autoriser la précommande',

            'attributes' => [
                'allow-preorder'       => 'Autoriser la précommande',
                'product-availability' => 'Disponibilité du produit',
                'product-qty'          => 'Quantité du produit',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => "L'email de notification de stock n'a pas été envoyé.",
            'mass-notify-success' => 'Notification de stock envoyée avec succès par e-mail.',
            'title'               => 'Précommandes',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'Commande de paiement : ',
                'preorder-information'         => 'Informations sur la précommande',
                'preorder-payment-information' => 'Informations de paiement de la précommande',
                'preorder-summary'             => 'Cette commande contient des articles en précommande.',
                'reference-order'              => 'Commande de référence : ',
                'status'                       => 'Statut : ',
                'type'                         => 'Type : ',
            ],
        ],

        'configuration' => [
            'info'  => "Définir les options de précommande.",
            'title' => 'Précommande',

            'settings' => [
                'info'  => "Définir les options de précommande.",
                'title' => 'Paramètres',
            ],

            'system' => [
                'complete-payment'       => 'Paiement complet',
                'enable-automatic-mail'  => 'Activer le courrier automatique',
                'enable-pre-order'       => 'Activer la précommande',
                'message'                => 'Message',
                'partial-payment'        => 'Paiement partiel',
                'pre-order-percent-info' => "Cette valeur sera utilisée si le 'Type de précommande' est sélectionné comme 'Paiement partiel'.",
                'pre-order-percent'      => 'Pourcentage de précommande',
                'pre-order-type'         => 'Type de précommande',
                'preorder'               => 'Précommande',
                'settings'               => 'Paramètres',
                
                'general' => [
                    'info'   => "Définir le type de précommande, le pourcentage de précommande et le message.",
                    'title'  => 'Général',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'Nom du canal',
            'complete-payment' => 'Paiement complet',
            'completed'        => 'Terminé',
            'created-at'       => 'Créé le',
            'customer-email'   => 'E-mail du client',
            'customer-name'    => 'Nom du client',
            'email-sent'       => 'E-mail envoyé',
            'id'               => 'ID',
            'image'            => 'Image',
            'location'         => 'Emplacement',
            'no'               => 'Non',
            'normal-order'     => 'Commande normale',
            'not-applicable'   => 'Non applicable',
            'notify-customer'  => 'Notifier le client',
            'order-id'         => 'ID de commande',
            'order-type'       => 'Type de commande',
            'paid-amount'      => 'Montant payé',
            'partial-payment'  => 'Paiement partiel',
            'pay-by'           => 'Payé par',
            'payment-order-id' => 'ID de commande de paiement',
            'pending'          => 'En attente',
            'pre-order-type'   => 'Type de précommande',
            'preorder'         => 'Précommande',
            'processing'       => 'En cours de traitement',
            'product-name'     => 'Nom du produit',
            'remaining-amount' => 'Montant restant',
            'status'           => 'Statut',
            'yes'              => 'Oui',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'Cher :name',
            'info'    => "Le produit :name est désormais disponible en stock. <a style=\"color:#0041FF\" href=\":link\">Cliquez ici</a> pour compléter la précommande.",
            'subject' => 'Notification de disponibilité du produit',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>Disponible le :</span> :date',
                    'available-soon-for-preorder'  => 'Bientôt disponible en précommande',
                    'complete-preorder-error'      => "Le paiement de la précommande n'a pas pu être effectué.",
                    'complete-preorder'            => 'Précommande complète',
                    'nothing-to-pay'               => 'Rien à payer pour la précommande.',
                    'payment-order'                => 'Commande de paiement',
                    'percent-to-pay'               => 'Payer :percent% en précommande.',
                    'preorder-information'         => 'Informations sur la précommande',
                    'preorder-payment-information' => 'Informations de paiement de la précommande',
                    'preorder-summary'             => 'Cette commande contient des articles en précommande.',
                    'preorder'                     => 'Précommande',
                    'reference-order'              => 'Commande de référence',
                    'status'                       => 'Statut : ',
                    'type'                         => 'Type : ',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>Disponible le :</span> :date',
            'preorder'     => 'Précommande',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'Le paiement a déjà été effectué pour cette commande',
                    'preorder-payment'      => 'Le paiement en précommande ne peut pas être ajouté avec d\'autres produits.',
                    'product-not-added'     => "Le produit ne peut pas être ajouté avec le paiement en précommande.",
                    'quantity-error'        => 'La quantité demandée n\'est pas disponible en précommande.',
                    'quantity-update-error' => 'La quantité en précommande ne peut pas être mise à jour.',
                ],
            ],
        ],
    ],

    'acl' => [
        'pre-order'       => 'Précommande',
       'notify-customer'  => 'Notifier le client',
    ],
];