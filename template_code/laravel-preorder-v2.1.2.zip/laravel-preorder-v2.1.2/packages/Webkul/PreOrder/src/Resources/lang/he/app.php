<?php

return [
    'admin' => [
        'layouts' => [
            'preorder' => 'הזמנה מראש',
        ],

        'catalog' => [
            'title' => 'אפשר הזמנה מראש',

            'attributes' => [
                'allow-preorder'       => 'אפשר הזמנה מראש',
                'product-availability' => 'זמינות המוצר',
                'product-qty'          => 'כמות המוצר',
            ],
        ],

        'pre-orders' => [
            'mass-notify-error'   => 'דוא"ל התראת מלאי לא נשלח.',
            'mass-notify-success' => 'דוא"ל התראת מלאי נשלח בהצלחה.',
            'title'               => 'הזמנות מראש',
        ],

        'sales' => [
            'orders' => [
                'payment-order'                => 'הזמנת תשלום : ',
                'preorder-information'         => 'מידע על הזמנה מראש',
                'preorder-payment-information' => 'מידע תשלום על הזמנה מראש',
                'preorder-summary'             => 'הזמנה זו מכילה פריטים שהוזמנו מראש.',
                'reference-order'              => 'הזמנת הפניה : ',
                'status'                       => 'סטטוס : ',
                'type'                         => 'סוג : ',
            ],
        ],

        'configuration' => [
            'info'  => 'הגדר אפשרויות להזמנה מראש.',
            'title' => 'הזמנה מראש',

            'settings' => [
                'info'  => 'הגדר אפשרויות להזמנה מראש.',
                'title' => 'הגדרות',
            ],

            'system' => [
                'complete-payment'       => 'תשלום מלא',
                'enable-automatic-mail'  => 'אפשר דוא"ל אוטומטי',
                'enable-pre-order'       => 'אפשר הזמנה מראש',
                'message'                => 'הודעה',
                'partial-payment'        => 'תשלום חלקי',
                'pre-order-percent-info' => 'ערך זה ישמש אם נבחר "סוג הזמנה מראש" כ "תשלום חלקי".',
                'pre-order-percent'      => 'אחוז הזמנה מראש',
                'pre-order-type'         => 'סוג הזמנה מראש',
                'preorder'               => 'הזמנה מראש',
                'settings'               => 'הגדרות',
                
                'general' => [
                    'info'   => 'הגדר סוג הזמנה מראש, אחוז הזמנה מראש והודעה.',
                    'title'  => 'כללי',
                ],
            ],
        ],

        'datagrid' => [
            'channel-name'     => 'שם הערוץ',
            'complete-payment' => 'תשלום מלא',
            'completed'        => 'הושלם',
            'created-at'       => 'נוצר בתאריך',
            'customer-email'   => 'דוא"ל הלקוח',
            'customer-name'    => 'שם הלקוח',
            'email-sent'       => 'דוא"ל נשלח',
            'id'               => 'מזהה',
            'image'            => 'תמונה',
            'location'         => 'מיקום',
            'no'               => 'לא',
            'normal-order'     => 'הזמנה רגילה',
            'not-applicable'   => 'לא רלוונטי',
            'notify-customer'  => 'להודיע ללקוח',
            'order-id'         => 'מספר הזמנה',
            'order-type'       => 'סוג הזמנה',
            'paid-amount'      => 'סכום ששולם',
            'partial-payment'  => 'תשלום חלקי',
            'pay-by'           => 'שולם על ידי',
            'payment-order-id' => 'מספר הזמנת תשלום',
            'pending'          => 'ממתין',
            'pre-order-type'   => 'סוג הזמנה מראש',
            'preorder'         => 'הזמנה מראש',
            'processing'       => 'מעבד',
            'product-name'     => 'שם המוצר',
            'remaining-amount' => 'סכום נותר',
            'status'           => 'סטטוס',
            'yes'              => 'כן',
        ],        
    ],

    'mail' => [
        'in-stock' => [
            'dear'    => 'יקר :name',
            'info'    => 'המוצר :name זמין כעת במלאי. <a style="color:#0041FF" href=":link">לחץ כאן</a> כדי להשלים הזמנה מראש.',
            'subject' => 'התראת הזמינות של המוצר',
        ],
    ],

    'shop' => [
        'customers' => [
            'account' => [
                'orders' => [
                    'available-on'                 => '<span>זמין בתאריך:</span> :date',
                    'available-soon-for-preorder'  => 'זמין בקרוב להזמנה מראש',
                    'complete-preorder-error'      => 'תשלום הזמנה מראש לא הושלם.',
                    'complete-preorder'            => 'הזמנה מראש מלאה',
                    'nothing-to-pay'               => 'אין דבר לשלם עבור הזמנה מראש.',
                    'payment-order'                => 'הזמנת תשלום',
                    'percent-to-pay'               => 'שלם :percent% כהזמנה מראש.',
                    'preorder-information'         => 'מידע על הזמנה מראש',
                    'preorder-payment-information' => 'מידע תשלום על הזמנה מראש',
                    'preorder-summary'             => 'ההזמנה מכילה פריטים בהזמנה מראש.',
                    'preorder'                     => 'הזמנה מראש',
                    'reference-order'              => 'הזמנת הפניה',
                    'status'                       => 'סטטוס : ',
                    'type'                         => 'סוג : ',
                ],
            ],
        ],

        'products' => [
            'available-on' => '<span>זמין בתאריך:</span> :date',
            'preorder'     => 'הזמנה מראש',
        ],

        'checkout' => [
            'cart' => [
                'error' => [
                    'payment-done'          => 'התשלום כבר בוצע עבור הזמנה זו',
                    'preorder-payment'      => 'לא ניתן להוסיף תשלום מראש עם מוצר אחר.',
                    'product-not-added'     => 'לא ניתן להוסיף מוצר עם תשלום מראש.',
                    'quantity-error'        => 'הכמות שביקשת אינה זמינה להזמנה מראש.',
                    'quantity-update-error' => 'לא ניתן לעדכן כמות של תשלום מראש.',
                ],
            ],
        ],
    ],

    'acl' => [
        'notify-customer'  => 'להודיע ללקוח',
        'preorder'         => 'הזמנה מראש',
    ],
];