<?php

namespace Webkul\PreOrder\Repositories;

use Webkul\Core\Eloquent\Repository;
use Webkul\PreOrder\Contracts\PreOrderItem;

class PreOrderItemRepository extends Repository
{
    /**
     * Specify Model class name.
     *
     * @return mixed
     */
    public function model()
    {
        return PreOrderItem::class;
    }

    /**
     * Check if is pre-order payment order.
     * 
     * @param integer $orderId
     * @return boolean
     */
    public function isPreOrderPaymentOrder($orderId)
    {
        return $this->resetScope()->scopeQuery(function ($query) use ($orderId) {
            return $query->leftJoin('order_items', 'pre_order_items.payment_order_item_id', '=', 'order_items.id')
                ->leftJoin('orders', 'order_items.order_id', '=', 'orders.id')
                ->where('orders.id', $orderId);
        })->count();
    }

    /**
     * Check if order have pre-order items.
     * 
     * @param integer $orderId
     * @return boolean
     */
    public function havePreOrderItems($orderId)
    {
        return $this->resetScope()->scopeQuery(function ($query) use ($orderId) {
            
            return $query->where('pre_order_items.order_id', $orderId);
        })->count();
    }

    /**
     * Check if pre-order can be complete.
     * 
     * @param OrderItem $orderItem
     * @return array
     */
    public function canBeComplete($orderItem)
    {
        $this->resetScope();

        $preOrderItem = $this->findOneByField('order_item_id', $orderItem->id);

        if (
            ! $preOrderItem 
            || $preOrderItem->status == 'completed'
        ) {
            return false;
        }

        if ($orderItem->type == 'configurable') {
            $isInStock = $orderItem->child->product && $this->getProductTotalQuantity($orderItem->child->product) >= $orderItem->qty_ordered ? true : false;
        } else {
            $isInStock = $orderItem->product && $this->getProductTotalQuantity($orderItem->product) >= $orderItem->qty_ordered ? true : false;
        }

        $condition = $orderItem->qty_invoiced == $orderItem->qty_ordered ? true : false;

        $result = [
            'isInStock' => $isInStock,
            'condition' => $condition,
        ];
        
        return $result;
    }

    /**
     * Get total quantity of product.
     * 
     * @param  \Webkul\Product\Models\Product $product
     * @return integer
     */
    public function getProductTotalQuantity($product)
    {
        $total = 0;

        $channelInventorySourceIds = core()->getCurrentChannel()
            ->inventory_sources()
            ->where('status', 1)
            ->pluck('id');

        foreach ($product->inventories as $inventory) {
            if (is_numeric($channelInventorySourceIds->search($inventory->inventory_source_id))) {
                $total += $inventory->qty;
            }
        }

        return $total;
    }
}