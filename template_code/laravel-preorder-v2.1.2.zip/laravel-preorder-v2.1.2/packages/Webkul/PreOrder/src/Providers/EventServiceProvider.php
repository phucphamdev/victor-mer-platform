<?php

namespace Webkul\PreOrder\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {   
        if (core()->getConfigData('pre_order.settings.general.enable_pre_order')) {
            Event::listen('bagisto.shop.products.short_description.before', function($viewRenderEventManager) {
                $viewRenderEventManager->addTemplate('pre_order::shop.default.products.preorder-info');
            });
        }
        
        /*
         * In stock notify Customers.
         */
        if ( core()->getConfigData('pre_order.settings.general.enable_auto_mail') ) {
            Event::listen('catalog.product.update.after', 'Webkul\PreOrder\Listeners\Order@stockNotifyCustomer');
        }

        Event::listen('bagisto.admin.layout.head', function($viewRenderEventManager) {
            $viewRenderEventManager->addTemplate('pre_order::components.style');
        });
        
        Event::listen('checkout.cart.add.before', 'Webkul\PreOrder\Listeners\Cart@cartItemAddBefore');

        Event::listen('checkout.cart.update.before', 'Webkul\PreOrder\Listeners\Cart@cartItemUpdateBefore');

        Event::listen('checkout.cart.add.after', 'Webkul\PreOrder\Listeners\Cart@cartItemAddAfter');

        Event::listen('checkout.order.save.after', 'Webkul\PreOrder\Listeners\Order@afterPlaceOrder');

        Event::listen('sales.invoice.save.after', 'Webkul\PreOrder\Listeners\Invoice@afterInvoice');

        Event::listen('sales.order.cancel.after', 'Webkul\PreOrder\Listeners\Order@afterCancelOrder');
    }
}