<?php

namespace Webkul\PreOrder\Providers;

use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\AliasLoader;
use Illuminate\Support\ServiceProvider;
use Webkul\Shipping\Facades\Shipping as ShippingFacade;
use Webkul\Checkout\Facades\Cart;
use Webkul\PreOrder\Shipping;

class PreOrderServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     */
    public function boot(): void
    {   
        $this->app->register(EventServiceProvider::class);

        $this->app->register(ModuleServiceProvider::class);

        Route::middleware('web')->group(__DIR__ . '/../Routes/admin-routes.php');
  
        Route::middleware('web')->group(__DIR__ . '/../Routes/front-routes.php');

        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');

        $this->loadTranslationsFrom(__DIR__ . '/../Resources/lang', 'pre_order');

        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'pre_order');

        $this->app->bind(
            \Webkul\CartRule\Helpers\CartRule::class, 
            \Webkul\PreOrder\Helpers\CartRule::class
        );

        $this->app->bind(
            \Webkul\Product\Helpers\ConfigurableOption::class,
            \Webkul\PreOrder\Helpers\ConfigurableOption::class
        );

        $this->app->bind(
            \Webkul\Product\Type\Configurable::class, 
            \Webkul\PreOrder\Type\Configurable::class
        );

        $this->app->bind(
            \Webkul\Product\Type\Simple::class,
            \Webkul\PreOrder\Type\Simple::class
        );

        $this->app->bind(
            \Webkul\Shop\Http\Controllers\API\CartController::class,
            \Webkul\PreOrder\Http\Controllers\Shop\API\CartController::class
        );

        $this->app->bind(
            \Webkul\Admin\Http\Controllers\Catalog\ProductController::class, 
            \Webkul\PreOrder\Http\Controllers\Admin\Catalog\ProductController::class
        );

        $this->app->bind(
            \Webkul\Shop\Http\Controllers\API\OnepageController::class,
            \Webkul\PreOrder\Http\Controllers\Shop\OnepageController::class
        );

        $this->app->bind(
            \Webkul\Shop\Http\Controllers\API\ProductController::class,
            \Webkul\PreOrder\Http\Controllers\Shop\ProductController::class
        );

        $this->publishes([
            __DIR__ . '/../Resources/views/shop/default/products' 
            => resource_path('views/vendor/shop/products'),

            __DIR__ . '/../Resources/views/shop/default/checkout/cart' 
            => resource_path('views/vendor/shop/checkout/cart'),

            __DIR__ . '/../Resources/views/shop/default/customers/account/' 
            => resource_path('themes/default/views/customers/account/'),

            __DIR__ . '/../Resources/views/components/products/card.blade.php' 
            => resource_path('views/vendor/shop/components/products/card.blade.php'),
   
            __DIR__ . '/../Resources/views/admin/configuration' 
            => resource_path('views/vendor/admin/configuration'),

            __DIR__ . '/../Resources/views/admin/sales/orders/view.blade.php' 
            => resource_path('views/vendor/admin/sales/orders/view.blade.php'),

            __DIR__ . '/../Resources/views/admin/catalog/products' 
            => resource_path('views/vendor/admin/catalog/products'),
        ]);

        if (core()->getConfigData('pre_order.settings.general.enable_pre_order')) {
            $this->mergeConfigFrom(
                dirname(__DIR__) .'/Config/admin-menu.php',
                'menu.admin'
            );
        }

        $this->publishAssets();
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->mergeConfigFrom(
            dirname(__DIR__) . '/Config/system.php', 'core'
        );

        $this->mergeConfigFrom(
            dirname(__DIR__) . '/Config/acl.php', 'acl'
        );

        $this->registerFacades();
    }

    /**
     * Register Bouncer as a singleton.
     *
     * @return void
     */
    protected function registerFacades()
    {
        $loader = AliasLoader::getInstance();

        $loader->alias('shipping', ShippingFacade::class);

        $this->app->singleton('shipping', function () {
            return new Shipping();
        });

        $loader->alias('cart', Cart::class);

        $this->app->singleton('cart', function () {
            return new Cart();
        });

        $this->app->bind('cart', 'Webkul\PreOrder\Cart');
    }

    /**
     * Publish the assets.
     *
     * @return void
     */
    protected function publishAssets()
    {
        $this->publishes([
            __DIR__ . '/../../publishable' => public_path('themes/preorder/')
        ], 'public');
    }
}