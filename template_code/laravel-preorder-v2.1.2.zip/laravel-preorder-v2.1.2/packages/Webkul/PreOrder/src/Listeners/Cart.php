<?php

namespace Webkul\PreOrder\Listeners;

use Cart as CartFacade;
use Webkul\PreOrder\Repositories\PreOrderItemRepository;
use Webkul\Product\Repositories\ProductRepository;

class Cart
{
    /**
     * Create a new customer event listener instance.
     *
     * @return void
     */
    public function __construct(
        protected PreOrderItemRepository $preOrderItemRepository,
        protected ProductRepository $productRepository,
    ) {
    }

    /**
     * Before product added to the cart.
     *
     * @param mixed $cartItem
     */
    public function cartItemAddBefore($productId)
    {
        $data = request()->all();

        if (! isset($data['pre_order_payment'])) {
            if ($this->haveCompletePreorderProduct()) {
                throw new \Exception(trans('pre_order::app.shop.checkout.cart.error.product-not-added'));
            }

            $product = $this->productRepository->find($productId);

            if ($product->type == 'configurable') {
                if (isset($data['selected_configurable_option'])) {
                    $product = $this->productRepository->find($data['selected_configurable_option']);
                } else {
                    return;
                }
            }

            if (
                $product->getTypeInstance()->totalQuantity() > 0 
                || ! $product->allow_preorder
            ) {
                return;
            }
          
            if (! isset($data['quantity'])) {
                $data['quantity'] = 1;
            }

            if ($cart = CartFacade::getCart()) {
                $cartItem = $cart->items()->where('product_id', $productId)->first();

                if ($cartItem) {
                    $quantity = $cartItem->quantity + $data['quantity'];
                } else {
                    $quantity = $data['quantity'];
                }
            } else {
                $quantity = $data['quantity'];
            }
            
            if (
                $product->preorder_qty 
                && $product->preorder_qty < $quantity
            ) {
                throw new \Exception(trans('pre_order::app.shop.checkout.cart.error.quantity-error'));
            }
        } else {
            if ($cart = CartFacade::getCart()) {
                $cartItem = $cart->items()->where('product_id', $productId)->count();

                if (count($cart->items()->get()) > 1 ) {
                    throw new \Exception(trans('pre_order::app.shop.checkout.cart.error.preorder-payment'));
                }
            }
        }
    }

    /**
     * Check if pre-order product.
     * 
     * @param int $productId
     * @return void
     */
    public function haveCompletePreorderProduct()
    {
        if (! $cart = CartFacade::getCart()) {
            return false;
        }

        foreach ($cart->items()->get() as $item) {
            if (isset($item->additional['pre_order_payment'])) {
                return true;
            }
        }

        return false;
    }

    /**
     * Before product update to the cart.
     *
     * @param CartItem $item
     * @return void
     */
    public function cartItemUpdateBefore($item)
    {
        if (isset($item->additional['pre_order_payment'])) {
            throw new \Exception(trans('pre_order::app.shop.checkout.cart.error.quantity-update-error'));
        }

        $quantities = request()->get('qty');

        $product = $item->type == 'configurable' ? $item->child->product_flat : $item->product_flat;

        if (
            $product 
            && ($product->totalQuantity() > 0 
            || ! $product->allow_preorder)
        ) {
            return;
        }

        if (
            $product 
            && ($product->preorder_qty 
            && $product->preorder_qty < $quantities[$item->id])
        ) {
            throw new \Exception(trans('pre_order::app.shop.checkout.cart.error.quantity-error'));
        }
    }

    /**
     * After product added to the cart.
     *
     * @param mixed $cartItem
     * @return void
     */
    public function cartItemAddAfter($cartItem)
    {
        if (core()->getConfigData('pre_order.settings.general.enable_pre_order')) {
            if (! request()->input('order_item_id')) {
                $product = $this->productRepository->find($cartItem->product_id);
                
                if ($product->type == 'configurable') {
                    if (isset($cartItem['additional']['selected_configurable_option'])) {
                        $product = $this->productRepository->find($cartItem['additional']['selected_configurable_option']);

                        $parentProduct = $this->productRepository->find($product->parent_id);

                        $product['allow_preorder'] = $parentProduct->allow_preorder;
                        
                        $product['preorder_qty'] = $parentProduct->preorder_qty;

                        $product['preorder_availability'] = $parentProduct->preorder_availability;
                    } else {
                        return;
                    }
                }

                if (
                    $product 
                    && $product->totalQuantity() > 0 
                    || ! $product->allow_preorder
                ) {
                    return;
                }
                
                if (core()->getConfigData('pre_order.settings.general.pre_order_type') == 'partial') {
                    if (is_null(core()->getConfigData('pre_order.settings.general.percent'))) {
                        $preOrderPercentage = 0;
                    } else {
                        $preOrderPercentage = core()->getConfigData('pre_order.settings.general.percent');
                    }
                } else {
                    $preOrderPercentage = 100;
                }

                $productPrice = ($product->getTypeInstance()->getMinimalPrice() * $preOrderPercentage) / 100;

                $cartItem->custom_price = $productPrice;

                $cartItem->save();
            } else {
                $preOrderItem = $this->preOrderItemRepository->findOneByField('order_item_id', request()->input('order_item_id'));
    
                $productPrice = $preOrderItem->base_remaining_amount / $preOrderItem->order_item->qty_ordered;

                $cartItem->custom_price = $productPrice;
    
                $cartItem->save();
            }
        }
    }
}