<?php

namespace Webkul\PreOrder\Listeners;

use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Webkul\PreOrder\Mail\ProductInStockNotification;
use Webkul\PreOrder\Repositories\PreOrderItemRepository;
use Webkul\Sales\Repositories\OrderItemRepository;

class Order
{
    /**
     * @var int
     */
    public const ZERO = 0;

    /**
     * @var int
     */
    public const ONE = 1;

    /**
     * Status completed.
     */
    public const STATUS_PENDING = 'pending';

    /**
     * Status processing.
     */
    public const STATUS_PROCESSING = 'processing';

    /**
     * Status completed.
     */
    public const STATUS_COMPLETE = 'complete';
    /**
     * Create a new Order event listener instance.
     *
     * @return void
     */
    public function __construct(
        protected OrderItemRepository $orderItemRepository,
        protected PreOrderItemRepository $preOrderItemRepository,
    ) {
    }

    /**
     * After sales order creation, add entry to pre_order_items order table.
     *
     * @param mixed $order
     * @return void
     */
    public function afterPlaceOrder($order)
    {
        foreach ($order->items()->get() as $item) {
            if (isset($item->additional['pre_order_payment'])) {
                $preOrderItem = $this->preOrderItemRepository->findOneByField('order_item_id', $item->additional['order_item_id']);

                $this->preOrderItemRepository->update([
                    'status'                => self::STATUS_PROCESSING,
                    'payment_order_item_id' => $item->id,
                ], $preOrderItem->id);
            } else {
                if ($item->type == 'configurable') {
                    if (
                        $item->child->product->getTypeInstance()->totalQuantity() > self::ONE
                        || ! $item->product->allow_preorder
                    ) {
                        continue;
                    }
                } else {
                    if (
                        $item->product->getTypeInstance()->totalQuantity() > self::ONE
                        || ! $item->product->allow_preorder
                    ) {
                        continue;
                    }
                }

                if (core()->getConfigData('pre_order.settings.general.pre_order_type') == 'partial') {
                    $preOrderType = 'partial';

                    if (is_null(core()->getConfigData('pre_order.settings.general.percent'))) {
                        $preOrderPercentage =  self::ZERO;
                    } else {
                        $preOrderPercentage = core()->getConfigData('pre_order.settings.general.percent');
                    }
                } else {
                    $preOrderType = self::STATUS_COMPLETE;

                    $preOrderPercentage = 100;
                }

                $productPrice = $item->type == 'configurable'
                    ? $item->child->product->getTypeInstance()->getMinimalPrice()
                    : $item->product->getTypeInstance()->getMinimalPrice();

                $this->preOrderItemRepository->create([
                    'preorder_type'         => $preOrderType,
                    'preorder_percent'      => $preOrderPercentage,
                    'status'                => self::STATUS_PENDING,
                    'paid_amount'           => $item->total,
                    'base_paid_amount'      => $item->base_total,
                    'base_remaining_amount' => ($productPrice * $item->qty_ordered) - $item->base_total,
                    'order_id'              => $order->id,
                    'order_item_id'         => $item->id,
                    'token'                 => str::random(32),
                ]);
            }
        }
    }

    /**
     * After order get canceled, pre-ordered repository should be update.
     *
     * @param mixed $order
     * @return void
     */
    public function afterCancelOrder($order)
    {
        foreach ($order->items()->get() as $item) {
            if ($item->product->product_flats[0]->allow_preorder){
                $preOrderItem = $this->preOrderItemRepository->findOneByField('order_item_id', $item->id);

                if ($preOrderItem) {
                    $this->preOrderItemRepository->update([
                        'status' => 'canceled',
                    ], $preOrderItem->id);
                }
            }
        }
    }

    /**
     * To get notifiable Orders Ids.
     *
     * @param mixed $product
     * @return void
     */
    public function stockNotifyCustomer($product)
    {
        if ($product->type == 'configurable') {
            foreach ($product->variants as $variant) {
                $inventory = $variant->inventories->first();
            }
        } else {
            $inventory = $product->inventories->first();
        }

        if (! $inventory) {
           return;
        }
        
        $qty = $inventory['qty'];
        
        $preOrders = $this->preOrderItemRepository->all();

        $preOrderItemIds = $preOrders->pluck('order_item_id')->all();

        $notifiableOrdersIds=[];

        foreach ($preOrderItemIds as $preOrderItemId) {
            $orderItem = $this->orderItemRepository->find($preOrderItemId);

            if (
                $orderItem->product_id  == $product->id 
                && $qty > self::ZERO
            ) {
                array_push($notifiableOrdersIds, $orderItem->order_id);
            }

            $isInvoiceGenerated = $orderItem->qty_invoiced == $orderItem->qty_ordered ? true : false;

            if ($isInvoiceGenerated) {
               $this->stockNotifyMailToCustomers($notifiableOrdersIds);
            }
        }
    }

    /**
     * To mail customers about in stock item.
     *
     * @param mixed $notifiableOrdersIds
     * @return void
     */
    public function stockNotifyMailToCustomers($notifiableOrdersIds)
    {
        foreach ($notifiableOrdersIds as $order_id) {
            $preOrderItem = $this->preOrderItemRepository->findOneByField('order_id', $order_id);

            try {
                Mail::send(new ProductInStockNotification($preOrderItem));

                $this->preOrderItemRepository->update([
                    'email_sent' => self::ONE,
                ], $preOrderItem->id);
            } catch (\Exception $e) {
            }
        }
    }
}