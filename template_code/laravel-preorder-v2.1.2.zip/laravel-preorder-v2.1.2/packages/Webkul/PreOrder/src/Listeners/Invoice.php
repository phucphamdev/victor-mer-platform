<?php

namespace Webkul\PreOrder\Listeners;

use Illuminate\Support\Facades\Mail;
use Webkul\PreOrder\Mail\ProductInStockNotification;
use Webkul\PreOrder\Repositories\PreOrderItemRepository;
use Webkul\Sales\Repositories\OrderRepository;

class Invoice
{
    /**
     * Status completed.
     */
    public const STATUS_COMPLETED = 'completed';
    
    /**
     * Status processing.
     */
    public const STATUS_PROCESSING = 'processing';

    /**
     * Create a new Order event listener instance.
     *
     * @return void
     */
    public function __construct(
        protected OrderRepository $orderRepository,
        protected PreOrderItemRepository $preOrderItemRepository,
    ) {
    }

    /**
     * After sales invoice creation, update Pre-order status.
     *
     * @param mixed $invoice
     * @return void
     */
    public function afterInvoice($invoice)
    {                
        foreach ($invoice->items()->get() as $item) {
            if (isset($item->additional['pre_order_payment'])) {
                $preOrderItem = $this->preOrderItemRepository->findOneByField('order_item_id', $item->additional['order_item_id']);

                $this->preOrderItemRepository->update([
                    'status' => self::STATUS_COMPLETED,
                ], $preOrderItem->id);

                $this->orderRepository->update([
                    'status' => self::STATUS_COMPLETED,
                ], $preOrderItem->order_id);
            } else {
                $preOrderItem = $this->preOrderItemRepository->findOneByField('order_item_id', $item->order_item_id);

                if (
                    ! $preOrderItem 
                    || ! $preOrderItem->base_remaining_amount
                ) {
                    return;
                }

                $this->preOrderItemRepository->update([
                    'status' => self::STATUS_PROCESSING,
                ], $preOrderItem->id);

                try {
                    Mail::send(new ProductInStockNotification($preOrderItem));
                } catch (\Exception $e) {
                    \Log::info('EmailVerificationNotification Error');
                    
                    report($e);
                }
            }
        }
    }
}