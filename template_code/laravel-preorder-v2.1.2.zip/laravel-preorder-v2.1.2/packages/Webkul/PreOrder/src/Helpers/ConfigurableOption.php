<?php

namespace Webkul\PreOrder\Helpers;

use Webkul\Product\Helpers\ConfigurableOption as BaseConfigurableOptions;

class ConfigurableOption extends BaseConfigurableOptions
{
    /**
     * @var int
     */
    public const ONE = 1;

    /**
     * Returns the allowed variants.
     *
     * @param \Webkul\Product\Contracts\Product $product
     * @return array
     */
    public function getAllowedVariants($product)
    {
        if (count($this->allowedVariants)) {
            return $this->allowedVariants;
        }

        $variantCollection = $product->variants()
            ->with([
                'parent',
                'attribute_values',
                'price_indices',
                'inventory_indices',
                'images',
                'videos',
            ])
            ->get();

        foreach ($variantCollection as $variant) {
           /**
            * Bagisto PreOrder Check.
            */
            if (
                core()->getConfigData('pre_order.settings.general.enable_pre_order')
                && $product->allow_preorder
                && $variant->totalQuantity() < self::ONE
            ) {
                $this->allowedVariants[] = $variant;
            } else {
                if ($variant->isSaleable()) {
                    $this->allowedVariants[] = $variant;
                }
            }
        }

        return $this->allowedVariants;
    }
}