<?php

namespace Webkul\PreOrder\Helpers;

use Carbon\Carbon;
use Webkul\Product\Repositories\ProductRepository;

class Product
{
    /**
     * ProductRepository object
     *
     * @var variant
    */
    protected $variants;
    
    /**
     * Create a new customer event listener instance.
     *
     * @return void
     */
    public function __construct(
        protected ProductRepository $productRepository,
    ) {
    }

    /**
     * Return Pre-order variants.
     *
     * @param Product $product
     * @return array
     */
    public function getPreOrderVariants($product)
    {
        $config = [];

        foreach ($product->variants as $variant) {
            if (
                $variant->totalQuantity() < 1 
                && $variant->allow_preorder
            ) {
                $config[$variant->product_id] = [
                    'preorder_qty'      => $variant->preorder_qty,
                    'availability_text' => $variant->preorder_availability && Carbon::parse($variant->preorder_availability) > Carbon::now()
                        ? trans('pre_order::app.shop.customers.account.orders.available-on', [
                                'date' => core()->formatDate(Carbon::parse($variant->preorder_availability), 'F d, Y')
                            ])
                        : null,
                ];
            }
        }

        return $config;
    }
}