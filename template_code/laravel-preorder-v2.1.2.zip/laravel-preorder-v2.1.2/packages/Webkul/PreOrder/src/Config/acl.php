<?php

return [
    [
        'key'   => 'pre_order',
        'name'  => 'pre_order::app.acl.pre-order',
        'route' => 'admin.pre_order.pre_orders.index',
        'sort'  =>  3,
    ], [
        'key'   => 'pre_order.notify_customer',
        'name'  => 'pre_order::app.acl.notify-customer',
        'route' => 'admin.pre_order.pre_orders.notify_customer',
        'sort'  =>  1,
    ],
];