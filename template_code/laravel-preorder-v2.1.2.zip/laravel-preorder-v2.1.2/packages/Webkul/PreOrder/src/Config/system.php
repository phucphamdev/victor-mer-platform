<?php

return [
    [
        'key'  => 'pre_order',
        'name' => 'pre_order::app.admin.configuration.title',
        'info' => 'pre_order::app.admin.configuration.info',
        'sort' => 1,
    ], [
        'key'  => 'pre_order.settings',
        'name' => 'pre_order::app.admin.configuration.settings.title',
        'info' => 'pre_order::app.admin.configuration.settings.info',
        'icon' => 'preorder-configuration.svg',
        'sort' => 1,
    ], [
        'key'    => 'pre_order.settings.general',
        'name'   => 'pre_order::app.admin.configuration.system.general.title',
        'info'   => 'pre_order::app.admin.configuration.system.general.info',
        'sort'   => 1,
        'fields' => [
            [
                'name'          => 'enable_pre_order',
                'title'         => 'pre_order::app.admin.configuration.system.enable-pre-order',
                'type'          => 'boolean',
                'channel_based' => true,
            ], [
                'name'          => 'pre_order_type',
                'title'         => 'pre_order::app.admin.configuration.system.pre-order-type',
                'type'          => 'select',
                'validation'    => 'required',
                'options'       => [
                    [
                        'title' => 'pre_order::app.admin.configuration.system.partial-payment',
                        'value' => 'partial',
                    ], [
                        'title' => 'pre_order::app.admin.configuration.system.complete-payment',
                        'value' => 'complete',
                    ],
                ],
                'channel_based' => true,
            ], [
                'name'          => 'percent',
                'title'         => 'pre_order::app.admin.configuration.system.pre-order-percent',
                'type'          => 'text',
                'validation'    => 'between:0.01,99.9|required',
                'channel_based' => true,
            ], [
                'name'          => 'message',
                'title'         => 'pre_order::app.admin.configuration.system.message',
                'type'          => 'textarea',
                'validation'    => 'max:150',
                'locale_based'  => true,
                'channel_based' => true,
            ], [
                'name'          => 'enable_auto_mail',
                'title'         => 'pre_order::app.admin.configuration.system.enable-automatic-mail',
                'type'          => 'boolean',
                'channel_based' => true,
            ],
        ],
    ],
];