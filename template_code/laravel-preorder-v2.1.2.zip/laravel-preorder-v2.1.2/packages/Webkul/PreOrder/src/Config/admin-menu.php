<?php

return [
    [
        'key'   => 'pre_order',
        'name'  => 'pre_order::app.admin.layouts.pre-order',
        'route' => 'admin.pre_order.pre_orders.index',
        'sort'  =>  3,
        'icon'  => 'preorder-icon',
    ],
];