<?php

namespace Webkul\PreOrder\Models;

use Konekt\Concord\Proxies\ModelProxy;

class PreOrderItemProxy extends ModelProxy
{
}