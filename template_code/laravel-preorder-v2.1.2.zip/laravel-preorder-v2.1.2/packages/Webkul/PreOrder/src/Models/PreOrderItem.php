<?php

namespace Webkul\PreOrder\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Webkul\PreOrder\Contracts\PreOrderItem as PreOrderItemContract;
use Webkul\Sales\Models\OrderProxy;
use Webkul\Sales\Models\OrderItemProxy;

class PreOrderItem extends Model implements PreOrderItemContract
{   
    public $timestamps = false;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'preorder_type', 
        'preorder_percent', 
        'status', 
        'email_sent', 
        'paid_amount', 
        'base_paid_amount', 
        'base_remaining_amount', 
        'order_id', 
        'order_item_id', 
        'payment_order_item_id', 
        'token',
    ];

    /**
     * Status labels.
     *
     * @var array
     */
    protected $statusLabel = [
        'pending'    => 'Pending',
        'processing' => 'Processing',
        'completed'  => 'Completed',
    ];
    
    /**
     * Type labels.
     *
     * @var array
     */
    protected $typeLabel = [
        'partial'  => 'Partial Payment',
        'complete' => 'Complete Payment',
    ];

    /**
     * Get the order record associated with the pre order item.
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(OrderProxy::modelClass(), 'order_id');
    }

    /**
     * Get the order item record associated with the pre order item.
     */
    public function order_item(): BelongsTo
    {
        return $this->belongsTo(OrderItemProxy::modelClass(), 'order_id');
    }

    /**
     * Get the order item record associated with the pre order item.
     */
    public function payment_order_item(): BelongsTo
    {
        return $this->belongsTo(OrderItemProxy::modelClass(), 'payment_order_item_id');
    }

    /**
     * Returns the status label from status code.
     * 
     * @return $this
     */
    public function getStatusLabelAttribute()
    {
        return $this->statusLabel[$this->status];
    }

    /**
     * Returns the type label from status code.
     * 
     * @return $this
     */
    public function getTypeLabelAttribute()
    {
        return $this->typeLabel[$this->preorder_type];
    }
}