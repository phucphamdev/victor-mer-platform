<?php

namespace Webkul\PreOrder\DataGrids\Admin;

use Illuminate\Support\Facades\DB;
use Webkul\DataGrid\DataGrid;
use Webkul\PreOrder\Contracts\PreOrderItem;

class PreOrder extends DataGrid
{
    /**
     * Prepare query builder.
     *
     * @return \Illuminate\Database\Query\Builder
     */
    public function prepareQueryBuilder()
    {
        $queryBuilder = DB::table('pre_order_items')
            ->leftJoin('order_items', 'pre_order_items.order_item_id', '=', 'order_items.id')
            ->leftJoin('orders', 'pre_order_items.order_id', '=', 'orders.id')
            ->leftJoin('order_items as payment_order_items', 'pre_order_items.payment_order_item_id', '=', 'payment_order_items.id')
            ->addSelect('pre_order_items.id', 'pre_order_items.order_id', 'order_items.name as product_name', 'orders.customer_email', 'order_item_id', 'preorder_type', 'pre_order_items.status', 'base_paid_amount', 'pre_order_items.email_sent', 'base_remaining_amount', 'payment_order_items.order_id as payment_order_id')
            ->addSelect(DB::raw('CONCAT(orders.customer_first_name, " ", orders.customer_last_name) as customer_name'));

        $this->addFilter('id', 'pre_order_items.id');
        $this->addFilter('status', 'pre_order_items.status');
        $this->addFilter('order_id', 'pre_order_items.order_id');
        $this->addFilter('payment_order_id', 'payment_order_items.order_id');
        $this->addFilter('product_name', 'order_items.name');
        $this->addFilter('customer_name', DB::raw('CONCAT(orders.customer_first_name, " ", orders.customer_last_name)'));

        return $queryBuilder;
    }

    /**
     * Add Columns.
     *
     * @return void
     */
    public function prepareColumns()
    {
        $this->addColumn([
            'index'      => 'id',
            'label'      => trans('pre_order::app.admin.datagrid.id'),
            'type'       => 'integer',
            'searchable' => false,
            'sortable'   => true,
            'filterable' => true,
        ]);

        $this->addColumn([
            'index'      => 'order_id',
            'label'      => trans('pre_order::app.admin.datagrid.order-id'),
            'type'       => 'integer',
            'searchable' => false,
            'sortable'   => true,
            'filterable' => true,
            'closure'    => function ($row) {
                return '<a href="' . route('admin.sales.orders.view', $row->order_id) . '">' . $row->order_id . '</a>';
            },
        ]);

        $this->addColumn([
            'index'       => 'payment_order_id',
            'label'       => trans('pre_order::app.admin.datagrid.payment-order-id'),
            'type'        => 'integer',
            'searchable'  => false,
            'sortable'    => false,
            'filterable'  => true,
            'closure'     => function ($row) {
                if ($row->payment_order_id) {
                    return '<a href="' . route('admin.sales.orders.view', $row->payment_order_id) . '">' . $row->payment_order_id . '</a>';
                }
               
                return trans('pre_order::app.admin.datagrid.not-applicable');
            },
        ]);

        $this->addColumn([
            'index'      => 'product_name',
            'label'      => trans('pre_order::app.admin.datagrid.product-name'),
            'type'       => 'string',
            'searchable' => true,
            'sortable'   => true,
            'filterable' => true,
        ]);

        $this->addColumn([
            'index'      => 'customer_name',
            'label'      => trans('pre_order::app.admin.datagrid.customer-name'),
            'type'       => 'string',
            'searchable' => true,
            'sortable'   => true,
            'filterable' => true,
        ]);

        $this->addColumn([
            'index'      => 'customer_email',
            'label'      => trans('pre_order::app.admin.datagrid.customer-email'),
            'type'       => 'string',
            'searchable' => true,
            'sortable'   => true,
            'filterable' => true,
        ]);

        $this->addColumn([
            'index'      => 'base_paid_amount',
            'label'      => trans('pre_order::app.admin.datagrid.paid-amount'),
            'type'       => 'price',
            'searchable' => false,
            'sortable'   => true,
            'filterable' => true,
        ]);

        $this->addColumn([
            'index'      => 'base_remaining_amount',
            'label'      => trans('pre_order::app.admin.datagrid.remaining-amount'),
            'type'       => 'integer',
            'searchable' => false,
            'sortable'   => true,
            'filterable' => true,
            'closure'    => function ($row) {
                if ($row->status === PreOrderItem::STATUS_COMPLETED) {
                    return core()->formatBasePrice('0');
                } 

                return $row->base_remaining_amount;
            }
        ]);

        $this->addColumn([
            'index'      => 'preorder_type',
            'label'      => trans('pre_order::app.admin.datagrid.pre-order-type'),
            'type'       => 'dropdown',
            'options'    => [
                'type' => 'basic',

                'params' => [
                    'options' => [
                        [
                            'label'  => trans('pre_order::app.admin.datagrid.partial-payment'),
                            'value'  => 'partial',
                        ], [
                            'label'  => trans('pre_order::app.admin.datagrid.complete-payment'),
                            'value'  => 'complete',
                        ],
                    ],
                ],
            ],
            'sortable'   => true,
            'searchable' => false,
            'filterable' => true,
            'closure'    => function ($row) {
                if ($row->preorder_type == PreOrderItem::TYPE_PARTIAL) {
                    return trans('pre_order::app.admin.datagrid.partial-payment');
                }

                return trans('pre_order::app.admin.datagrid.complete-payment');
            },
        ]);

        $this->addColumn([
            'index'   => 'status',
            'label'   => trans('pre_order::app.admin.datagrid.status'),
            'type'    => 'dropdown',
            'options' => [
                'type' => 'basic',

                'params' => [
                    'options' => [
                        [
                            'label' => trans('shop::app.customers.account.orders.status.options.processing'),
                            'value' => 'processing',
                        ], [
                            'label' => trans('shop::app.customers.account.orders.status.options.completed'),
                            'value' => 'completed',
                        ], [
                            'label' => trans('shop::app.customers.account.orders.status.options.canceled'),
                            'value' => 'canceled',
                        ], [
                            'label' => trans('shop::app.customers.account.orders.status.options.closed'),
                            'value' => 'closed',
                        ], [
                            'label' => trans('shop::app.customers.account.orders.status.options.pending'),
                            'value' => 'pending',
                        ], [
                            'label' => trans('shop::app.customers.account.orders.status.options.pending-payment'),
                            'value' => 'pending_payment',
                        ], [
                            'label' => trans('shop::app.customers.account.orders.status.options.fraud'),
                            'value' => 'fraud',
                        ],
                    ],
                ],
            ],
            'sortable'   => true,
            'searchable' => false,
            'filterable' => true,
            'closure'    => function ($row) {
                switch ($row->status) {
                    case PreOrderItem::STATUS_PENDING:
                      return '<p class="label-pending">' . trans('pre_order::app.admin.datagrid.pending') . '</p>';

                    case PreOrderItem::STATUS_COMPLETED:
                      return '<p class="label-closed">' . trans('pre_order::app.admin.datagrid.completed') . '</p>';

                   default :
                      return '<p class="label-active">' . trans('pre_order::app.admin.datagrid.processing') . '</p>';
                }
            },
        ]);

        $this->addColumn([
            'index'      => 'email_sent',
            'label'      => trans('pre_order::app.admin.datagrid.email-sent'),
            'type'       => 'boolean',
            'searchable' => false,
            'sortable'   => true,
            'filterable' => true,
            'closure'    => function($row) {
                if ($row->email_sent) { 
                    return trans('pre_order::app.admin.datagrid.yes');
                }    

                return trans('pre_order::app.admin.datagrid.no');
            },
        ]);
    }

    /**
     * Prepare mass actions.
     *
     * @return void
     */
    public function prepareMassActions()
    {
        if (bouncer()->hasPermission('pre_order.notify_customer')) {
            $this->addMassAction([
                'type'   => 'delete',
                'title'  => trans('pre_order::app.admin.datagrid.notify-customer'),
                'method' => 'POST',
                'url'    => route('admin.pre_order.pre_orders.notify_customer'),
            ]);   
        }
    }
}