<?php

namespace Webkul\PreOrder;

use Illuminate\Support\Facades\Event;
use Webkul\Checkout\Cart as BaseCart;

class Cart extends BaseCart
{
    /**
     * Add items in a cart with some cart and item details.
     *
     * @param int $productId
     * @param array $data
     * @return \Webkul\Checkout\Contracts\Cart|string|array
     * @throws Exception
     */
    public function addProduct($productId, $data)
    {
        Event::dispatch('checkout.cart.add.before', $productId);

        $cart = $this->getCart();

        if (! $cart) {
            $cart = $this->create($data);
        }

        if (! $cart) {
            return ['warning' => trans('shop::app.checkout.cart.item.error-add')];
        }

        $product = $this->productRepository->find($productId);

        if (! $product->status) {
            return ['info' => trans('shop::app.checkout.cart.item.inactive-add')];
        }

        $cartProducts = $product->getTypeInstance()->prepareForCart($data);

        if (is_string($cartProducts)) {
            if (! $cart->all_items->count()) {
                $this->removeCart($cart);
            } else {
                $this->collectTotals();
            }

            throw new \Exception($cartProducts);
        } else {
            $parentCartItem = null;

            foreach ($cartProducts as $cartProduct) {
                $cartItem = $this->getItemByProduct($cartProduct, $data);

                if (isset($cartProduct['parent_id'])) {
                    $cartProduct['parent_id'] = $parentCartItem->id;
                }

                if (! $cartItem) {
                    $cartItem = $this->cartItemRepository->create(array_merge($cartProduct, ['cart_id' => $cart->id]));
                } else {
                    if (
                        isset($cartProduct['parent_id'])
                        && $cartItem->parent_id !== $parentCartItem->id
                    ) {
                        $cartItem = $this->cartItemRepository->create(array_merge($cartProduct, [
                            'cart_id' => $cart->id,
                        ]));
                    } else {
                        $cartItem = $this->cartItemRepository->update($cartProduct, $cartItem->id);
                    }
                }

                if (! $parentCartItem) {
                    $parentCartItem = $cartItem;
                }
            }
        }

        if (core()->getConfigData('pre_order.settings.general.enable_pre_order')) {
            Event::dispatch('checkout.cart.add.after', $parentCartItem);
        } else {
            Event::dispatch('checkout.cart.add.after', $cart);
        }

        $this->collectTotals();

        return $this->getCart();
    }

    /**
     * Update cart items information.
     *
     * @param  array  $data
     * @return bool|void|Exception
     */
    public function updateItems($data)
    {
        foreach ($data['qty'] as $itemId => $quantity) {
            $item = $this->cartItemRepository->find($itemId);

            $product = $this->productRepository->findOneByField('id', $item->product_id);

            if (! $item) {
                continue;
            }

            if (! $item->product->status) {
                throw new \Exception(__('shop::app.checkout.cart.item.inactive'));
            }

            if ($quantity <= 0) {
                $this->removeItem($itemId);

                throw new \Exception(__('shop::app.checkout.cart.illegal'));
            }

            $item->quantity = $quantity;

            if (
                $product->allow_preorder
                && $product->preorder_qty < $quantity

            ) {
                throw new \Exception(trans('shop::app.checkout.cart.inventory-warning'));
            }

            if (! $product->allow_preorder) {
                if (! $this->isItemHaveQuantity($item)) {
                    throw new \Exception(trans('shop::app.checkout.cart.inventory-warning'));
                }
            }

            Event::dispatch('checkout.cart.update.before', $item);

            $this->cartItemRepository->update([
                'quantity'          => $quantity,
                'total'             => core()->convertPrice($item->price * $quantity),
                'base_total'        => $item->price * $quantity,
                'total_weight'      => $item->weight * $quantity,
                'base_total_weight' => $item->weight * $quantity,
            ], $itemId);

            Event::dispatch('checkout.cart.update.after', $item);
        }

        $this->collectTotals();

        return true;
    }

    /**
     * Checks if cart has any error.
     *
     * @return bool
     */
    public function hasError(): bool
    {
        $cartItems = $this->getCart()->items;

        foreach ($cartItems as $cartItem) {
            $product = $this->productRepository->findOneByField('id', $cartItem->product_id);

           $allowPreorder = $product->allow_preorder;
        }

        if (! $allowPreorder) {
            if (
                ! $this->getCart()
                || ! $this->isItemsHaveSufficientQuantity()
            ) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * To validate if the product information is changed by admin and the items have been added to the cart before it.
     *
     * @return bool
     */
    public function validateItems(): bool
    {
        $cart = $this->getCart();

        if (! $cart) {
            return false;
        }

        if (! $cart->items->count()) {
            $this->removeCart($cart);

            return false;
        }

        $isInvalid = false;

        foreach ($cart->items as $item) {
            $validationResult = $item->getTypeInstance()->validateCartItem($item);

            if ($validationResult->isItemInactive()) {
                $this->removeItem($item->id);

                $isInvalid = true;

                session()->flash('info', __('shop::app.checkout.cart.inactive'));
            } else {
                $price = ! is_null($item->custom_price) ? $item->custom_price : $item->base_price;

                /**
                 * Handles exchange rate for cart item price.
                 */
                $this->cartItemRepository->update([
                    'price'      => $item->price,
                    'base_price' => $item->base_price,
                    'total'      => core()->convertPrice($price * $item->quantity),
                    'base_total' => $price * $item->quantity,
                ], $item->id);
            }

            $isInvalid |= $validationResult->isCartInvalid();
        }

        return ! $isInvalid;
    }
}