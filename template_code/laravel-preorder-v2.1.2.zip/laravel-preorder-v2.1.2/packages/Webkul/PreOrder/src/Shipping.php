<?php

namespace Webkul\PreOrder;

use Illuminate\Support\Facades\Config;
use Webkul\Checkout\Facades\Cart;
use Webkul\Shipping\Shipping as BaseShipping;

class Shipping extends BaseShipping
{
    /**
     * Rates
     *
     * @var array
     */
    protected $rates = [];

    /**
     * Collects rate from available shipping methods.
     */
    public function collectRates(): array
    {
        if (! Cart::getCart()) {
            return false;
        }

        $this->removeAllShippingRates();

        $ratesList = [];

        foreach (Config::get('carriers') as $shippingMethod) {
            $object = new $shippingMethod['class'];

            if ($rates = $object->calculate()) {
                if (is_array($rates)) {
                    $ratesList[] = $rates;
                } else {
                    $ratesList[] = [$rates];
                }
            }
        }

        $this->rates = array_merge(...$ratesList);

        $this->saveAllShippingRates();

        return [
            'shippingMethods' => $this->getGroupedAllShippingRates(),
        ];
    }
}