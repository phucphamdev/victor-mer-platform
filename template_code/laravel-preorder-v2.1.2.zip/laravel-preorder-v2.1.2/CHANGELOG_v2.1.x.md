# CHANGELOG for v2.1.2

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v2.1.2(27th of Nov, 2024)**

* [Enhancement] When order place via Partial Payment || Refund button should visible on the partial payment order details page untill admin create the shipment on the complete payment order details page.

* [Enhancement] When order place via Partial Payment || Shipment button should not visible on the partial payment order details page.It should be visible on order details page where complete order payment is done.

* [bug] "Preorder" button is not enable on the web front if preorder qty field is empty for the respective product.

* [bug] When disable the status of preorder from the configure section, Preorder button sholud be shown on the product view page and product card page.

* [bug] Getting the translation issue for the notify customer button on the preorder section.

* [bug] The configuration section for preorders is not compatible with support for multiple locales.

* [bug] Getting the UI issue on the customer order details.

* [bug] After partial payment, the customer is refunded the product after the product is in stock, the complete preorder button should be disabled.

* [bug] Order is completed without create shipment by admin if customer place order via partial payment.

* [bug] If product is out of stock and preorder module is disable then "Add to Cart" button is working on homepage, catalog, search, wishlist and compare page.


## **v2.0.0(08th of December, 2023)** - *Compatible*
* [bug] Unable to create the Product from admin panel.

* [bug] After partial payment, the customer is refunded the product after the product is in stock, the complete preorder button should be disabled.

* [bug] When paid the partial payment after the customer refunded the product then the customer order page, found the UI and translation issue on the front end.

* [bug] When applying the preorder functionality for the main configuration page then the preorder is not working.

* [bug] All the shipping methods should be shown on during partial payment but after getting the mail during the complete payment time only the free delivery methods should be shown on the checkout page.

* [bug] During the partial payment if apply the flat rate shipping method and after the complete payment the free delivery shipping method should be shown.

* [bug] Getting the view Exception error, when creating different locales RTL and clicking the velocity logo.

* [bug] When disabling the preorder status it is also shown in the Create Product section on the admin panel.

* [bug] After getting the mail, opened the mail and clicked the link button then redirected to the order page but on the order page, we have completed the payment for only a single product but both products are in stock.

* [bug] When the product is in stock then the send the mail for only single product.

* [bug] Found the issue, When using the cart rule with partial payment type then the cart discount is applied according to the actual amount.

* [bug] Customers pay the partial & remaining payment of the product then the status is shown as processing on the preorder section.

* [bug] Please add one more column on the preorder section on the admin panel.

* [bug] Guests are not allowed to check out any simple/configurable product.

* [bug] Getting the unnecessary value is shown on the mini cart when removing the product from the mini cart.

* [bug] Missing the add to cart button on the product view page when not applying the preorder functionality.

* [bug] Found the responsive issue in the mobile view.

* [bug] Getting the UI issue on front pages in the front end.

* [enhancement] When using the partial payment method then the Preorder Percent field should be mandatory.

* [enhancement] Please update the filter of the preorder section on admin the admin panel.

* [enhancement] Please add the validation, When using the partial payment functionality then the Preorder Percent value is always greater than 0.

## **v1.1.1(28th of May, 2020)** - *Release*

* [Enhancement] Now compatable with new release Bagisto v0.1.7.

* [bug] Size of Preorder button should be equal to Add to Cart, in default theme.

* [bug] Getting exception while using filter for order type column in orders(sales-orders).

* [bug] In filter option "Preorder type" to select option should be Complete or partial.

* [bug] Back date should not be accepted in product availability

* [bug] Not able to add preorder product in cart from category page in velocity theme

* [bug] Customer should not redirect to admin panel from In stock notification of product email, if order for that product has already been placed.

* [bug] Link available in email redirect to admin preorder section, if preorder is already completed for that product.

* [bug] Partial payment not work in case of configurable product.

* [bug] Correct the preorder button length for configurable product.

* [bug] Not getting preorder button for products.

* [bug] When customer click on complete preorder payment then product should add in cart only with the remaining amount that need to pay.

* [bug] Add to cart button should not display with preorder.

* [bug] Ui issue.

* [bug] Getting incorrect remaining amount to pay.

* [bug] Getting exception if click on category.

* [bug] Preorder should not work for downloadable product.

* [bug] Not getting Preorder button to complete preorder in customer account.

* [bug] Signed in customer not able to complete preorder from email link as well as from customer order section.

* [bug] Remove preorder button from grouped product.

* [bug] Remove preorder from Bundle Product.

* [bug] Preorder partial payment is not working.

* [bug] Getting issue when click on complete Preorder link in email for guest customer.

* [bug] Customer not received mail for stock notification.

* [bug] Not getting preorder button for Preorder products.

* [bug] Getting exception on frontend.

## **v0.1.1(28th of June, 2019)** - *Release*

* [bug] Able to add preorder item multiple times in cart to complete payment.

* [bug] Getting exception when filtering Preorder from Order Id.

* [bug] Issue with multicurrency. If partial payment is selected for product then also in cart total product price is showing.

* [bug] Getting exception if customer try to complete preorder if any other product is already added in cart.

* [bug] Getting exception if user click on mail notification to complete the preorder payment.

* [bug] Getting exception when Applying filter through "Id" and "Status".

* [bug] Getting incorrect amount to pay in case of Partial Payment.

* [bug] If from Configuration Preorder type is selected as complete than also preorder percent is showing on Category and home page.

* [bug] Not getting a button of preorder in case of configurable product.

* [bug] Availability date of Preorder is not showing on front-end.

* [bug] Not getting an option to pay the remaining amount of order after generating an invoice.

## **v0.1.0(13th of Jube, 2019)** - *Release*


* [feature] Buyer can pre-order only out of stock products.

* [feature] Works with Simple and Configurable products.

* [feature] Set a custom message to display on the preorder product page.

* [feature] Admin can set preorder status and availability date.

* [feature] Using this module customer can pay full or partial payment.

* [feature] Customers can receive an email notification when a product is in-stock.

* [feature] Guest users can also use the pre-order feature and place the orders.

* [feature] The admin can display Free Preorder Note to customers.

* [feature] Multi-Lingual support/All language working including RTL.

* [feature] The code is fully open & you can customize it according to your need.