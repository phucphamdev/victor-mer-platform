### 1. Introduction:

Bagisto Pre-order extension allows the customer to pre-order products which are not yet available at the online store. With the help of Bagisto Pre-order extension, the customer or the guest user can place orders for out of stock products. The admin can set the whether the customer will pay a full or partial amount of the product.

It packs in lots of demanding features that allows your business to scale in no time:

* Buyer can pre-order only out of stock products.
* Works with Simple and Configurable products.
* Set a custom message to display on the Pre-order product page.
* Admin can set Pre-order status and availability date.
* Using this module customer can pay full or partial payment.
* Customers can receive an email notification when a product is in-stock.
* Guest users can also use the pre-order feature and place the orders.
* The admin can display Free Pre-order Note to customers.
* Multi-Lingual support/All language working including RTL.
* The code is fully open & you can customize it according to your need.


### 2. Requirements:

* **Bagisto**: 2.1.2


### 3. Installation:

* Unzip the respective extension zip and then merge "packages" and "public" folder into project root directory.
* Goto config/app.php file and add following line under 'providers'

~~~
Webkul\PreOrder\Providers\PreOrderServiceProvider::class
~~~

* Goto composer.json file and add following line under 'psr-4'

~~~
"Webkul\\PreOrder\\": "packages/Webkul/PreOrder/src"
~~~

* In the config/bagisto-vite.php file, add the following line under the 'viters' section:

~~~
'preorder' => [
        'hot_file'                 => 'preorder-default-vite.hot',
        'build_directory'          => 'themes/preorder/build',
        'package_assets_directory' => 'src/Resources/assets',
    ],
~~~

* Run these commands below to complete the setup

~~~
composer dump-autoload
~~~

~~~
php artisan migrate
~~~

~~~
php artisan db:seed --class=Webkul\\PreOrder\\Database\\Seeders\\DatabaseSeeder
~~~

~~~
php artisan vendor:publish --provider="Webkul\PreOrder\Providers\PreOrderServiceProvider" --force
~~~

~~~
php artisan optimize:clear
~~~

~~~
> That's it, now just execute the project on your specified domain.
~~~
