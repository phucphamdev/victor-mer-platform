<?php

return [
    [
        'key'           => 'settings.push_notification',
        'name'          => 'api::app.menu.push-notification',
        'route'         => 'api.notification.index',
        'sort'          => 9,
    ],
];