<?php

namespace Webkul\API\Models;

use Konekt\Concord\Proxies\ModelProxy;

class PushNotificationProxy extends ModelProxy
{
}
