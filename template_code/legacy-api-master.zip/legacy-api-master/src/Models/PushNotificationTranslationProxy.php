<?php

namespace Webkul\API\Models;

use Konekt\Concord\Proxies\ModelProxy;

class PushNotificationTranslationProxy extends ModelProxy
{
}
