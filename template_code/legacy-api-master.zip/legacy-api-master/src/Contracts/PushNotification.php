<?php

namespace Webkul\API\Contracts;

interface PushNotification
{
}
