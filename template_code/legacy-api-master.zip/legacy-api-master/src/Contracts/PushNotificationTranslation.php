<?php

namespace Webkul\API\Contracts;

interface PushNotificationTranslation
{
}
