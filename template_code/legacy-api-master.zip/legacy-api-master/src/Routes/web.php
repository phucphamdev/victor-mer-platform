<?php

/**
 * API routes.
 */
require 'api-routes.php';

/**
 * FCM routes.
 */
require 'fcm-routes.php';
