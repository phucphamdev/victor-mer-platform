# CHANGELOG for v1.x.x

This changelog consists of the bug & security fixes and new features included in the releases listed below.

* [enhancement] - Customer delete account API added.

* [enhancement] - Push Notification section added at the admin end.

## **v1.0.0 (19th of Nov, 2021)** - *Release*

* [fixed] - Wishlist icon is not dark after user visit second time on same catalog page.

* [fixed] - Showing wrong date,month,year and time on review page.

* [fixed] - Guest user is not able to place order.

* [fixed] - User will be able to set new password by entering wrong current password on profile page.