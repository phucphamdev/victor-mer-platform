<?php

return [
    'b2b-suite' => [
        'hot_file'                 => 'b2b-suite-vite.hot',
        'build_directory'          => 'themes/b2b-suite/build',
        'package_assets_directory' => 'src/Resources/assets',
    ],
];
