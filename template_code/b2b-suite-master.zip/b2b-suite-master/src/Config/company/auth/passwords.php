<?php

return [
    'companies' => [
        'provider' => 'companies',
        'table'    => 'company_password_resets',
        'expire'   => 60,
        'throttle' => 60,
    ],
];
