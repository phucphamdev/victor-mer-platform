<?php

return [
    'company' => [
        'driver'   => 'session',
        'provider' => 'companies',
    ],
];
