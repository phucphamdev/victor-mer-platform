<?php

return [
    'companies' => [
        'driver' => 'eloquent',
        'model'  => Webkul\B2BSuite\Models\Company::class,
    ],
];
