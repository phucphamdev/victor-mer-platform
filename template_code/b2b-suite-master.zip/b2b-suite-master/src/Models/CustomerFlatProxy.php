<?php

namespace Webkul\B2BSuite\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CustomerFlatProxy extends ModelProxy {}
