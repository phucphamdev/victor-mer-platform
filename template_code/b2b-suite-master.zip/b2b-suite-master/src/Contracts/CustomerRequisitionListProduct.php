<?php

namespace Webkul\B2BSuite\Contracts;

interface CustomerRequisitionListProduct {}
