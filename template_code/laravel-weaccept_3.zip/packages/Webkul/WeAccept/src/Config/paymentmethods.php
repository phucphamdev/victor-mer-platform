<?php

return [
    'weaccept' => [
        'code' => 'weaccept',
        'title' => 'WeAccept',
        'description' => 'WeAccept Payments',
        'class' => 'Webkul\WeAccept\Payment\WeAcceptPayment',
        'active' => true,
        'sort' => 5
    ]
];
