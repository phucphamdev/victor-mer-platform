<?php

namespace Webkul\WeAccept\Contracts;

interface WeAccept
{
    
}
