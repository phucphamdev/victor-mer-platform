<?php

namespace Webkul\WeAccept\Models;

use Konekt\Concord\Proxies\ModelProxy;

class WeAcceptProxy extends ModelProxy
{

}
