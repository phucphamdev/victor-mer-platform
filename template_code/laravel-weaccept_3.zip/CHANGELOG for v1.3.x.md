# CHANGELOG for v1.3.x

## **v1.3.1(26th of May, 2021)** - *Release*

* [feature] Added Refund Feature, Now admin can refund the payment from their dashboard.


## **v0.1.3(9th of March, 2021)** - Release

* [feature] Compatible with Bagisto v1.3.0 & v1.3.1

## **v0.1.2(29th of September, 2020)** - Release

* [feature] Compatible with Bagisto v1.2.0

## **v0.1.1(15th of August, 2019)** - Release

* [feature] customers can pay through WeAccept payment gateway.
