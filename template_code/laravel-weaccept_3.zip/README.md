### 1. Introduction:

WeAccept Payments simplifies online payment & acceptance for businesses with an easy, quick & secure experience for people paying on websites & apps.

### 2. Requirements:

* **Bagisto**: v01.3.0 to v1.3.1

### 3. Installation:

* Unzip the respective extension zip and then merge "packages" folder into project root directory.
* Goto config/app.php file and add following line under 'providers'.

~~~
Webkul\WeAccept\Providers\WeAcceptServiceProvider::class
~~~

* Goto composer.json file and add following line under 'psr-4'

~~~
"Webkul\\WeAccept\\": "packages/Webkul/WeAccept/src"
~~~

* WeAccept Merchent Account's URL

    * Transaction response callback

    ~~~
    https://yourdomain.com/weaccept/paymob_txn_response_callback
    ~~~

* Run these commands below to complete the setup

~~~
composer dump-autoload
~~~

~~~
php artisan migrate
~~~

~~~
php artisan route:cache
~~~

~~~
php artisan config:cache
~~~

> That's it, now just execute the project on your specified domain.
