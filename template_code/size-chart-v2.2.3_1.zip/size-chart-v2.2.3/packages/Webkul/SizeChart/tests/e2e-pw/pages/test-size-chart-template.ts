
import { enableToggles } from "./toggleSetting";
import { createSizeChartTemplate } from "./template-creation";
import { loginAsAdmin } from "../utils/adminsetup";

export async function testSizeChartFeature(page) {

   /**
    * Navigate to size chart configuration
    */
    await loginAsAdmin(page);
    await page.getByRole('link', { name: 'Configure' }).click();
    await page.getByRole('link', { name: 'Size Chart Manage size charts' }).click();

   /**
    * Enable toggles
    */
    const { isSizeChartEnabled, isCustomSizeChartEnabled } = await enableToggles(page);

   /**
    * Proceed only if both toggles are enabled
    */
    if (isSizeChartEnabled && isCustomSizeChartEnabled) {
        await createSizeChartTemplate(page);
    } else {
        console.warn("Toggles were not enabled — skipping template and product creation.");
    }
}
