export async function shipAddress(page){
  await page.getByRole('textbox', { name: 'Company Name' }).fill('test');
  await page.getByRole('textbox', { name: 'First Name' }).fill('test');
  await page.getByRole('textbox', { name: 'Last Name' }).fill('test1');
  await page.getByRole('textbox', { name: 'email@example.com' }).fill('test@examle.com');
  await page.getByRole('textbox', { name: 'Street Address' }).fill('test');
  await page.locator('select[name="billing.country"]').selectOption('IN');
  await page.locator('select[name="billing.state"]').selectOption('DL');
  await page.getByRole('textbox', { name: 'City' }).fill('test');
  await page.getByRole('textbox', { name: 'Zip/Postcode' }).fill('202020');
  await page.getByRole('textbox', { name: 'Telephone' }).fill('1234567890');
  await page.getByRole('button', { name: 'Save' }).click();
}