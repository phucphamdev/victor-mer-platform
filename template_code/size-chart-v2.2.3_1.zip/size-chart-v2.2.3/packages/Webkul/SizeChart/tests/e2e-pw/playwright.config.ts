// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

/**
 * Playwright Configuration for Bagisto Size Chart Module
 */
export default defineConfig({
  timeout: 60 * 1000,
  expect: {
    timeout: 20 * 1000,
  },
  testDir: './tests', // Change this path if your tests are elsewhere
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',

  use: {
    baseURL: 'http://127.0.0.1:8000', // Update if different port is used
    trace: 'on-first-retry',
    screenshot: 'on',
    video: 'on',
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
