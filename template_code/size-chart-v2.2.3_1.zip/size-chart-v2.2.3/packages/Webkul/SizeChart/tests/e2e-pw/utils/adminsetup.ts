export async function loginAsAdmin(page){
  await page.goto('admin/login');
  await page.getByRole('textbox', { name: 'Email Address' }).fill('admin@example.com');
  await page.getByRole('textbox', { name: 'Password' }).fill('admin123');
  await page.getByRole('button', { name: 'Sign In' }).click();
}

export async function loginAsCustomer(page){
  await page.goto('customer/login');
  await page.getByRole('textbox', { name: 'Email' }).click();
  await page.getByRole('textbox', { name: 'Email' }).fill('cust@example.com');
  await page.getByRole('textbox', { name: 'Password' }).click();
  await page.getByRole('textbox', { name: 'Password' }).fill('admin123');
  await page.getByRole('button', { name: 'Sign In' }).click();
}

export async function createCustomerAccount(page){
  await page.goto('',{ waitUntil: 'networkidle' });
  await page.getByRole('button', { name: 'Profile' }).click();
  await page.getByRole('link', { name: 'Sign Up' }).click();
  await page.waitForTimeout(2000);
  await page.getByRole('textbox', { name: 'First Name' }).fill('customer');
  await page.getByRole('textbox', { name: 'Last Name' }).fill('one');
  await page.getByRole('textbox', { name: 'Email' }).fill('cust@example.com');
  await page.getByRole('textbox', { name: 'Password', exact: true }).fill('admin123');
  await page.getByRole('textbox', { name: 'Confirm Password' }).fill('admin123');
  await page.getByRole('button', { name: 'Register' }).click();
}