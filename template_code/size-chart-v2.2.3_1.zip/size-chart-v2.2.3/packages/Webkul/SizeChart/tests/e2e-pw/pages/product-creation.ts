import {expect} from "@playwright/test";
import { loginAsAdmin } from "../utils/adminsetup";
import  {fillInTinymce}  from "../utils/tinymc";

const randomID = Date.now();
function getRandomNumber(min: number, max: number): string {
  return Math.floor(Math.random() * (max - min + 1) + min).toString();
}

export async function createProduct(page) {
  await loginAsAdmin(page);
  
  /**
   * Navigate to Products
   */
  await page.waitForLoadState();
  await page.getByRole('link', { name: 'Catalog' }).click();

  /**
   * Start creating a new product
   */
  await page.getByRole('button', { name: 'Create Product' }).click();
  await expect(page.getByText('Create New Product')).toBeVisible({ timeout: 5000 });

  /**
   * Fill basic product info
   */
  await page.locator('select[name="type"]').selectOption('Simple');
  await page.locator('select[name="attribute_family_id"]').selectOption('1');

  const skuCode = `SP${randomID}`;
  await page.locator('input[name="sku"]').fill(skuCode);
  await page.getByRole('button', { name: 'Save Product' }).click();
  await page.waitForLoadState('networkidle');
  /**
   * Fill detailed product info
   */
  await page.waitForTimeout(5000);
  const productName = `MEN T-SHIRT ${randomID}`;
  await page.waitForTimeout(5000);
  await page.locator('#name').fill(productName);
  await page.locator('#color').selectOption('1');
  await page.locator('#size').selectOption('7');

  /**
   * Description and metadata
   */
  await fillInTinymce(page,"#short_description_ifr", "Test short description");
  await fillInTinymce(page,"#description_ifr", "Test description");
  await page.locator('#meta_title').fill('This is Meta Title');
  await page.locator('#meta_keywords').fill('Meta Keywords');
  await page.locator('#meta_description').fill('Meta Description');

  /**
   * Pricing and weight
   */
  const price = getRandomNumber(100, 5000);
  const cost = (0.2 * +price).toFixed(2);
  const special = (0.1 * +cost).toFixed(2);
  const weight = getRandomNumber(10, 100);

  await page.locator('#price').fill(price);
  await page.locator('#cost').fill(cost);
  await page.locator('#special_price').fill(special);
  await page.locator('#weight').fill(weight);

  /**
   * Enable switches (toggle inputs)
   */
  await page.locator('.relative > label').first().click();
  await page.locator('div:nth-child(3) > .relative > label').click();
  await page.locator('div:nth-child(4) > .relative > label').click();
  await page.locator('div:nth-child(5) > .relative > label').click();
  await page.locator('div:nth-child(6) > .relative > label').click();
  await page.locator('input[name="inventories\\[1\\]"]').fill('22');

  /**
   * Select the most recently created size chart template
   */
  const options = await page.locator('#sizechart_id option');
  const count = await options.count();
  if (count > 0) {
      const lastOptionValue = await options.nth(count - 1).getAttribute('value');
      await page.locator('#sizechart_id').selectOption(lastOptionValue);
  } else {
      console.warn('No options available in #sizechart_id dropdown');
  }

  await page.getByRole('button', { name: 'Save Product' }).click();

  return productName;
}
