import { test, expect } from '@playwright/test';
import { createProduct } from '../pages/product-creation';
import { testSizeChartFeature } from '../pages/test-size-chart-template';
import { addCustomSizedProductToCart } from '../pages/add-to-cart';
import { createCustomerAccount, loginAsAdmin, loginAsCustomer} from '../utils/adminsetup';
import { shipAddress } from '../utils/address';
import path from 'path'; 
import fs from 'fs';

test.describe("From sizechart creation to customer checkout using sizechart", () => {

 /**
  * Variable to store the product name
  */
  let productName: string = '';
  test("Admin can add size chart templates and create product with it", async ({page}) => {
        await testSizeChartFeature(page);
        console.log("✅");
  });

  test('Create Product', async ({ page }) => {
    productName = await createProduct(page);
  
    if (!productName) {
      throw new Error('Failed to create product');
    }
  
    // Write the product name to a JSON file
    const productData = { name: productName };
  
    // Ensure the directory exists
    const path = 'test-data/product-data.json';
    fs.mkdirSync('test-data', { recursive: true });
  
    fs.writeFileSync(path, JSON.stringify(productData));
    console.log("✅");
  });
  
  test('Create and View Size Chart', async ({ page }) => {
      await createCustomerAccount(page);
      await loginAsCustomer(page);
      await addCustomSizedProductToCart(page);
      console.log("✅");
  });
  
  test('Checkout the product', async ({ page }) => {
 /**
  * Login using stored credentials
  */
  loginAsCustomer(page);
  await page.waitForTimeout(3000);

  await page.getByRole("button", { name: "Shopping Cart" }).click();
  await page.waitForTimeout(2000);

  const checkoutButton = page.getByRole("link", { name: "Continue to Checkout" });
  if (!await checkoutButton.isVisible().catch(() => false)) {
    await addCustomSizedProductToCart(page);
    await page.getByRole('button', { name: 'Add To Cart' }).click();
    await page.waitForTimeout(3000);
    await page.getByRole("button", { name: "Shopping Cart" }).click();
    await page.waitForTimeout(1000);
    await page.getByRole("link", { name: "Continue to Checkout" }).click();
  } else {
    await page.getByRole("link", { name: "Continue to Checkout" }).click();
  }

 /**
  * Proceed to checkout steps
  */

  await shipAddress(page)

  await page.getByRole("button", { name: "Proceed" }).click();
  await page.locator("div:nth-child(2) > .icon-radio-unselect").click();
  await page.locator(
    "div:nth-child(3) > .border-b > div > .z-10 > .flex > div:nth-child(2) > .icon-radio-unselect"
  ).click();

  await page.getByRole("button", { name: "Place Order" }).click();
  await page.waitForTimeout(4000);
  // await expect(page.getByRole("link", { name: "Continue Shopping" })).toBeVisible();
  console.log("✅");
});

  test('Sales Dashboard', async ({ page }) => {
    loginAsAdmin(page);
    // await page.getByRole("link", { name: "Sales" }).click();
    await page.click('//a[contains(., "Sales")]');
    await page.locator('span.icon-sort-right.cursor-pointer').first().click();
    await expect(page.getByText("Your Own Sizes")).toBeVisible();
    console.log("✅");
  });

  /**
   * Cleanup after all tests are done
   */
  test.afterAll(() => {
    const productDataPath = path.resolve('test-data', 'product-data.json');
    const loginDataPath = path.resolve('test-data', 'customer-login.json');
    try {
      if (fs.existsSync(productDataPath)) {
        fs.unlinkSync(productDataPath);
        console.log("Product data file deleted.");
      }
    } catch (error) {
      console.error('Error deleting data files:', error);
    }
  });
});
