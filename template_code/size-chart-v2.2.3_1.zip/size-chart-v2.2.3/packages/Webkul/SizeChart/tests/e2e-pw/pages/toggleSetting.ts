import { Page, expect } from '@playwright/test';

export async function enableToggles(page: Page) {
  const toggles = [
    { label: 'Enable Size Chart' },
    { label: 'Enable Custom Size Chart' },
    { label: 'Show Acknowledgement Note' }
  ];

  let acknowledgementEnabled = false;

  for (const { label } of toggles) {
    const checkbox = page.getByLabel(label);
    const visualToggle = checkbox.locator('xpath=following-sibling::div[1]');

    if (!await checkbox.isChecked()) {
      await visualToggle.click();
      await expect(checkbox).toBeChecked({ timeout: 3000 });
    }

    if (label === 'Show Acknowledgement Note') acknowledgementEnabled = true;
  }

  /**
   * Fill acknowledgement note if enabled
   */
  if (acknowledgementEnabled) {
    const noteField = page.locator('textarea[name="sizechart[settings][size-chart][acknowledgement_note]"]');
    await expect(noteField).toBeVisible({ timeout: 5000 });
    await noteField.fill('Example acknowledgement text goes here.');
  }

  /**
   * Save changes
   */
  await page.getByRole('button', { name: /Save Configuration/i }).click();
  await expect(page.getByText(/Configuration saved successfully/i)).toBeVisible({ timeout: 10000 });

  return {
    isSizeChartEnabled: true,
    isCustomSizeChartEnabled: true,
  };
}
