import fs from 'fs';
import path from 'path';
import { expect } from '@playwright/test';

export async function addCustomSizedProductToCart(adminPage) {
  const filePath = path.resolve(process.cwd(), 'test-data', 'product-data.json');

  if (!fs.existsSync(filePath)) {
    throw new Error(`File not found at: ${filePath}`);
  }

  const productData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  const productName = productData.name;

  await adminPage.locator('input[aria-label="Search products here"]').fill(productName);
  await adminPage.press('body', 'Enter');
  await adminPage.getByText(productName, { exact: true }).click();
  await adminPage.getByRole('link', { name: productName }).click();

  const sizeChartButton = adminPage.getByText('View Size Chart');
  await expect(sizeChartButton).toBeVisible();
  await sizeChartButton.click();

  await adminPage.getByRole('button', { name: 'Custom Size Chart' }).click();
  await adminPage.getByPlaceholder('SHOULDER').fill('30');
  await adminPage.getByPlaceholder('LENGTH').fill('28');
  await adminPage.getByPlaceholder('WIDTH').fill('35');

  await adminPage.locator('#main label').click();
  await adminPage.getByRole('button', { name: 'Save' }).click();
  await adminPage.waitForTimeout(2000);

  await adminPage.getByRole('button', { name: 'Add To Cart' }).click();
  await adminPage.waitForTimeout(3000);
}