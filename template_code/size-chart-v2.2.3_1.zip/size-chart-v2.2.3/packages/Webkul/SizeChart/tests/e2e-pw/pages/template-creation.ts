import { expect } from '@playwright/test';

export async function createSizeChartTemplate(adminPage) {

 /**
  * Navigate to Size Chart section
  */
  await adminPage.getByRole('link', { name: 'Size Chart' }).click();
  await expect(adminPage).toHaveURL(/admin\/sizechart/);
  await expect(adminPage.getByText(/Size Chart Templates/i)).toBeVisible();

 /**
  *  Go to template creation page
  */
  await adminPage.getByRole('link', { name: 'Add Template' }).click();
  await expect(adminPage).toHaveURL(/admin\/sizechart\/create/);
  await adminPage.waitForTimeout(3000);

 /**
  * Fill basic template info
  */
  const uniqueCode = `MTS-${Date.now()}`;
  function getRandomNumber(digits: number): number {
    const min = Math.pow(10, digits - 1);
    const max = Math.pow(10, digits) - 1;
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  
  const twoDigit = getRandomNumber(2);  // e.g. 23
  const fourDigit = getRandomNumber(4); // e.g. 4829
  
  const templateName = `Men's ${twoDigit} T-Shirt ${fourDigit}`;

  await adminPage.locator('input[name="template_name"]').fill(templateName);
  await adminPage.locator('input[name="template_code"]').fill(uniqueCode);
  await adminPage.locator('input[name="size_units"]').fill('S,M,L');
  await adminPage.locator('input[name="measurements"]').fill('Shoulder,Length,Width');

 /**
  * Proceed to matrix input section
  */
  await adminPage.getByRole('button', { name: /Continue/i }).click();
  await expect(adminPage.locator('table input').first()).toBeVisible();

 /**
  *  Fill all matrix inputs with sample valuev
  */
  await adminPage.locator('input[name="measurements\\[S\\]\\[Shoulder\\]"]').fill('10');
  await adminPage.locator('input[name="measurements\\[S\\]\\[Length\\]"]').fill('9');
  await adminPage.locator('input[name="measurements\\[S\\]\\[Width\\]"]').fill('8');
  await adminPage.locator('input[name="measurements\\[M\\]\\[Shoulder\\]"]').fill('8');
  await adminPage.locator('input[name="measurements\\[M\\]\\[Length\\]"]').fill('10');
  await adminPage.locator('input[name="measurements\\[M\\]\\[Width\\]"]').fill('7');
  await adminPage.locator('input[name="measurements\\[L\\]\\[Shoulder\\]"]').fill('6');
  await adminPage.locator('input[name="measurements\\[L\\]\\[Length\\]"]').fill('8');
  await adminPage.locator('input[name="measurements\\[L\\]\\[Width\\]"]').fill('9');;
  
 /**
  * Save the template
  */
  await adminPage.getByRole('button', { name: /Save Template/i }).click();
  await expect(adminPage.getByText(/Template Successfully Created/i)).toBeVisible({ timeout: 10000 });
}

