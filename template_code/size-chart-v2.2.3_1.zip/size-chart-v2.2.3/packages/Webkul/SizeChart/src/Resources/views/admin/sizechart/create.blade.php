<x-admin::layouts>
    <x-slot:title>
        @lang('sizechart::app.sizechart.template.add-temp-title')
    </x-slot:title>

    <x-admin::form
        :action="route('sizechart.admin.index.store')"
        enctype="multipart/form-data"
    >
        
    <div class="flex items-center justify-between gap-4 max-sm:flex-wrap">
        <p class="text-xl font-bold text-gray-800 dark:text-white">
            @lang('sizechart::app.sizechart.template.add-temp-title')
        </p>

        <div class="flex items-center gap-x-2.5">
            <!-- Back Button -->
            <a
                href="{{ route('sizechart.admin.index') }}"
                class="transparent-button hover:bg-gray-200 dark:text-white dark:hover:bg-gray-800"
            >
                @lang('admin::app.catalog.categories.create.back-btn')
            </a>
           
        </div>
    </div>

    <div class="mt-3.5 flex gap-2.5 max-xl:flex-wrap">
        <div class="flex flex-col flex-1 gap-2 max-xl:flex-auto">
        
            {!! view_render_event('bagisto.admin.sizechart.template.create_simple_template.before') !!}
            
               <div class="p-4 bg-white rounded box-shadow dark:bg-gray-900">
                    <div class="grid grid-cols-2 gap-4">
                        <x-admin::form.control-group>
                            <x-admin::form.control-group.label class="required">
                                @lang('sizechart::app.sizechart.template.template-name')
                            </x-admin::form.control-group.label>

                            <x-admin::form.control-group.control
                                type="text"
                                name="template_name"
                                :value="old('template_name')"
                                id="template_name"
                                rules="required"
                                :label="trans('sizechart::app.sizechart.template.template-name')"
                                :placeholder="trans('sizechart::app.sizechart.template.template-name')"
                                :tinymce="true"
                            >
                            </x-admin::form.control-group.control>

                            <x-admin::form.control-group.error
                                control-name="template_name"
                            >
                            </x-admin::form.control-group.error>
                        </x-admin::form.control-group>
                
                        <x-admin::form.control-group>
                            <x-admin::form.control-group.label class="required">
                                @lang('sizechart::app.sizechart.template.template-code')
                            </x-admin::form.control-group.label>

                            <x-admin::form.control-group.control
                                type="text"
                                name="template_code"
                                :value="old('template_code')"
                                id="template_code"
                                rules="required"
                                :label="trans('sizechart::app.sizechart.template.template-code')"
                                :placeholder="trans('sizechart::app.sizechart.template.template-code')"
                                :tinymce="true"
                            >
                            </x-admin::form.control-group.control>

                            <x-admin::form.control-group.error
                                control-name="template_code"
                            >
                            </x-admin::form.control-group.error>
                        </x-admin::form.control-group>

                        <x-admin::form.control-group>
                            <x-admin::form.control-group.label>
                                @lang('sizechart::app.sizechart.template.template-image')
                            </x-admin::form.control-group.label>
                            
                            <div class="hidden">
                                <x-admin::media.images
                                    name="image"
                                >
                                </x-admin::media.images>
                            </div>
        
                            <v-media-images
                                name="image"
                            >
                            </v-media-images>
                        </x-admin::form.control-group>
                    </div>
                    
                <add-size-chart> </add-size-chart>
            </div>
            
            {!! view_render_event('bagisto.admin.sizechart.template.create_simple_template.after') !!}
        </div> 
    </div>
    </x-admin::form>

    @pushOnce('scripts')
        <script 
            type="text/x-template" 
            id="add-size-chart-template"
        >
        <div v-if="!showSizeChart">
                <!-- Size Units Input -->
                <x-admin::form.control-group.label class="required">
                    @lang('sizechart::app.sizechart.template.size-units')
                </x-admin::form.control-group.label>

                <x-admin::form.control-group.control
                    type="text"
                    name="size_units"
                    v-model="sizeUnits"
                    rules="required"
                    :label="trans('sizechart::app.sizechart.template.size-units')"
                    :placeholder="trans('sizechart::app.sizechart.template.body-size-units')"
                >
                </x-admin::form.control-group.control>

                <x-admin::form.control-group.error
                    control-name="size_units"
                >
                </x-admin::form.control-group.error>
                <p class="mb-4 text-xs text-gray-600 dark:text-gray-300">
                    @lang('sizechart::app.sizechart.template.size-units-info')
                </p>
                
                <!-- Measurements Input -->
                <x-admin::form.control-group.label class="required">
                    @lang('sizechart::app.sizechart.template.measurements')
                </x-admin::form.control-group.label>

                <x-admin::form.control-group.control
                    type="text"
                    name="measurements"
                    v-model="measurementFields"
                    rules="required"
                    :label="trans('sizechart::app.sizechart.template.measurements')"
                    :placeholder="trans('sizechart::app.sizechart.template.body-measurements')"
                >
                </x-admin::form.control-group.control>

                <x-admin::form.control-group.error
                    control-name="measurements"
                >
                </x-admin::form.control-group.error>
                <p class="mb-4 text-xs text-gray-600 dark:text-gray-300">
                    @lang('sizechart::app.sizechart.template.body-measurements-info')
                </p>

            <div class="mb-2 mt-2.5">
                <button 
                    type="button" 
                    class="primary-button" 
                    @click="createSizeChart()"
                >
                    @lang('sizechart::app.sizechart.template.continue')
                </button>
            </div>
        </div>

        <div v-else>
            <div class="overflow-x-auto">
                <x-admin::table class="w-full min-w-[0px] text-left text-sm overflow-x-auto">
                    <x-admin::table.thead class="text-sm font-medium dark:bg-gray-800">
                        <x-admin::table.thead.tr>
                            <x-admin::table.th>
                                @lang('sizechart::app.sizechart.template.size')
                            </x-admin::table.th>
                        
                            <template v-for="field in fields" :key="field">
                                <x-admin::table.th>
                                    @{{ field }}
                                </x-admin::table.th>
                            </template>
                        </x-admin::table.thead.tr>
                    </x-admin::table.thead>
                    
                    <x-admin::table.tbody class="bg-white dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:border-gray-400 dark:focus:border-gray-400">
                        <template v-for="(size, index) in sizes" :key="size">
                            <x-admin::table.tbody.tr>
                                <x-admin::table.td class="dark:text-gray-300">
                                    @{{ size }}
                                </x-admin::table.td>
                                
                                <template v-for="field in fields" :key="field">
                                    <x-admin::table.td>
                                        <input 
                                            type="text"
                                            :name="'measurements[' + size + '][' + field + ']'"
                                            class="w-full min-h-[39px] py-2 px-3 border rounded-md text-sm text-gray-600 dark:text-gray-300 transition-all hover:border-gray-400 focus:border-gray-400 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-300 dark:hover:border-gray-400 dark:focus:border-gray-400"
                                        />
                                    </x-admin::table.td>
                                </template>
                            </x-admin::table.tbody.tr>
                        </template>
                    </x-admin::table.tbody>
                </x-admin::table>
            </div>
            
            <div class="flex items-center gap-x-2.5">
                <button 
                    type="button" 
                    class="primary-button" 
                    @click="backToInput()"
                >
                    @lang('sizechart::app.sizechart.template.back')
                </button>
            
                <button 
                    type="submit"
                    class="primary-button"
                >
                    @lang('sizechart::app.sizechart.template.save-btn-title')
                </button>
            </div>
        </div>
    </script>

    <script type="module">
        app.component('add-size-chart', {
            template: '#add-size-chart-template',

            data() {
                return {
                    sizeUnits: '',
                    measurementFields: '',
                    showSizeChart: false,
                    fields: [],
                    sizes: []
                };
            },

            methods: {
                createSizeChart() {
                    if (this.measurementFields.length && this.sizeUnits.length) {
                        this.fields = this.measurementFields.split(',').map(field => field.trim());
                        this.sizes = this.sizeUnits.split(',').map(size => size.trim());
                        this.showSizeChart = true;
                    } else {
                        this.$emitter.emit('add-flash', { 
                            type: 'warning', 
                            message: "@lang('sizechart::app.sizechart.template.empty-fields')" 
                        });
                    }
                },

                backToInput() {
                    this.showSizeChart = false;
                    this.fields = [];
                    this.sizes = [];
                }
            }
        });
    </script>
@endPushOnce

</x-admin::layouts>