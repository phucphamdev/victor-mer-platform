<x-admin::layouts>
    <x-slot:title>
        @lang('sizechart::app.sizechart.template.title')
    </x-slot:title>

    <div class="flex items-center justify-between gap-4 max-sm:flex-wrap">
        <p class="text-xl font-bold text-gray-800 dark:text-white">
            @lang('sizechart::app.sizechart.template.title')
        </p>

        <div class="flex items-center gap-x-2.5">
            <a
                href="{{ route('sizechart.admin.index.create') }}"
                class="primary-button"
            >
                @lang('sizechart::app.sizechart.template.add-simple')
            </a>
        </div>
    </div>

    {!! view_render_event('bagisto.admin.sizechart.template.list.before') !!}

    <x-admin::datagrid src="{{ route('sizechart.admin.index') }}"></x-admin::datagrid>

    {!! view_render_event('bagisto.admin.sizechart.template.list.after') !!}

</x-admin::layouts>