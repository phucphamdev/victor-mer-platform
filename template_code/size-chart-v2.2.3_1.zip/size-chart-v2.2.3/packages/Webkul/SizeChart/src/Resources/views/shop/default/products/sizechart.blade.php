@inject('customSizeChartRepository', 'Webkul\SizeChart\Repositories\CustomSizeChartRepository')

@php
    $sizeChart = app('Webkul\SizeChart\Http\Controllers\Shop\SizeChartController');

    if ($product->parent_id) {
        $productIds = $product->parent_id;
    } else {
        $productIds = $product->id;
    }

    $template = $sizeChart->getSizeChart($productIds);
 
    $measurements = [];

    if ($template) {
        $options = $sizeChart->getOptions($template->id);

        $columns = [];
        
        foreach ($options as $size => $data) {
            $row = ['SIZE' => $size];
            
            foreach ($data as $type => $value) {
                $row[strtoupper($type)] = $value;
                $columns[strtoupper($type)] = true;
            }
            $measurements[] = $row;
        }

        $columns = array_merge(['SIZE'], array_keys($columns));
    }

    $customer = auth()->guard('customer')->user();
    
    $customSizeData = [];

    if ($customer && $template) {
        $customSizeEntry = $customSizeChartRepository
            ->where('customer_id', $customer->id)
            ->where('product_id', $productIds)
            ->where('template_id', $template->id)
            ->whereNull('order_id')
            ->first();

        if ($customSizeEntry) {
            $decodedData = json_decode($customSizeEntry->size_attributes, true) ?? [];
    
            foreach ($decodedData as $key => $value) {
                $customSizeData[strtoupper($key)] = $value;
            }
        }
    }
    
    $showAcknowledgementNote = core()->getConfigData('sizechart.settings.size-chart.show_acknowledgement_note');
@endphp

@if ($template)
    <div class="mt-4">
        <v-size-chart 
            :size-data="{{ json_encode($measurements) }}" 
            :columns="{{ json_encode($columns) }}"
            :image-url="{{ json_encode($template->image_url ?? '') }}"
            :custom-size-data="{{ json_encode($customSizeData) }}"
            :is-logged-in="{{ auth()->guard('customer')->check() ? 'true' : 'false' }}"
            :show-acknowledgement="{{ $showAcknowledgementNote ? 'true' : 'false' }}"
            login-url="{{ route('shop.customer.session.index') }}"
        >
        </v-size-chart>
    </div>

    @pushOnce('scripts')
        <script type="text/x-template" id="v-size-chart-template">
            <span
                class="font-semibold cursor-pointer text-navyBlue"
                @click="$refs.sizechartModel.open()"
            >
                <span>
                    @lang('sizechart::app.sizechart.template.view-size-chart')
                </span>
            </span>

            <x-shop::modal ref="sizechartModel">
                <x-slot:header class="!p-0 ">
                    <span class="text-xl font-medium text-gray-800"></span>
                </x-slot:header>

                <x-slot:content>
                    <div class="flex flex-row justify-center gap-8 bg-zinc-100 max-sm:gap-1.5">
                        <button 
                            type="button"
                            class="px-6 py-3 font-medium focus:outline-none"
                            :class="activeTab === 'size-chart' ? 'text-black border-b-2 border-navyBlue' : 'text-gray-500 hover:text-gray-700'"
                            @click="activeTab = 'size-chart'"
                        >
                            {{ $template->template_name }}
                        </button>

                        @if (core()->getConfigData('sizechart.settings.size-chart.custom_size_chart_status'))
                            <button 
                                type="button"
                                class="px-6 py-3 font-medium focus:outline-none"
                                :class="activeTab === 'custom-size-chart' ? 'text-black border-b-2 border-navyBlue' : 'text-gray-500 hover:text-gray-700'"
                                @click="activeTab = 'custom-size-chart'"
                            >
                                @lang('sizechart::app.sizechart.template.custom-size-chart')
                            </button>
                        @endif
                        
                    </div>

                    <!-- Tab content -->
                    <div class="flex-1 overflow-y-auto">
                        <!-- Size Chart Tab -->
                        <div v-show="activeTab === 'size-chart'" class="p-5">
                            <div class="flex flex-col gap-8 md:flex-row">
                                <div v-if="imageUrl" class="flex items-center justify-center w-full md:w-1/2">
                                    <img 
                                        :src="imageUrl" 
                                        alt="Size Chart"
                                        width="150"
                                        height="150"
                                    >
                                </div>
                                
                                <div class="w-full md:w-1/2">
                                    <div class="overflow-x-auto">
                                        <table class="w-full border-collapse">
                                            <thead>
                                                <tr>
                                                    <th v-for="column in columns" :key="column" class="p-2 text-sm font-semibold text-center border border-gray-300 bg-gray-50">
                                                        @{{ column }}
                                                    </th>
                                                </tr>
                                            </thead>
                                            
                                            <tbody>
                                                <tr v-for="(row, index) in sizeData" :key="index">
                                                    <td class="p-2 font-medium text-center border border-gray-300">
                                                       @{{ row['SIZE'] }}
                                                    </td>
                                            
                                                    <td v-for="column in columns.slice(1)" :key="column" class="p-2 text-center border border-gray-300">
                                                        @{{ row[column] || '-' }}
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- How to Measure Tab -->
                        <div v-show="activeTab === 'custom-size-chart'" class="p-5">
                            <div v-if="!isLoggedIn" class="font-medium text-center text-red-500">
                                <p>@lang('sizechart::app.sizechart.template.custom-login')</p>
                                
                                <a :href="loginUrl" class="text-blue-600 underline">@lang('admin::app.users.sessions.submit-btn')</a> 
                            </div>
                            
                            <form v-else :action="'{{ route('sizechart.shop.custom.size.store') }}'" method="POST"  @submit="submitForm">
                                @csrf
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div v-for="column in columns.slice(1)" :key="column" class="mb-4">
                                        <div class="mb-1 text-sm font-medium text-gray-800">@{{ column }}</div>
                                        <input 
                                            type="number" 
                                            :name="'size_attributes_' + column.toLowerCase()"
                                            :placeholder="column"
                                            class="block w-full px-3 py-2 text-base text-gray-700 placeholder-gray-400 bg-white border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                            v-model="customSizeData[column]"
                                        >
                                        <div v-if="errors[column]" class="mt-1 text-sm text-red-500">@{{ errors[column] }}</div>
                                    </div>

                                    <input 
                                        type="hidden" 
                                        name="template_id" 
                                        value="{{$template->id}}"
                                    >
                                    
                                   
                                    <input 
                                        type="hidden" 
                                        name="product_id" 
                                        value="{{$productIds}}"
                                    >
                                </div>

                                @if( core()->getConfigData('sizechart.settings.size-chart.show_acknowledgement_note'))
                                    <div class="flex items-start mt-4 mb-2">
                                        <input
                                            type="checkbox"
                                            v-bind="field"
                                            id="acknowledgment-checkbox"
                                            class="sr-only peer"
                                            v-model="acknowledgmentChecked"
                                            name="acknowledgment"
                                            required
                                        />
                                    
                                        <label
                                            for="acknowledgment-checkbox"
                                            class="text-2xl cursor-pointer icon-uncheck peer-checked:icon-check-box peer-checked:text-navyBlue"
                                        >
                                        </label>

                                        <span class="ltr:ml-2.5 rtl:mr-2.5 text-sm">
                                            {{ core()->getConfigData('sizechart.settings.size-chart.acknowledgement_note')}}
                                        </span>
                                </div>
                                @endif
                                
                                <button
                                    type="submit"
                                    class="mt-2 primary-button m-0 block rounded-2xl px-11 py-3 text-center text-base max-md:w-full max-md:max-w-full max-md:rounded-lg max-md:py-2 max-sm:py-1.5"
                                    :disabled="showAcknowledgement && !acknowledgmentChecked"
                                    :class="showAcknowledgement && !acknowledgmentChecked ? 'opacity-50 cursor-not-allowed' : ''"
                                >
                                    @lang('shop::app.customers.account.addresses.create.save')
                                </button>
                            </form>
                        </div>
                    </div>
                </x-slot:content>
            </x-shop::modal>
        </script>

        <script type="module">
            app.component('v-size-chart', {
                template: '#v-size-chart-template',
                data() {
                    return {
                        activeTab: 'size-chart',
                        formData: { ...this.customSizeData },
                        errors: {},
                        acknowledgmentChecked: false,
                    }
                },
                
                props: {
                    sizeData: {
                        type: Array,
                        required: true
                    },
                    columns: {
                        type: Array,
                        required: true
                    },
                    imageUrl: {
                        type: String,
                        default: ''
                    },
                    customSizeData: {
                        type: Object,
                        default: () => ({})
                    },
                    isLoggedIn: { 
                        type: Boolean, 
                        required: true 
                    },
                    loginUrl: { 
                        type: String, 
                        required: true 
                    },
                    showAcknowledgement: {
                        type: Boolean,
                        default: false
                    }
                },

                methods: {
                    validateForm() {
                        this.errors = {};
                        let isValid = true;
                        
                        if (this.showAcknowledgement && !this.acknowledgmentChecked) {
                            isValid = false;
                            return;
                        }
        
                        for (const column in this.customSizeData) {
                            const value = this.customSizeData[column];
                            
                            if (!value) {
                                this.errors[column] = "@lang('sizechart::app.admin.system.validation-required-msg')";
                                isValid = false;
                            }
        
                            else if (isNaN(value) || parseFloat(value) < 1) {
                                this.errors[column] = "@lang('sizechart::app.admin.system.validation-negative-msg')";
                                isValid = false;
                            }
                        }
                        
                        return isValid;
                    },
                    
                    submitForm(event) {
                        if (!this.validateForm()) {
                            event.preventDefault();
                        }
                    }
                },
            });
        </script>
    @endPushOnce
@endif