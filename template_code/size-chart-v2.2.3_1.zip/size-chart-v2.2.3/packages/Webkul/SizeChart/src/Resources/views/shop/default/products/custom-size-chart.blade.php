@inject('customSizeChartRepository', 'Webkul\SizeChart\Repositories\CustomSizeChartRepository')

@php
    $sizeChart = app('Webkul\SizeChart\Http\Controllers\Shop\SizeChartController');
    
    if ($product->parent_id) {
        $productIds = $product->parent_id;
    } else {
        $productIds = $product->id;
    }

    $template = $sizeChart->getSizeChart($productIds);
    
    $customer = auth()->guard('customer')->user();
        
    $customSizeData = [];

    if ($customer  && $template) {
        $customSizeEntry = $customSizeChartRepository
            ->where('customer_id', $customer->id)
            ->where('product_id', $productIds)
            ->where('template_id', $template->id)
            ->whereNull('order_id')
            ->first();

        if ($customSizeEntry) {
            $decodedData = json_decode($customSizeEntry->size_attributes, true) ?? [];

            foreach ($decodedData as $key => $value) {
                $customSizeData[($key)] = $value;
            }
        }
    }
@endphp

@if (!empty($customSizeData))
    <div class="p-4 mt-4 border rounded bg-gray-50">
        <h3 class="mb-2 text-base font-medium">@lang('sizechart::app.sizechart.template.your-own-sizes')</h3>
        <ul class="pl-5 list-disc">
            @foreach ($customSizeData as $key => $value)
                <li>
                    <span class="text-base text-zinc-500">{{ $key }}:</span>   
                    <span class="text-base text-zinc-500">{{ $value }}</span>   
                </li>
            @endforeach
        </ul>
    </div>
@endif