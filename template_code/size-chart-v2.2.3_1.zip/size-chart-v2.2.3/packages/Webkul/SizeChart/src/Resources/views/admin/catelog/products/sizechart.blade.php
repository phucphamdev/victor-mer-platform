@php
    $sizeChart = app('Webkul\SizeChart\Http\Controllers\Admin\SizeChartController');

    $templates = $sizeChart->getAll();
    
    if ($product->parent_id) {
        $sproductId = $product->parent_id;
    } else {
        $sproductId = $product->id;
    }

    $savedTemp = $sizeChart->saveTemplate($sproductId);
@endphp

@if (
    $product->type == 'simple' 
    || $product->type == 'configurable' 
)
    <select-product-sizechart> </select-product-sizechart>               

    @pushOnce('scripts')
        <script type="text/x-template" id="select-product-sizechart-template">
            <div class="p-4 bg-white rounded-sm dark:bg-gray-900 box-shadow">
                <div class="mb-4">
                    @if ($savedTemp)
                        <span class="mb-4 text-base font-semibold text-gray-800 dark:text-white">@lang('sizechart::app.admin.system.saved-template')</span>
                        <span class="mb-5 text-sm text-gray-600 dark:text-gray-300"> {{ $savedTemp->template_name }}</span>
                    @else
                        <span class="mb-4 text-base font-semibold text-gray-800 dark:text-white">@lang('sizechart::app.admin.system.saved-template')</span>
                        <span class="mb-5 text-sm text-gray-600 dark:text-gray-300">@lang('sizechart::app.admin.system.none')</span>
                    @endif
                </div>

                <x-admin::form
                    v-slot="{ meta, errors, handleSubmit }"
                    as="div"
                >
                    <x-admin::form.control-group class="w-full mb-[10px]">
                        <x-admin::form.control-group.label>
                            @lang('sizechart::app.sizechart.template.select-template')
                        </x-admin::form.control-group.label>

                        <x-admin::form.control-group.control
                            type="select"
                            name="sizechart_id"
                            id="sizechart_id"
                            v-validate="'required'" 
                            :value="old('sizechart_id')"
                            v-model="selectedSizechart"
                            @change="selectSizechart($event)"
                        >
                        <option value="0" >{{ __('sizechart::app.sizechart.template.select-none') }}</option> 
                        <option v-for="(option, index) in selectOptions" :value="option.id">
                                @{{ option.template_name }}
                        </option>
                        </x-admin::form.control-group.control>

                        <x-admin::form.control-group.error
                            class="mt-3"
                            control-name="sizechart_id"
                        >
                        </x-admin::form.control-group.error>
                    </x-admin::form.control-group>
                </x-admin::form>    
            </div>
        </script>
    
        <script type="module">
            app.component('select-product-sizechart', {

                template: '#select-product-sizechart-template',

                data() {
                    return {
                        savedOption: @json($savedTemp),
                        selectedSizechart: '',
                        selectOptions: @json($templates)
                    }
                },

                mounted: function() {
                    if (this.savedOption) {
                        this.selectedSizechart = this.savedOption.id     
                    } else {
                        this.selectedSizechart = '0'
                    }
                },

                methods: {
                    selectSizechart: function() {
                        this.$axios.get(`{{ route('sizechart.shop.save.template') }}?product_id={{ $sproductId }}&sizechart_id=` + event.target.value)
                            .then(response => {
                                if (response.data.status) {

                                    return;
                                } else {
                                    this.$emitter.emit('add-flash', { type: 'warning', message: "@lang('sizechart::app.sizechart.template.custom-option-not-available')" });

                                    return;
                                }
                            })
                            .catch(error => {
                                this.$emitter.emit('add-flash', { type: 'warning', message: "@lang('sizechart::app.sizechart.template.something-went-wrong')" });
                        });
                    }
                }
            });
        </script>
    @endPushOnce
@endif
