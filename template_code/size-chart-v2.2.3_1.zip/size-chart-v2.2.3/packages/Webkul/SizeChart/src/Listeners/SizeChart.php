<?php

namespace Webkul\SizeChart\Listeners;

use Webkul\Sales\Contracts\Order as OrderContract;
use Webkul\SizeChart\Repositories\CustomSizeChartRepository;

class SizeChart
{
    /**
     * Create a new listner instance.
     *
     * @return void
     */
    public function __construct(
        protected CustomSizeChartRepository $customSizeChartRepository,
    ) {}

    /**
     * After order is created
     *
     * @return void
     */
    public function afterCreated(OrderContract $order)
    {
        foreach ($order->items as $item) {
            $this->customSizeChartRepository->where([
                'product_id'  => $item->product_id,
                'customer_id' => $order->customer_id,
                'order_id'    => null,
            ])->update([
                'order_id' => $order->id,
            ]);
        }
    }
}