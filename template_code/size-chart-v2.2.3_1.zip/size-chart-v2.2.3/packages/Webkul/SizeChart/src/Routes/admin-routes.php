<?php

use Illuminate\Support\Facades\Route;
use Webkul\SizeChart\Http\Controllers\Admin\SizeChartController;
use Webkul\SizeChart\Http\Controllers\Shop\SizeChartController as ShopSizeChartController;

Route::group(['middleware' => ['web', 'admin', 'locale']], function () {

    Route::group(['middleware' => ['IsSizeChartEnabled']], function () {

        Route::controller(SizeChartController::class)->prefix('admin/sizechart')->group(function () {
            Route::get('', 'index')->name('sizechart.admin.index');

            Route::get('create', 'create')->name('sizechart.admin.index.create');

            Route::post('store', 'store')->name('sizechart.admin.index.store');

            Route::get('edit/{id}', 'edit')->name('sizechart.admin.index.edit');

            Route::post('update/{id}', 'update')->name('sizechart.admin.index.update');

            Route::delete('delete/{id}', 'destroy')->name('sizechart.admin.index.delete');

            Route::post('massdelete', 'massDestroy')->name('sizechart.admin.index.massdelete');
        });
    });
});

Route::group(['middleware' => ['web', 'locale']], function () {

    Route::group(['middleware' => ['IsSizeChartEnabled']], function () {

        Route::get('/admin/sizechart/attribute', [SizeChartController::class, 'attributeOptions'])->name('sizechart.admin.config.attribute');
        
        Route::get('/shop/sizechart/template/save', [ShopSizeChartController::class, 'saveTemplate'])->name('sizechart.shop.save.template');

        Route::post('custom-size-chart/store', [ShopSizeChartController::class, 'customSizeStore'])->name('sizechart.shop.custom.size.store');
    });
});