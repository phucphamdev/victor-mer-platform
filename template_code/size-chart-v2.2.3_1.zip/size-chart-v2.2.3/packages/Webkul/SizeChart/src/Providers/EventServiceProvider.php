<?php

namespace Webkul\SizeChart\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        Event::listen('bagisto.admin.layout.head.before', function ($viewRenderEventManager) {
            $viewRenderEventManager->addTemplate('sizechart::admin.styles');
        });

        if (core()->getConfigData('sizechart.settings.size-chart.status')) {
            Event::listen('bagisto.admin.catalog.product.edit.form.categories.after', function($viewRenderEventManager) {
                $viewRenderEventManager->addTemplate('sizechart::admin.catelog.products.sizechart');
            });
       
            Event::listen('bagisto.shop.products.price.after', function($viewRenderEventManager) {
                $viewRenderEventManager->addTemplate('sizechart::shop.default.products.sizechart');

                $viewRenderEventManager->addTemplate('sizechart::shop.default.products.custom-size-chart');
            });

            Event::listen('checkout.order.save.after', 'Webkul\SizeChart\Listeners\SizeChart@afterCreated');
        }
    }
}