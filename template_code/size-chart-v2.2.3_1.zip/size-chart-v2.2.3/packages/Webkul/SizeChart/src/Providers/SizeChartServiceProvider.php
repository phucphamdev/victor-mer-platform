<?php

namespace Webkul\SizeChart\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Event;
use Illuminate\Routing\Router;
use Webkul\SizeChart\Http\Middleware\IsSizeChartEnabled;

class SizeChartServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot(Router $router)
    {
        $this->app->register(ModuleServiceProvider::class);

        $this->app->register(EventServiceProvider::class);
        
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');

        $this->loadRoutesFrom(__DIR__.'/../Routes/admin-routes.php');

        $this->loadTranslationsFrom(__DIR__ . '/../Resources/lang', 'sizechart');

        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'sizechart');

        $router->aliasMiddleware('IsSizeChartEnabled', IsSizeChartEnabled::class);

        $this->publishAssets();

        $this->publishes([
            __DIR__.'/../Resources/views/shop/customers/account/orders/view.blade.php' => __DIR__.'/../../../Shop/src/Resources/views/customers/account/orders/view.blade.php',
        ]);

        $this->publishes([
            __DIR__.'/../Resources/views/admin/sales/orders/view.blade.php' => __DIR__.'/../../../Admin/src/Resources/views/sales/orders/view.blade.php',
        ]);

        if (core()->getConfigData('sizechart.settings.size-chart.status')) {
            $this->mergeConfigFrom(
                dirname(__DIR__) . '/Config/admin-menu.php', 'menu.admin'
            );
        }
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->registerConfig();
    }

    /**
     * Register package config.
     *
     * @return void
     */
    protected function registerConfig()
    {
        $this->mergeConfigFrom(
            dirname(__DIR__) . '/Config/system.php', 'core'
        );
    }

    /**
     * Publish the assets.
     *
     * @return void
     */
    protected function publishAssets()
    {
        $this->publishes([
            __DIR__ .'/../../publishable/build' => public_path('themes/size-chart/build')
        ], 'public');
    }
}