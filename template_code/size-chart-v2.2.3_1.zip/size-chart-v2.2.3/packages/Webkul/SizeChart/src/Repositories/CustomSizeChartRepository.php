<?php

namespace Webkul\SizeChart\Repositories;

use Webkul\Core\Eloquent\Repository;

class CustomSizeChartRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return mixed
     */
    function model()
    {
        return 'Webkul\SizeChart\Contracts\CustomSizeChart';
    }
    /**
     * Retrieves and formats custom size data for a given product and authenticated customer.
     *
     * @param  object  $product
     * @return array
     */
    public function customSizeData($product, $customerId, $orderid)
    {
        if ($product->parent_id) {
            $productIds = $product->parent_id;
        } else {
            $productIds = $product->product_id;
        }
   
        $customSizeData = [];

        $customSizeEntry = $this->where('customer_id', $customerId)
            ->where('product_id', $productIds)
            ->where('order_id', $orderid)
            ->first();

        if ($customSizeEntry) {
            $decodedData = json_decode($customSizeEntry->size_attributes, true) ?? [];

            foreach ($decodedData as $key => $value) {
                $customSizeData[($key)] = $value;
            }
        }

        return $customSizeData;
    }
}