<?php

namespace Webkul\SizeChart\Contracts;

interface CustomSizeChart
{
}