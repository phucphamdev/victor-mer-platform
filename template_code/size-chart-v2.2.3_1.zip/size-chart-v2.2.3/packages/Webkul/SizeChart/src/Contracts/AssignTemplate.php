<?php

namespace Webkul\SizeChart\Contracts;

interface AssignTemplate
{
}