<?php

namespace Webkul\SizeChart\Models;

use Illuminate\Database\Eloquent\Model;
use Webkul\Product\Models\ProductProxy;
use Webkul\SizeChart\Contracts\AssignTemplate as AssignTemplateContract;

class AssignTemplate extends Model implements AssignTemplateContract
{   
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'template_assign';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'product_id', 
        'template_id',
    ];
}