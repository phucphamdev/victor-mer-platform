<?php

namespace Webkul\SizeChart\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CustomSizeChartProxy extends ModelProxy
{
}