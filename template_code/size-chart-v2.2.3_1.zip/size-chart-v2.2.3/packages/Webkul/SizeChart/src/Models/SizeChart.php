<?php

namespace Webkul\SizeChart\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Webkul\Product\Models\ProductProxy;
use Webkul\SizeChart\Contracts\SizeChart as SizeChartContract;

class SizeChart extends Model implements SizeChartContract
{   
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'size_charts';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'template_name', 
        'template_code', 
        'template_type', 
        'config_attribute', 
        'size_chart', 
        'image_path',
        'status',
    ];

    /**
     * Get image url for the product image.
     */
    public function image_url()
    {
        if (! $this->image_path) {
            return;
        }

        return Storage::url($this->image_path);
    }

    /**
     * Get image url for the product image.
     */
    public function getImageUrlAttribute()
    {
        return $this->image_url();
    }

    /**
     * @return array
     */
    public function toArray()
    {
        $array = parent::toArray();

        $array['image_url'] = $this->image_url;

        return $array;
    }

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'size_chart' => 'array',
    ];
}