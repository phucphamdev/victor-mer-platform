<?php

namespace Webkul\SizeChart\Http\Controllers\Shop;

use Illuminate\Http\Request;
use Webkul\SizeChart\Models\CustomSizeChart;
use Webkul\Attribute\Repositories\AttributeRepository;
use Webkul\SizeChart\Http\Controllers\Controller;
use Webkul\SizeChart\Repositories\SizeChartRepository;
use Webkul\SizeChart\Repositories\AssignTemplateRepository;
use Webkul\SizeChart\Repositories\CustomSizeChartRepository;

class SizeChartController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        protected AttributeRepository $attributeRepository,
        protected SizeChartRepository $sizechartRepository,
        protected AssignTemplateRepository $assignTemplateRepository,
        protected CustomSizeChartRepository $customSizeChartRepository,
    ) {}
    
    /**
     * Returns the assigned template.
     * 
     * @return array
     */
    public function getSizeChart(int $productId)
    {
        $assignTemplate = $this->assignTemplateRepository->findOneWhere([
            'product_id' => $productId,
        ]);
       
        if ($assignTemplate) {
            return $this->sizechartRepository->findOrFail($assignTemplate->template_id);
        }
    }

    /**
     * Returns size chart records.
     * 
     * @return array
     */
    public function getOptions(int $id)
    {
        $sizeChart = $this->sizechartRepository->findOrFail($id);

        $sizeChartData = json_decode($sizeChart->size_chart, true);

        return $sizeChartData;
    }

    /**
     * Save templates.
     * 
     * @return \Illuminate\Http\Response
     */
    public function saveTemplate()
    {
        if (! request('sizechart_id')) {
            $this->unassignTemplate(request('product_id'));
        } else {
            $this->saveOrUpdateTemplate(request('product_id'), request('sizechart_id'));
        }

        return response()->json([
            'status' => true,
        ]);
    }

    /**
     * Delete existing template.
     * 
     * @return void
     */
    public function unassignTemplate(int $productId)
    {
        $this->assignTemplateRepository->where([
            'product_id' => $productId,
        ])->delete();
    }

    /**
     * Save or update templates.
     * 
     * @return void
     */
    public function saveOrUpdateTemplate(int $productId, int $sizeChartId)
    {
        $this->assignTemplateRepository->updateOrCreate([
            'product_id' => $productId,
        ], [
            'template_id' => $sizeChartId,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     * 
     * @return \Illuminate\Http\Response
     */
    public function customSizeStore(Request $request)
    {
        $customerId = auth()->guard()->user()->id;
    
        if (! $customerId) {
            return redirect()->back()->with('error',  trans('sizechart::app.sizechart.response.error-logged-in'));
        }
    
        $sizeAttributes = [];
    
        foreach ($request->except(['_token', 'product_id', 'order_id']) as $key => $value) {
            if (strpos($key, 'size_attributes_') === 0) {
                $attribute = str_replace('size_attributes_', '', $key);
                $sizeAttributes[$attribute] = $value;
            }
        }

        $existingRecord = $this->customSizeChartRepository
            ->where('customer_id', $customerId)
            ->where('product_id', $request->product_id)
            ->where('template_id', $request->template_id)
            ->whereNull('order_id')
            ->first();

        if ($existingRecord) {
            $existingRecord->update([
                'size_attributes' => json_encode($sizeAttributes),
            ]);
        } else {
            $this->customSizeChartRepository->create([
                'customer_id'     => $customerId,
                'product_id'      => $request->product_id,
                'order_id'        => $request->order_id,
                'template_id'     => $request->template_id,
                'size_attributes' => json_encode($sizeAttributes),
            ]);
        }
    
        return redirect()->back()->with('success', trans('sizechart::app.sizechart.response.size-chart-save'));
    }
}