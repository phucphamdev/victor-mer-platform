<?php

namespace Webkul\SizeChart\Http\Controllers\Admin;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Webkul\Admin\Http\Requests\MassDestroyRequest;
use Webkul\Attribute\Repositories\AttributeRepository;
use Webkul\SizeChart\Datagrids\TemplateDataGrid;
use Webkul\SizeChart\Http\Controllers\Controller;
use Webkul\SizeChart\Repositories\SizeChartRepository;
use Webkul\SizeChart\Repositories\AssignTemplateRepository;

class SizeChartController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(
        protected SizeChartRepository $sizechartRepository,
        protected AssignTemplateRepository $assignTemplateRepository,
        protected AttributeRepository $attributeRepository
    ) {}

    /**
     * Display a listing of the resource.
     * 
     * @return Illuminate\View\View
     */
    public function index()
    {
        if (request()->ajax()) {
            return datagrid(TemplateDataGrid::class)->process();
        }

        return view('sizechart::admin.sizechart.index');
    }

    /**
     * Show the form for creating a new resource.
     * 
     * @return Illuminate\View\View
     */
    public function create()
    {
        return view('sizechart::admin.sizechart.create');
    }

    /**
     * Get all the templates.
     * 
     * @return array
     */
    public function getAll()
    {
        return $this->sizechartRepository->get();
    }

    /**
     * Save template for product.
     * 
     * @return array
     */
    public function saveTemplate(int $productId)
    {
        $checkSavedTemplate = $this->assignTemplateRepository->findOneWhere([
            'product_id' => $productId,
        ]);

        if (! empty($checkSavedTemplate)) {
            $sizeChart = $this->sizechartRepository->findOrFail($checkSavedTemplate->template_id);

            return $sizeChart;
        }
    }

    /**
     * Store a newly created resource in storage.
     * 
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        $this->validate(request(), [
            'template_name' => 'required',
            'measurements'  => 'required',
            'template_code' => ['required', 'unique:size_charts,template_code'],
            'image.*'       => 'nullable|mimes:bmp,jpeg,jpg,png,webp',
        ]);

        if (request()->hasFile('image')) {
            $imagePath = current(request()->file('image'))->store('template');
            $request->request->add(['image_path' => $imagePath]);
        }

        $sizeChart = json_encode(request('measurements'));

        $request->request->add(['size_chart' => $sizeChart]);

        $data = request()->only([
            'template_name',
            'template_code',
            'measurements',
            'size_chart',
            'image',
            'image_path',
        ]);

        $this->sizechartRepository->create($data);

        session()->flash('success', trans('sizechart::app.sizechart.response.create-success'));

        return redirect()->route('sizechart.admin.index');
    }

    /**
     * Show the form for editing the specified resource.
     * 
     * @return Illuminate\View\View
     */
    public function edit(int $id)
    {
        $sizeChart = $this->sizechartRepository->findOrFail($id);
        
        $sizeChartData = json_decode($sizeChart->size_chart, true);

        $sizeUnits = implode(',', array_keys($sizeChartData));

        $measurementUnits = implode(',', array_keys(reset($sizeChartData)));

        return view('sizechart::admin.sizechart.edit', compact('sizeChart', 'sizeChartData', 'sizeUnits', 'measurementUnits'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate(request(), [
            'template_name' => 'required',
            'measurements'  => 'required',
            'template_code' => ['required', 'unique:size_charts,template_code,'.$id,],
            'image.*'       => 'nullable|mimes:bmp,jpeg,jpg,png,webp',
        ]);

        if (request()->hasFile('image')) {
            $imagePath = current(request()->file('image'))->store('template');
            $request->request->add(['image_path' => $imagePath]);
        }

        $sizeChart = json_encode(request('measurements'));

        $request->request->add(['size_chart' => $sizeChart]);

        $data = request()->only([
            'template_name',
            'template_code',
            'measurements',
            'size_chart',
            'image',
            'image_path',
        ]);

        $this->sizechartRepository->update($data, $id);

        session()->flash('success', trans('sizechart::app.sizechart.template.update-success'));

        return redirect()->route('sizechart.admin.index'); 
    }

    /**
     * Remove the specified resource from storage.
     * 
     * @return  \Illuminate\Http\JsonResponse
     */
    public function destroy(int $id)
    {
        try {
            $this->sizechartRepository->delete($id);

            return new JsonResponse(['message' => trans('sizechart::app.sizechart.template.delete-success')]);
        } catch (\Exception $e) {
            return new JsonResponse(['message' => trans('admin::app.response.delete-failed', ['name' => 'Template'])], 500);
        }
    }

    /**
     * Mass delete the templates
     * 
     * @return  \Illuminate\Http\JsonResponse
     */
    public function massDestroy(MassDestroyRequest $massDestroyRequest)
    {
        $templateIds = $massDestroyRequest->input('indices');

        try {
            foreach ($templateIds as $templateId) {
                $this->sizechartRepository->delete($templateId);
            }

            return new JsonResponse([
                'message' => trans('sizechart::app.sizechart.template.delete-success')
            ], 200);
        } catch (\Exception $e) {
            return new JsonResponse([
                'message' => $e->getMessage()
            ], 500);
        }
    }
}