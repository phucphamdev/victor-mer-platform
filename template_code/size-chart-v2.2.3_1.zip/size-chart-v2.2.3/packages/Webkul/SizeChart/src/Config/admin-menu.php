<?php

return [
    [
        'key'   => 'sizechart',
        'name'  => 'sizechart::app.layouts.sizechart',
        'route' => 'sizechart.admin.index',
        'sort'  => 3,
        'icon'  => 'mp-size-chartmp',
    ],
];