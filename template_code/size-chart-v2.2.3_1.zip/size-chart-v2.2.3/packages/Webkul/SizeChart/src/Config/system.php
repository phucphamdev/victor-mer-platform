<?php

return [
    [
        'key'  => 'sizechart',
        'name' => 'sizechart::app.admin.system.size-chart',
        'info' => 'sizechart::app.admin.system.description',
        'sort' => 1,
    ], [
        'key'  => 'sizechart.settings',
        'name' => 'sizechart::app.admin.system.size-chart',
        'info' => 'sizechart::app.admin.system.description',
        'icon' => 'settings/store.svg',
        'sort' => 1,
    ], [
        'key'    => 'sizechart.settings.size-chart',
        'name'   => 'sizechart::app.admin.system.size-chart',
        'info'   => 'sizechart::app.admin.system.description',
        'sort'   => 1,
        'fields' => [
            [
                'name'          => 'status',
                'title'         => 'sizechart::app.admin.system.enable-size-chart',
                'type'          => 'boolean',
                'channel_based' => true,
                'locale_based'  => false,
            ], [
                'name'          => 'custom_size_chart_status',
                'title'         => 'sizechart::app.admin.system.custom-size-chart-status',
                'type'          => 'boolean',
                'channel_based' => true,
                'locale_based'  => false,
            ], [
                'name'          => 'show_acknowledgement_note',
                'title'         => 'sizechart::app.admin.system.show-acknowledgement-note',
                'type'          => 'boolean',
                'channel_based' => true,
                'locale_based'  => false,
            ], [
                'name'          => 'acknowledgement_note',
                'title'         => 'sizechart::app.admin.system.acknowledgement-note',
                'type'          => 'textarea',
                'depends'       => 'show_acknowledgement_note:1',
                'validation'    => 'required_if:show_acknowledgement_note,1',
                'channel_based' => true,
                'locale_based'  => true,
            ],
        ],
    ],
];