# CHANGELOG for v2.0.0

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v2.2.3(2024)** - Release

* [feature] Compatible with Bagisto v2.2.3

## **v2.0.0(4th of Jan, 2024)** - Release

* [feature] Compatible with Bagisto v2.0.0

## **v1.4.3(21st of Jul, 2022)** - Release

* [feature] Compatible with Bagisto v1.4.3

## **v1.3.3(8th of Feb, 2022)** - Release

* [feature] Compatible with Bagisto v1.3.3

## **v1.3.2(21st of September, 2021)** - Release

* [feature] Compatible with Bagisto v1.3.2

## **v1.2.0(11th of March, 2021)** - *Release*

* [feature] Compatible with bagisto v1.2.0 version

* [feature] Two types of templates can be created – Normal & Configurable Product Template.

* [feature] Admin can add a size chart image.

* [feature] Size Chart Module supports jpg, .png, .jpeg as image formats.

* [feature] The customer will see the size chart on the product page.
