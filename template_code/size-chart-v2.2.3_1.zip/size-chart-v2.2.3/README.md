### 1. Introduction:

* Admin can add size chart templates.
* Two types of templates can be created – Normal & Configurable Product Template.
* Admin can add a size chart image.
* Admin can enable/disable size chart from configurations.
* Size Chart Module supports jpg, .png, .jpeg, .bmp, .webp as image formats.
* The customer will see the size chart on the product page.
* This module increases the customer satisfaction.
* Size Chart Module is working with Simple, Virtual, and Configurable product types.

### 2. Requirements:

* **Bagisto**: v2.2.3.


### 3. Installation:

* Unzip the respective extension zip and then merge "packages" folder into project root directory.
* Goto config/app.php file and add following line under 'providers'

~~~
Webkul\SizeChart\Providers\SizeChartServiceProvider::class,
~~~

* Goto composer.json file and add following line under 'psr-4'

~~~
"Webkul\\SizeChart\\": "packages/Webkul/SizeChart/src"
~~~

* In the config/bagisto-vite.php file, add the following line under the 'viters' section:

~~~
    'size_chart' => [
        'hot_file'                 => 'size-chart-vite.hot',
        'build_directory'          => 'themes/size-chart/build',
        'package_assets_directory' => 'src/Resources/assets',
    ],
~~~

* Run these commands below to complete the setup

~~~
composer dump-autoload
~~~

~~~
php artisan migrate
~~~

~~~
php artisan route:cache
~~~

~~~
php artisan vendor:publish --force

-> Enter Webkul\SizeChart\Providers\SizeChartServiceProvider and then press enter to publish all assets and configurations.
~~~

> now execute the project on your specified domain.
