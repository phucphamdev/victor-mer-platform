<?php

return [
    'design email' => 'Design email',
    'send' => 'Send',
    'cgs' => 'Customer groups',
    'subs' => 'To subscribers',
    'subj' => 'Email subject',
    'intro' => 'Introduction text'
];