<?php

namespace Tahiryasin\Countries\Contracts;

interface CountryState
{
}