<?php

namespace Tahiryasin\Countries\Contracts;

interface Country
{
}