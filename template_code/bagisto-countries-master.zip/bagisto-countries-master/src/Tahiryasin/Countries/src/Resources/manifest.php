<?php

return [
    'name'    => 'Tahir\'s Countries CRUD',
    'version' => '0.0.1',
];
