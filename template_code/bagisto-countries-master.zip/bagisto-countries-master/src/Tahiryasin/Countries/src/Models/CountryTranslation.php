<?php

namespace Tahiryasin\Countries\Models;

use Webkul\CMS\Models\CountryTranslation as WebkulCountryTranslation;

class CountryTranslation extends WebkulCountryTranslation
{

}