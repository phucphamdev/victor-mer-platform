<?php

namespace Tahiryasin\Countries\Models;

use Webkul\CMS\Models\CountryTranslationProxy as WebkulCountryTranslationProxy;

class CountryTranslationProxy extends WebkulCountryTranslationProxy
{

}