<?php

namespace Tahiryasin\Countries\Models;

use Webkul\CMS\Models\CountryProxy as WebkulCountryProxy;

class CountryProxy extends WebkulCountryProxy
{

}