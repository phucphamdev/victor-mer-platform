<?php

return [
    'paytm'  => [
        'code'        => 'paytm',
        'title'       => 'Paytm',
        'description' => 'Paytm',
        'class'       => 'Wontonee\Paytm\Payment\Paytm',
        'active'      => true,
        'sort'        => 8,
    ],
];