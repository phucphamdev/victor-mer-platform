<?php

namespace Mziel\Blog\Models;

use Konekt\Concord\Proxies\ModelProxy;

class BlogCategoryProxy extends ModelProxy
{

}