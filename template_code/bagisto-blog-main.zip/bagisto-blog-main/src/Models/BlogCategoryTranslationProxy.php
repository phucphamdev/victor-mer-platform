<?php

namespace Mziel\Blog\Models;

use Konekt\Concord\Proxies\ModelProxy;

class BlogCategoryTranslationProxy extends ModelProxy
{

}