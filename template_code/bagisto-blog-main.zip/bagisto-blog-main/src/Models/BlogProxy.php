<?php

namespace Mziel\Blog\Models;

use Konekt\Concord\Proxies\ModelProxy;

class BlogProxy extends ModelProxy
{

}