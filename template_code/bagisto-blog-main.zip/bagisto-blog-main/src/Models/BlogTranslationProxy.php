<?php

namespace Mziel\Blog\Models;

use Konekt\Concord\Proxies\ModelProxy;

class BlogTranslationProxy extends ModelProxy
{

}