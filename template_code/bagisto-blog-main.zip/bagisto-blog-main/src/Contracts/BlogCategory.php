<?php

namespace Mziel\Blog\Contracts;

interface BlogCategory
{
}