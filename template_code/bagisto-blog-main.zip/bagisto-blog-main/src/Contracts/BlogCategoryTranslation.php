<?php

namespace Mziel\Blog\Contracts;

interface BlogCategoryTranslation
{
}