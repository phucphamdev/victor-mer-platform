<?php

namespace Mziel\Blog\Contracts;

interface BlogTranslation
{
}