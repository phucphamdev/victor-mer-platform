<?php

namespace Mziel\Blog\Contracts;

interface Blog
{
}