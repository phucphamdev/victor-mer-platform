# Changelog for Bagisto Rewards

#### This changelog consists the bug & security fixes and new features being included in the releases listed below.

## **v2.1.2** - *Release*

* Compatibile with bagisto v2.1.2

## **v2.0.0** - *Release*

* [fixed] Compatibility issue with bagisto v2.0.0

## **v1.5.1** - *Release*

* [fixed] Compatibility issue with bagisto v1.5.1

## **v1.2.0(25h of September 2020)** - *Release*

* [feature] Admin can add Attributes rewards.

* [feature] Admin can add Category rewards.

* [feature] Admin can add Product rewards.

* [feature] Admin can add Cart rewards.

* [feature] Reward are calculated based on Attribute/Category/Product/Cart.

* [feature] Admin can view all the users and all the reward based on order.



