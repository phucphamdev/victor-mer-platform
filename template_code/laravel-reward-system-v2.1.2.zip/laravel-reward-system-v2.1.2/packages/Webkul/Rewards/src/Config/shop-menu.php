<?php

return [
    [
        'key'   => 'account.reward_points',
        'name'  => 'rewards::app.shop.customer.account.layouts.reward-points',
        'route' => 'customer.rewards.index',
        'icon'  => 'reward-reward-point-icon',
        'sort'  => 8,
    ],
];