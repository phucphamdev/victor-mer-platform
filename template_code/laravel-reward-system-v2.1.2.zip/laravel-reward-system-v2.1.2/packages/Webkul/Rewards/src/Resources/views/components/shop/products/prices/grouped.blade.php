<p class="text-sm text-[#6E6E6E]">
    @lang('shop::app.products.prices.grouped.starting-at')
</p>

<p class="final-price font-semibold">
    {{ $prices['final']['formatted_price'] }}
</p>