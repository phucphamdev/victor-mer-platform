<p class="price-label text-sm text-[#6E6E6E] price-label">
    @lang('shop::app.products.prices.configurable.as-low-as')
</p>

<p class="final-price font-semibold special-price">
    {{ $prices['regular']['formatted_price'] }}
</p>