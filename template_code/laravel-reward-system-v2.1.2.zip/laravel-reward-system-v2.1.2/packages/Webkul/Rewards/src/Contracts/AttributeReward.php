<?php

namespace Webkul\Rewards\Contracts;

interface AttributeReward
{
}