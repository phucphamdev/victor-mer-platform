<?php

namespace Webkul\Rewards\Contracts;

interface CategorySpecificTimeReward
{
}