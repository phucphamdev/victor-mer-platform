<?php

namespace Webkul\TableRate\Contracts;

interface SuperSetRate
{
}