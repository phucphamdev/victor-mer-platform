<?php

namespace Webkul\Rewards\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CartRewardProxy extends ModelProxy
{
}