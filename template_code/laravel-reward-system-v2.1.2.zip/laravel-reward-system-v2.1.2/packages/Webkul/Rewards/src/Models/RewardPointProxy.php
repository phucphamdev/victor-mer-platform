<?php

namespace Webkul\Rewards\Models;

use Konekt\Concord\Proxies\ModelProxy;

class RewardPointProxy extends ModelProxy
{
}