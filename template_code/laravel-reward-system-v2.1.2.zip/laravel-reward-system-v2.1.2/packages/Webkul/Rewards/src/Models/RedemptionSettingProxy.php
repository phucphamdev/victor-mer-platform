<?php

namespace Webkul\Rewards\Models;

use Konekt\Concord\Proxies\ModelProxy;

class RedemptionSettingProxy extends ModelProxy
{
}