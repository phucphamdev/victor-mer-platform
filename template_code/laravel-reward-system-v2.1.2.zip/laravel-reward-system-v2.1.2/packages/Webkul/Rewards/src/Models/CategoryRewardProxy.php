<?php

namespace Webkul\Rewards\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CategoryRewardProxy extends ModelProxy
{
}